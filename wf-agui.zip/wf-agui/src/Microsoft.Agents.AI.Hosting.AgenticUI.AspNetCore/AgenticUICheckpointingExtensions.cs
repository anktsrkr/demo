// Copyright (c) Microsoft. All rights reserved.

using Microsoft.Agents.AI.Workflows;
using Microsoft.Agents.AI.Workflows.AgenticUI;
//using Microsoft.Agents.AI.Workflows.AgenticUI.Checkpointing;
using Microsoft.Agents.AI.Workflows.AgenticUI.Events;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.OpenApi;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.DependencyInjection;
using System.Text.Json;

namespace Microsoft.Agents.AI.Hosting.AgenticUI.AspNetCore;

/// <summary>
/// Extension methods for enabling checkpointing in Agentic UI endpoints.
/// </summary>
public static class AgenticUICheckpointingExtensions
{
    /// <summary>
    /// Maps an endpoint for checkpointing operations (create, resume, rehydrate, list).
    /// </summary>
    public static IEndpointConventionBuilder MapAgenticUICheckpoint(
        this IEndpointRouteBuilder endpoints,
        string pattern = "/api/checkpoint")
    {
        var group = endpoints.MapGroup(pattern);

        // List checkpoints for a run
        group.MapGet("/{runId}", ListCheckpoints)
            .WithName("ListCheckpoints")
            .WithOpenApi();

        // Get checkpoint metadata
        group.MapGet("/{runId}/{checkpointId}", GetCheckpointMetadata)
            .WithName("GetCheckpointMetadata")
            .WithOpenApi();

        // Delete a checkpoint
        group.MapDelete("/{checkpointId}", DeleteCheckpoint)
            .WithName("DeleteCheckpoint")
            .WithOpenApi();

        // Delete all checkpoints for a run
        group.MapDelete("/run/{runId}", DeleteRunCheckpoints)
            .WithName("DeleteRunCheckpoints")
            .WithOpenApi();

        return group;
    }

    private static async Task<IResult> ListCheckpoints(
        string runId,
        Microsoft.Agents.AI.Workflows.AgenticUI.Checkpointing.CheckpointManager? checkpointManager,
        CancellationToken ct)
    {
        if (checkpointManager == null)
        {
            return Results.BadRequest(new { error = "Checkpointing is not enabled" });
        }

        try
        {
            var checkpoints = await checkpointManager.ListCheckpointsAsync(runId, ct);
            return Results.Ok(checkpoints.Select(cp => new
            {
                cp.CheckpointId,
                cp.RunId,
                cp.SuperStepNumber,
                cp.CreatedAt,
                cp.Description,
                cp.Tags
            }));
        }
        catch (Exception)
        {
            return Results.InternalServerError();
        }
    }

    private static async Task<IResult> GetCheckpointMetadata(
        string runId,
        string checkpointId,
        Microsoft.Agents.AI.Workflows.AgenticUI.Checkpointing.CheckpointManager? checkpointManager,
        CancellationToken ct)
    {
        if (checkpointManager == null)
        {
            return Results.BadRequest(new { error = "Checkpointing is not enabled" });
        }

        try
        {
            var metadata = await checkpointManager.GetCheckpointMetadataAsync(checkpointId, ct);
            if (metadata == null || metadata.RunId != runId)
            {
                return Results.NotFound();
            }

            return Results.Ok(new
            {
                metadata.CheckpointId,
                metadata.RunId,
                metadata.SuperStepNumber,
                metadata.CreatedAt,
                metadata.Description,
                metadata.Tags
            });
        }
        catch (Exception)
        {
            return Results.InternalServerError();
        }
    }

    private static async Task<IResult> DeleteCheckpoint(
        string checkpointId,
        Microsoft.Agents.AI.Workflows.AgenticUI.Checkpointing.CheckpointManager? checkpointManager,
        CancellationToken ct)
    {
        if (checkpointManager == null)
        {
            return Results.BadRequest(new { error = "Checkpointing is not enabled" });
        }

        try
        {
            bool deleted = await checkpointManager.DeleteCheckpointAsync(checkpointId, ct);
            if (!deleted)
            {
                return Results.NotFound();
            }

            return Results.Ok(new { message = "Checkpoint deleted successfully" });
        }
        catch (Exception)
        {
            return Results.InternalServerError();
        }
    }

    private static async Task<IResult> DeleteRunCheckpoints(
        string runId,
        Microsoft.Agents.AI.Workflows.AgenticUI.Checkpointing.CheckpointManager? checkpointManager,
        CancellationToken ct)
    {
        if (checkpointManager == null)
        {
            return Results.BadRequest(new { error = "Checkpointing is not enabled" });
        }

        try
        {
            await checkpointManager.DeleteRunCheckpointsAsync(runId, ct);
            return Results.Ok(new { message = "All checkpoints for the run deleted successfully" });
        }
        catch (Exception)
        {
            return Results.InternalServerError();
        }
    }
}

/// <summary>
/// Input model for checkpoint resume operations.
/// </summary>
public class CheckpointResumeInput
{
    /// <summary>
    /// The checkpoint ID to resume from.
    /// </summary>
    public required string CheckpointId { get; set; }

    /// <summary>
    /// Optional reason for the resume operation.
    /// </summary>
    public string? Reason { get; set; }
}

/// <summary>
/// Input model for checkpoint rehydration operations.
/// </summary>
public class CheckpointRehydrateInput
{
    /// <summary>
    /// The checkpoint ID to rehydrate from.
    /// </summary>
    public required string CheckpointId { get; set; }

    /// <summary>
    /// The original run ID from the checkpoint.
    /// </summary>
    public required string OriginalRunId { get; set; }

    /// <summary>
    /// Optional reason for the rehydrate operation.
    /// </summary>
    public string? Reason { get; set; }
}
