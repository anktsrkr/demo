// Copyright (c) Microsoft. All rights reserved.

using Microsoft.Agents.AI.Workflows;
using Microsoft.Agents.AI.Workflows.AgenticUI;
using Microsoft.Agents.AI.Workflows.AgenticUI.Events;
using Microsoft.Agents.AI.Workflows.Checkpointing;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Mvc;
using System.IO;
using System.Net.Http;
using System.Text.Json;

namespace Microsoft.Agents.AI.Hosting.AgenticUI.AspNetCore;

public static class AgenticUIEndpointExtensions
{
    /// <summary>
    /// Maps an endpoint for streaming Agentic UI events from a workflow.
    /// </summary>
    /// <param name="endpoints">The endpoint route builder.</param>
    /// <param name="pattern">The route pattern.</param>
    /// <param name="workflow">The workflow instance to run.</param>
    /// <returns>A convention builder.</returns>
    public static IEndpointConventionBuilder MapAgenticUI(
        this IEndpointRouteBuilder endpoints,
        string pattern,
        Workflow workflow)
    {
        return endpoints.MapPost(pattern, async (HttpContext context, AgenticUIInput? input, [FromServices] CheckpointManager? checkpointManager) =>
        {
            if (input == null)
            {
                return new AgenticUIServerSentEventsResult(GetErrorEvents());
            }

            async IAsyncEnumerable<AgenticUIEvent> GetErrorEvents()
            {
                yield return new RunErrorEvent { Error = "Invalid input", Details = "The request body was missing or invalid." };
                await Task.CompletedTask;
            }

            // Simple input model binding
            string initialInput = input.Input ?? "Start";
            string runId = input.RunId ?? Guid.NewGuid().ToString("N");

            StreamingRun run;
            var store = context.RequestServices.GetService<ICheckpointStore<JsonElement>>();
            CheckpointInfo? lastCheckpoint = null;
            if (store != null)
            {
                var index = await store.RetrieveIndexAsync(runId).ConfigureAwait(false);
                lastCheckpoint = index.LastOrDefault();
            }

            if (checkpointManager != null && lastCheckpoint != null)
            {
                var checkpointed = await InProcessExecution.ResumeStreamAsync(workflow, lastCheckpoint, checkpointManager, runId, context.RequestAborted);
                run = checkpointed.Run;
                await run.TrySendMessageAsync(initialInput).ConfigureAwait(false);
            }
            else if (checkpointManager != null)
            {
                var checkpointed = await InProcessExecution.StreamAsync(workflow, initialInput, checkpointManager, runId, context.RequestAborted);
                run = checkpointed.Run;
            }
            else
            {
                run = await InProcessExecution.StreamAsync(workflow, initialInput, runId, context.RequestAborted);
            }

            await run.TrySendMessageAsync(new TurnToken(emitEvents: true));
            async IAsyncEnumerable<AgenticUIEvent> StreamEvents()
            {
                yield return new RunStartedEvent();

                await foreach (AgenticUIEvent uiEvt in run.WatchStreamAsync(context.RequestAborted).AsAgenticUIEvents())
                {
                    yield return uiEvt;
                }

                yield return new RunFinishedEvent();

                // (Auto-checkpoint logic omitted for stability - relying on framework or manual triggering)
            }

            return new AgenticUIServerSentEventsResult(StreamEvents(), run);
        });
    }
}

public class AgenticUIInput
{
    public string? Input { get; set; }
    public string? RunId { get; set; }
}
