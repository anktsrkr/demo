using Microsoft.Agents.AI.Workflows.AgenticUI.Events;
using Microsoft.Agents.AI.Workflows.Checkpointing;
using System.Text.Json;

namespace Microsoft.Agents.AI.Workflows.AgenticUI.Checkpointing;

/// <summary>
/// Manages checkpoint operations by wrapping a core framework checkpoint store.
/// </summary>
public class CheckpointManager(ICheckpointStore<JsonElement> store)
{
    private readonly ICheckpointStore<JsonElement> _store = store ?? throw new ArgumentNullException(nameof(store));

    /// <summary>
    /// Lists all unique run IDs.
    /// </summary>
    public ValueTask<IEnumerable<string>> ListRunsAsync(CancellationToken ct = default)
    {
        if (_store is ICheckpointStoreWithManagement<JsonElement> management)
        {
            return management.ListRunsAsync(ct);
        }

        return ValueTask.FromResult(Enumerable.Empty<string>());
    }

    /// <summary>
    /// Retrieves checkpoint metadata by ID.
    /// </summary>
    public async ValueTask<CheckpointMetadata?> GetCheckpointMetadataAsync(string checkpointId, string runId, CancellationToken ct = default)
    {
        var data = await GetCheckpointDataAsync(checkpointId, runId, ct).ConfigureAwait(false);
        if (data == null) return null;

        int stepNumber = 0;
        DateTimeOffset createdAt = DateTimeOffset.UtcNow;

        try
        {
            using var doc = JsonDocument.Parse(data);

            // Try to get stepNumber from value.stepNumber (actual checkpoint structure)
            if (doc.RootElement.TryGetProperty("value", out var valueProp) &&
                valueProp.TryGetProperty("stepNumber", out var stepProp))
            {
                stepNumber = stepProp.GetInt32();
            }
            // Fallback: try legacy superStepNumber at root
            else if (doc.RootElement.TryGetProperty("superStepNumber", out var ssProp))
            {
                stepNumber = ssProp.GetInt32();
            }

            // Try to get timestamp if available
            if (doc.RootElement.TryGetProperty("timestamp", out var tsProp) &&
                tsProp.TryGetDateTimeOffset(out var ts))
            {
                createdAt = ts;
            }
        }
        catch { /* Ignore parse errors */ }

        return new CheckpointMetadata
        {
            CheckpointId = checkpointId,
            RunId = runId,
            CreatedAt = createdAt,
            SuperStepNumber = stepNumber
        };
    }

    /// <summary>
    /// Lists all checkpoints for a specific run.
    /// </summary>
    public async ValueTask<IEnumerable<CheckpointMetadata>> ListCheckpointsAsync(string runId, CancellationToken ct = default)
    {
        var index = await _store.RetrieveIndexAsync(runId).ConfigureAwait(false);
        var result = new List<CheckpointMetadata>();

        foreach (var info in index)
        {
            var metadata = await GetCheckpointMetadataAsync(info.CheckpointId, runId, ct).ConfigureAwait(false);
            if (metadata != null)
            {
                result.Add(metadata);
            }
        }

        return result;
    }

    /// <summary>
    /// Retrieves the latest checkpoint metadata for a run.
    /// </summary>
    public async ValueTask<CheckpointMetadata?> GetLatestCheckpointAsync(string runId, CancellationToken ct = default)
    {
        var index = await _store.RetrieveIndexAsync(runId).ConfigureAwait(false);
        var latest = index.LastOrDefault(); // Assuming last is latest

        if (latest == null) return null;
        return await GetCheckpointMetadataAsync(latest.CheckpointId, runId, ct).ConfigureAwait(false);
    }

    /// <summary>
    /// Retrieves the checkpoint data.
    /// </summary>
    public async ValueTask<string?> GetCheckpointDataAsync(string checkpointId, string runId, CancellationToken ct = default)
    {
        try
        {
            var element = await _store.RetrieveCheckpointAsync(runId, new CheckpointInfo(runId, checkpointId)).ConfigureAwait(false);
            return element.GetRawText();
        }
        catch (KeyNotFoundException)
        {
            return null;
        }
    }

    /// <summary>
    /// Retrieves the chat history data from the latest checkpoint of a run.
    /// </summary>
    public async ValueTask<string?> GetChatHistoryDataAsync(string runId, CancellationToken ct = default)
    {
        var latest = await GetLatestCheckpointAsync(runId, ct).ConfigureAwait(false);
        if (latest == null) return null;

        var data = await GetCheckpointDataAsync(latest.CheckpointId, runId, ct).ConfigureAwait(false);
        if (string.IsNullOrEmpty(data)) return null;

        try
        {
            using var doc = JsonDocument.Parse(data);

            // Navigate to value.stateData (actual checkpoint structure)
            JsonElement stateData;
            if (
                doc.RootElement.TryGetProperty("stateData", out stateData))
            {
                // Good - use value.stateData
            }
            // Fallback: try legacy "state" at root
            else if (doc.RootElement.TryGetProperty("state", out stateData))
            {
                // Use legacy state
            }
            else
            {
                return null;
            }

            // Search for any key ending in "workflow_message_store"
            foreach (var prop in stateData.EnumerateObject())
            {
                if (prop.Name.EndsWith("workflow_message_store", StringComparison.OrdinalIgnoreCase))
                {
                    var storeProp = prop.Value;

                    // Unwrap TypedValue wrapper if present
                    if (storeProp.TryGetProperty("value", out var innerValue))
                    {
                        storeProp = innerValue;
                    }

                    // Extract messages array
                    if (storeProp.TryGetProperty("messages", out var messagesProp) ||
                        storeProp.TryGetProperty("Messages", out messagesProp))
                    {
                        return messagesProp.GetRawText();
                    }
                }
            }
        }
        catch { /* Ignore parse errors */ }

        return null;
    }

    /// <summary>
    /// Deletes all checkpoints for a run.
    /// </summary>
    public ValueTask DeleteRunCheckpointsAsync(string runId, CancellationToken ct = default)
    {
        if (_store is ICheckpointStoreWithManagement<JsonElement> management)
        {
            return management.DeleteRunCheckpointsAsync(runId, ct);
        }

        return ValueTask.CompletedTask;
    }

    /// <summary>
    /// Creates a checkpoint created event (standardized).
    /// </summary>
    public static CheckpointCreatedUIEvent CreateCreatedEvent(
        string checkpointId,
        string runId,
        int superStepNumber,
        string? description = null,
        Dictionary<string, string>? tags = null)
    {
        return new CheckpointCreatedUIEvent
        {
            CheckpointId = checkpointId,
            RunId = runId,
            SuperStepNumber = superStepNumber,
            Description = description,
            Tags = tags,
            Timestamp = DateTimeOffset.UtcNow
        };
    }

    /// <summary>
    /// Creates a checkpoint resuming event (for frontend notification).
    /// </summary>
    public static CheckpointResumingUIEvent CreateResumingEvent(
        string checkpointId,
        string runId,
        int superStepNumber,
        string? reason = null)
    {
        return new CheckpointResumingUIEvent
        {
            CheckpointId = checkpointId,
            RunId = runId,
            SuperStepNumber = superStepNumber,
            Reason = reason,
            Timestamp = DateTimeOffset.UtcNow
        };
    }

    /// <summary>
    /// Creates a checkpoint error event (for frontend notification).
    /// </summary>
    public static CheckpointErrorUIEvent CreateErrorEvent(
        string error,
        string? checkpointId = null,
        string? operation = null,
        string? details = null)
    {
        return new CheckpointErrorUIEvent
        {
            CheckpointId = checkpointId,
            Error = error,
            Operation = operation,
            Details = details,
            Timestamp = DateTimeOffset.UtcNow
        };
    }
}

/// <summary>
/// Represents metadata about a checkpoint.
/// </summary>
public record CheckpointMetadata
{
    public required string CheckpointId { get; set; }
    public required string RunId { get; set; }
    public required int SuperStepNumber { get; set; }
    public required DateTimeOffset CreatedAt { get; set; }
    public string? Description { get; set; }
    public Dictionary<string, string>? Tags { get; set; }
}

