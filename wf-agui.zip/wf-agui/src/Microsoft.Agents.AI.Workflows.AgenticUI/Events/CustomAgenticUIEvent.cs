// Copyright (c) Microsoft. All rights reserved.

using System.Text.Json;
using System.Text.Json.Serialization;

namespace Microsoft.Agents.AI.Workflows.AgenticUI.Events;

/// <summary>
/// Base class for custom user-defined Agentic UI events.
/// This allows flexibility for users to define their own event types.
/// </summary>
public class CustomAgenticUIEvent : AgenticUIEvent
{
    public CustomAgenticUIEvent()
    {
    }

    public CustomAgenticUIEvent(string eventType)
    {
        EventType = eventType;
    }

    [JsonIgnore]
    public virtual string? EventType { get; set; }

    [JsonPropertyName("payload")]
    public JsonElement? Payload { get; set; }
}
