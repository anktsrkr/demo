// Copyright (c) Microsoft. All rights reserved.

using System.Text.Json.Serialization;

namespace Microsoft.Agents.AI.Workflows.AgenticUI.Events;

/// <summary>
/// Event emitted when a SuperStep starts.
/// </summary>
public class SuperStepStartedUIEvent : AgenticUIEvent
{
    [JsonPropertyName("step_number")]
    public int StepNumber { get; set; }
}

/// <summary>
/// Event emitted when a SuperStep completes.
/// </summary>
public class SuperStepCompletedUIEvent : AgenticUIEvent
{
    [JsonPropertyName("step_number")]
    public int StepNumber { get; set; }
}
