// Copyright (c) Microsoft. All rights reserved.

using System.Text.Json.Serialization;

namespace Microsoft.Agents.AI.Workflows.AgenticUI.Events;

/// <summary>
/// Base class for all Agentic UI events.
/// </summary>
[JsonPolymorphic(TypeDiscriminatorPropertyName = "eventType")]
[JsonDerivedType(typeof(RunStartedEvent), AgenticUIEventTypes.RunStarted)]
[JsonDerivedType(typeof(RunFinishedEvent), AgenticUIEventTypes.RunFinished)]
[JsonDerivedType(typeof(RunErrorEvent), AgenticUIEventTypes.RunError)]
[JsonDerivedType(typeof(AgentStateSnapshotEvent), AgenticUIEventTypes.AgentStateSnapshot)]
[JsonDerivedType(typeof(AgentStateDeltaEvent), AgenticUIEventTypes.AgentStateDelta)]
[JsonDerivedType(typeof(AgentPlanningStartEvent), AgenticUIEventTypes.AgentPlanningStart)]
[JsonDerivedType(typeof(AgentPlanningStepEvent), AgenticUIEventTypes.AgentPlanningStep)]
[JsonDerivedType(typeof(AgentPlanningEndEvent), AgenticUIEventTypes.AgentPlanningEnd)]
[JsonDerivedType(typeof(ToolCallStartEvent), AgenticUIEventTypes.ToolCallStart)]
[JsonDerivedType(typeof(ToolCallArgsEvent), AgenticUIEventTypes.ToolCallArgs)]
[JsonDerivedType(typeof(ToolCallEndEvent), AgenticUIEventTypes.ToolCallEnd)]
[JsonDerivedType(typeof(ToolCallResultEvent), AgenticUIEventTypes.ToolCallResult)]
[JsonDerivedType(typeof(ExecutorInvokedUIEvent), AgenticUIEventTypes.ExecutorInvoked)]
[JsonDerivedType(typeof(ExecutorCompletedUIEvent), AgenticUIEventTypes.ExecutorCompleted)]
[JsonDerivedType(typeof(ExecutorFailedUIEvent), AgenticUIEventTypes.ExecutorFailed)]
[JsonDerivedType(typeof(SuperStepStartedUIEvent), AgenticUIEventTypes.SuperStepStarted)]
[JsonDerivedType(typeof(SuperStepCompletedUIEvent), AgenticUIEventTypes.SuperStepCompleted)]
[JsonDerivedType(typeof(AgentUpdateUIEvent), AgenticUIEventTypes.AgentUpdate)]
[JsonDerivedType(typeof(WorkflowOutputUIEvent), AgenticUIEventTypes.WorkflowOutput)]
[JsonDerivedType(typeof(WorkflowWarningUIEvent), AgenticUIEventTypes.WorkflowWarning)]
[JsonDerivedType(typeof(RequestInfoUIEvent), AgenticUIEventTypes.RequestInfo)]
[JsonDerivedType(typeof(CheckpointCreatedUIEvent), AgenticUIEventTypes.CheckpointCreated)]
[JsonDerivedType(typeof(CheckpointResumingUIEvent), AgenticUIEventTypes.CheckpointResuming)]
[JsonDerivedType(typeof(CheckpointRehydratingUIEvent), AgenticUIEventTypes.CheckpointRehydrating)]
[JsonDerivedType(typeof(CheckpointErrorUIEvent), AgenticUIEventTypes.CheckpointError)]
// Custom events are handled via registry or explicit derivation if needed
public abstract class AgenticUIEvent : WorkflowEvent
{
    /// <summary>
    /// The timestamp of the event.
    /// </summary>
    [JsonPropertyName("timestamp")]
    public DateTimeOffset Timestamp { get; set; } = DateTimeOffset.UtcNow;
}
