// Copyright (c) Microsoft. All rights reserved.

using System.Text.Json.Serialization;

namespace Microsoft.Agents.AI.Workflows.AgenticUI.Events;

/// <summary>
/// Event emitted when an agent produces an update (streaming or full response).
/// </summary>
public class AgentUpdateUIEvent : AgenticUIEvent
{
    [JsonPropertyName("executor_id")]
    public string ExecutorId { get; set; } = string.Empty;

    [JsonPropertyName("update")]
    public object? Update { get; set; }
}
