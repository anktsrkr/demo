// Copyright (c) Microsoft. All rights reserved.

using System.Text.Json.Serialization;

namespace Microsoft.Agents.AI.Workflows.AgenticUI.Events;

/// <summary>
/// Represents a single unit of work (goal/todo) in the agent's plan.
/// </summary>
public class AgentTodo
{
    [JsonPropertyName("description")]
    public string Description { get; set; } = string.Empty;

    [JsonPropertyName("executor")]
    public string? Executor { get; set; }

    [JsonPropertyName("status")]
    public string Status { get; set; } = "pending";
}

/// <summary>
/// Event emitted when the agent starts a planning phase.
/// </summary>
public class AgentPlanningStartEvent : AgenticUIEvent
{
    [JsonPropertyName("plan_id")]
    public string? PlanId { get; set; }

    [JsonPropertyName("goals")]
    public List<AgentTodo> Todos { get; set; } = [];
}

/// <summary>
/// Event emitted for each step in the agent's plan.
/// </summary>
public class AgentPlanningStepEvent : AgenticUIEvent
{
    [JsonPropertyName("plan_id")]
    public string? PlanId { get; set; }

    [JsonPropertyName("action")]
    public string Action { get; set; } = string.Empty;

    [JsonPropertyName("reasoning")]
    public string? Reasoning { get; set; }

    [JsonPropertyName("goal_index")]
    public int? GoalIndex { get; set; }

    [JsonPropertyName("goal_status")]
    public string? GoalStatus { get; set; }
}

/// <summary>
/// Event emitted when the agent finishes planning.
/// </summary>
public class AgentPlanningEndEvent : AgenticUIEvent
{
    [JsonPropertyName("plan_id")]
    public string? PlanId { get; set; }

    [JsonPropertyName("final_plan")]
    public string? FinalPlan { get; set; }
}
