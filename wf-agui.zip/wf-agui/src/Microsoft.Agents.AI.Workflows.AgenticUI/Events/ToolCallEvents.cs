// Copyright (c) Microsoft. All rights reserved.

using System.Text.Json.Serialization;

namespace Microsoft.Agents.AI.Workflows.AgenticUI.Events;

/// <summary>
/// Event emitted when a tool call starts.
/// </summary>
public class ToolCallStartEvent : AgenticUIEvent
{
    [JsonPropertyName("tool_call_id")]
    public string ToolCallId { get; set; } = string.Empty;

    [JsonPropertyName("tool_name")]
    public string ToolName { get; set; } = string.Empty;
}

/// <summary>
/// Event emitted when tool call arguments are streamed (delta update).
/// </summary>
public class ToolCallArgsEvent : AgenticUIEvent
{
    [JsonPropertyName("tool_call_id")]
    public string ToolCallId { get; set; } = string.Empty;

    [JsonPropertyName("args_delta")]
    public string ArgsDelta { get; set; } = string.Empty;
}

/// <summary>
/// Event emitted when tool call content generation ends.
/// </summary>
public class ToolCallEndEvent : AgenticUIEvent
{
    [JsonPropertyName("tool_call_id")]
    public string ToolCallId { get; set; } = string.Empty;
}

/// <summary>
/// Event emitted when the tool execution completes with a result.
/// </summary>
public class ToolCallResultEvent : AgenticUIEvent
{
    [JsonPropertyName("tool_call_id")]
    public string ToolCallId { get; set; } = string.Empty;

    [JsonPropertyName("result")]
    public object? Result { get; set; }
}
