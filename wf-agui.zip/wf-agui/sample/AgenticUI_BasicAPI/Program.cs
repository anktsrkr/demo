using AgenticUI_BasicAPI;
using AgenticUI_BasicAPI.Persistence;
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Hosting.AgenticUI.AspNetCore;
using Microsoft.Agents.AI.Workflows;
using Microsoft.Agents.AI.Workflows.AgenticUI;
using Microsoft.Agents.AI.Workflows.Checkpointing;
using Microsoft.Extensions.AI;
using OpenAI;
using System.ClientModel;
using System.Text.Json;
using Microsoft.Agents.AI.Workflows.AgenticUI.Checkpointing;

var builder = WebApplication.CreateBuilder(args);

// Add services
builder.Services.AddHttpClient();
builder.Services.AddSingleton<AmadeusService>();

// Configure Checkpointing
var store = new FileCheckpointStore("checkpoints");
builder.Services.AddSingleton<ICheckpointStore<JsonElement>>(store);

// Core Framework CheckpointManager
builder.Services.AddSingleton<Microsoft.Agents.AI.Workflows.CheckpointManager>(sp =>
{
    return Microsoft.Agents.AI.Workflows.CheckpointManager.CreateJson(store);
});

// Agentic UI CheckpointManager (wraps the store)
builder.Services.AddAgenticUICheckpointing();
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

// Configure OpenAI client
var apiKey = builder.Configuration["OpenAI:ApiKey"] ?? "sk-eoe4iyqjyzdxzfs3bd85w5641rayam7dblhrvlgjxyyn743d"; // Use env var or default
var apiEndpoint = builder.Configuration["OpenAI:Endpoint"] ?? "http://127.0.0.1:11435/v1/";

var chatClient = new OpenAIClient(new ApiKeyCredential(apiKey), new OpenAIClientOptions
{
    Endpoint = new Uri(apiEndpoint),
    NetworkTimeout = TimeSpan.FromSeconds(600)
});

var app = builder.Build();
app.UseCors();

// Register different workflows for testing
//var basicWorkflow = BasicWorkflow.Create();
//var simpleAgentWorkflow = SimpleAgentWorkflow.Create(chatClient);
//var agentWithToolsWorkflow = FunctionToolsWorkflow.Create(chatClient);
//var writerCriticWorkflow = WriterCriticWorkflow.Create(chatClient);
//var multiAgentWorkflow = MultiAgentWorkflow.Create(chatClient);
//var parallelAgentWorkflow = ParallelAgentWorkflow.Create(chatClient);
//var conditionalRoutingWorkflow = ConditionalRoutingWorkflow.Create(chatClient);
//var qaWorkflow = QualityAssuranceWorkflow.Create(chatClient);
//var streamingToolWorkflow = FunctionToolsStreamingWorkflow.Create(chatClient);
//var travelPlannerWorkflow = TravelPlannerWorkflow.Create(chatClient);
//var smartResearchWorkflow = SmartResearchWorkflow.Create(chatClient);
//var todoWorkflow = TodoGraphWorkflow.Create(chatClient);
//var toolOutputYieldingWorkflow = ToolOutputYieldingWorkflow.Create(chatClient);
// Get instances from service provider
var amadeusService = app.Services.GetRequiredService<AmadeusService>();

var travelAgentWithTodosWorkflow = TravelAgentTodosWorkflow.Create(chatClient, amadeusService);

// Map different endpoints for different workflows
//app.MapAgenticUI("/api/agent", simpleAgentWorkflow);
//app.MapAgenticUI("/api/basic", basicWorkflow);
//app.MapAgenticUI("/api/tools", agentWithToolsWorkflow);
//app.MapAgenticUI("/api/writer-critic", writerCriticWorkflow);
//app.MapAgenticUI("/api/multi-agent", multiAgentWorkflow);
//app.MapAgenticUI("/api/parallel", parallelAgentWorkflow);
//app.MapAgenticUI("/api/routing", conditionalRoutingWorkflow);
//app.MapAgenticUI("/api/qa", qaWorkflow);
//app.MapAgenticUI("/api/tools-streaming", streamingToolWorkflow);
//app.MapAgenticUI("/api/travel-planner", travelPlannerWorkflow);
//app.MapAgenticUI("/api/smart-research", smartResearchWorkflow);
//app.MapAgenticUI("/api/todo", todoWorkflow);
//app.MapAgenticUI("/api/tool-output-yielding", toolOutputYieldingWorkflow);
app.MapAgenticUI("/api/travel-todos", travelAgentWithTodosWorkflow);
app.MapAgenticUIThreads("/api/travel-todos/threads");

// Add a simple health check endpoint
app.MapGet("/", () => "AgenticUI Basic API is running!");

app.Run();
