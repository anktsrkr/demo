using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Agents.AI.Workflows;
using Microsoft.Agents.AI.Workflows.Checkpointing;
using Microsoft.Agents.AI.Workflows.AgenticUI.Checkpointing;

namespace AgenticUI_BasicAPI.Persistence;

/// <summary>
/// A file-based implementation of <see cref="ICheckpointStore{TStoreObject}"/> for <see cref="JsonElement"/>.
/// </summary>
public class FileCheckpointStore : ICheckpointStoreWithManagement<JsonElement>
{
    private readonly string _basePath;
    private static readonly JsonSerializerOptions _options = new(JsonSerializerDefaults.Web);

    /// <summary>
    /// Initializes a new instance of the <see cref="FileCheckpointStore"/> class.
    /// </summary>
    /// <param name="basePath">The base directory where checkpoints will be stored.</param>
    public FileCheckpointStore(string basePath)
    {
        _basePath = basePath ?? throw new ArgumentNullException(nameof(basePath));
        if (!Directory.Exists(_basePath))
        {
            Directory.CreateDirectory(_basePath);
        }
    }

    /// <inheritdoc/>
    public async ValueTask<IEnumerable<string>> ListRunsAsync(CancellationToken ct = default)
    {
        if (!Directory.Exists(_basePath))
        {
            return Enumerable.Empty<string>();
        }

        return Directory.GetDirectories(_basePath).Select(Path.GetFileName)!;
    }

    /// <inheritdoc/>
    public async ValueTask DeleteRunCheckpointsAsync(string runId, CancellationToken ct = default)
    {
        var runDir = Path.Combine(_basePath, runId);
        if (Directory.Exists(runDir))
        {
            Directory.Delete(runDir, true);
        }
    }

    /// <inheritdoc/>
    public async ValueTask<bool> DeleteCheckpointAsync(string checkpointId, CancellationToken ct = default)
    {
        // For simplicity, we search for the checkpoint in all run directories
        foreach (var runDir in Directory.GetDirectories(_basePath))
        {
            var checkpointPath = Path.Combine(runDir, $"{checkpointId}.json");
            if (File.Exists(checkpointPath))
            {
                File.Delete(checkpointPath);
                return true;
            }
        }
        return false;
    }

    /// <inheritdoc/>
    public async ValueTask<CheckpointInfo> CreateCheckpointAsync(string runId, JsonElement value, CheckpointInfo? parent = null)
    {
        var runDir = Path.Combine(_basePath, runId);
        if (!Directory.Exists(runDir))
        {
            Directory.CreateDirectory(runDir);
        }

        var key = new CheckpointInfo(runId, Guid.NewGuid().ToString("N"));
        var checkpointPath = Path.Combine(runDir, $"{key.CheckpointId}.json");

        var entry = new CheckpointEntry
        {
            Info = key,
            ParentId = parent?.CheckpointId,
            Value = value
        };

        var json = JsonSerializer.Serialize(entry, _options);
        await File.WriteAllTextAsync(checkpointPath, json).ConfigureAwait(false);

        return key;
    }

    /// <inheritdoc/>
    public async ValueTask<JsonElement> RetrieveCheckpointAsync(string runId, CheckpointInfo key)
    {
        var checkpointPath = Path.Combine(_basePath, runId, $"{key.CheckpointId}.json");
        if (!File.Exists(checkpointPath))
        {
            throw new KeyNotFoundException($"Checkpoint {key.CheckpointId} not found for run {runId}");
        }

        var json = await File.ReadAllTextAsync(checkpointPath).ConfigureAwait(false);
        var entry = JsonSerializer.Deserialize<CheckpointEntry>(json, _options);

        return entry?.Value ?? throw new InvalidOperationException("Failed to deserialize checkpoint.");
    }

    /// <inheritdoc/>
    public async ValueTask<IEnumerable<CheckpointInfo>> RetrieveIndexAsync(string runId, CheckpointInfo? withParent = null)
    {
        var runDir = Path.Combine(_basePath, runId);
        if (!Directory.Exists(runDir))
        {
            return Enumerable.Empty<CheckpointInfo>();
        }

        var files = Directory.GetFiles(runDir, "*.json");
        var result = new List<CheckpointInfo>();

        foreach (var file in files)
        {
            try
            {
                var json = await File.ReadAllTextAsync(file).ConfigureAwait(false);
                var entry = JsonSerializer.Deserialize<CheckpointEntry>(json, _options);
                if (entry != null)
                {
                    if (withParent == null || entry.ParentId == withParent.CheckpointId)
                    {
                        result.Add(entry.Info);
                    }
                }
            }
            catch (Exception)
            {
                // Skip invalid or corrupted files
                continue;
            }
        }

        return result;
    }

    private class CheckpointEntry
    {
        public CheckpointInfo Info { get; set; } = null!;
        public string? ParentId { get; set; }
        public JsonElement Value { get; set; }
    }
}
