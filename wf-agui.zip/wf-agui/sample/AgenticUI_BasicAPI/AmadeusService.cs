using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace AgenticUI_BasicAPI
{
    public class AmadeusService
    {
        private readonly HttpClient _httpClient;
        private readonly string _clientId;
        private readonly string _clientSecret;
        private readonly string _baseUrl;
        private string? _accessToken;
        private DateTime _tokenExpiry = DateTime.MinValue;

        public AmadeusService(HttpClient httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient;
            _clientId = configuration["Amadeus:ClientId"] ?? throw new ArgumentNullException("Amadeus:ClientId");
            _clientSecret = configuration["Amadeus:ClientSecret"] ?? throw new ArgumentNullException("Amadeus:ClientSecret");
            _baseUrl = configuration["Amadeus:BaseUrl"] ?? "https://test.api.amadeus.com";
        }

        private async Task EnsureTokenAsync()
        {
            if (_accessToken != null && DateTime.UtcNow < _tokenExpiry)
            {
                return;
            }

            var request = new HttpRequestMessage(HttpMethod.Post, $"{_baseUrl}/v1/security/oauth2/token");
            var body = new FormUrlEncodedContent(new[]
            {
                new KeyValuePair<string, string>("grant_type", "client_credentials"),
                new KeyValuePair<string, string>("client_id", _clientId),
                new KeyValuePair<string, string>("client_secret", _clientSecret)
            });
            request.Content = body;

            var response = await _httpClient.SendAsync(request);
            response.EnsureSuccessStatusCode();

            var json = await response.Content.ReadAsStringAsync();
            using var doc = JsonDocument.Parse(json);
            var root = doc.RootElement;

            _accessToken = root.GetProperty("access_token").GetString();
            var expiresIn = root.GetProperty("expires_in").GetInt32();
            _tokenExpiry = DateTime.UtcNow.AddSeconds(expiresIn - 60); // Buffer of 60 seconds
        }

        public async Task<JsonElement> SearchFlightsAsync(string origin, string destination, string departureDate, string? returnDate = null, int adults = 1)
        {
            await EnsureTokenAsync();

            var url = $"{_baseUrl}/v2/shopping/flight-offers?originLocationCode={origin}&destinationLocationCode={destination}&departureDate={departureDate}&adults={adults}";
            if (!string.IsNullOrEmpty(returnDate))
            {
                url += $"&returnDate={returnDate}";
            }

            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _accessToken);

            var response = await _httpClient.SendAsync(request);
            response.EnsureSuccessStatusCode();

            var json = await response.Content.ReadAsStringAsync();
            return JsonDocument.Parse(json).RootElement;
        }

        public async Task<JsonElement> GetHotelIdsAsync(string cityCode)
        {
            await EnsureTokenAsync();

            var url = $"{_baseUrl}/v1/reference-data/locations/hotels/by-city?cityCode={cityCode}";
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _accessToken);

            var response = await _httpClient.SendAsync(request);
            response.EnsureSuccessStatusCode();

            var json = await response.Content.ReadAsStringAsync();
            return JsonDocument.Parse(json).RootElement;
        }

        public async Task<JsonElement> GetHotelOffersAsync(string hotelIds, int adults = 1)
        {
            await EnsureTokenAsync();

            var url = $"{_baseUrl}/v3/shopping/hotel-offers?hotelIds={hotelIds}&adults={adults}";
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _accessToken);

            var response = await _httpClient.SendAsync(request);
            response.EnsureSuccessStatusCode();

            var json = await response.Content.ReadAsStringAsync();
            return JsonDocument.Parse(json).RootElement;
        }

        public async Task<JsonElement> GetSafetyDataAsync(double latitude, double longitude)
        {
            await EnsureTokenAsync();

            var url = $"{_baseUrl}/v1/safety/safety-rated-locations?latitude={latitude}&longitude={longitude}";
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _accessToken);

            var response = await _httpClient.SendAsync(request);
            response.EnsureSuccessStatusCode();

            var json = await response.Content.ReadAsStringAsync();
            return JsonDocument.Parse(json).RootElement;
        }

        public async Task<JsonElement> GetActivitiesAsync(double latitude, double longitude)
        {
            await EnsureTokenAsync();

            var url = $"{_baseUrl}/v1/shopping/activities?latitude={latitude}&longitude={longitude}";
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _accessToken);

            var response = await _httpClient.SendAsync(request);
            response.EnsureSuccessStatusCode();

            var json = await response.Content.ReadAsStringAsync();
            return JsonDocument.Parse(json).RootElement;
        }

        public async Task<JsonElement> GetTransferOffersAsync(string startLocationCode, string endCityName, string startDateTime, int passengers = 2)
        {
            await EnsureTokenAsync();

            var url = $"{_baseUrl}/v1/shopping/transfer-offers";
            var request = new HttpRequestMessage(HttpMethod.Post, url);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _accessToken);

            var body = new
            {
                startLocationCode = startLocationCode,
                endCityName = endCityName,
                transferType = "PRIVATE",
                startDateTime = startDateTime,
                passengers = passengers
            };

            request.Content = new StringContent(JsonSerializer.Serialize(body), System.Text.Encoding.UTF8, "application/json");

            var response = await _httpClient.SendAsync(request);
            response.EnsureSuccessStatusCode();

            var json = await response.Content.ReadAsStringAsync();
            return JsonDocument.Parse(json).RootElement;
        }
    }
}
