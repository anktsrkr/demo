using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Workflows;
using Microsoft.Agents.AI.Workflows.AgenticUI;
using Microsoft.Extensions.AI;
using OpenAI;

namespace AgenticUI_BasicAPI
{
    public static class MultiAgentWorkflow
    {
        public static Workflow Create(OpenAIClient chatClient)
        {
            var client = chatClient.GetChatClient("qwen3-4b").AsIChatClient();

            // Create specialized agents
            var researched = new ChatClientAgent(
                client,
                name: "Researcher",
                instructions: "You are a research expert. Analyze the topic and provide key insights, facts, and background information."
            );

            var analyst = new ChatClientAgent(
                client,
                name: "Analyst",
                instructions: "You are a data analyst. Take research findings and identify patterns, trends, and implications."
            );

            var synthesizer = new ChatClientAgent(
                client,
                name: "Synthesizer",
                instructions: "You are a content synthesizer. Take analysis and create a clear, comprehensive summary with actionable insights."
            );

            Func<string, IWorkflowContext, ValueTask<string>> handler = async (input, context) =>
            {
                var planId = "MultiAgentPipeline_Plan";

                // Step 1: Research
                await context.EmitPlanningStepAsync("Research phase: Gathering information", planId: planId);
                var researchOutput = await researched.RunAsync(new List<ChatMessage> { new ChatMessage(ChatRole.User, input) });

                // Step 2: Analysis
                await context.EmitPlanningStepAsync("Analysis phase: Processing findings", planId: planId);
                var analysisOutput = await analyst.RunAsync(new List<ChatMessage> { new ChatMessage(ChatRole.User, $"Analyze these findings:\n{researchOutput}") });

                // Step 3: Synthesis
                await context.EmitPlanningStepAsync("Synthesis phase: Creating final report", planId: planId);
                var finalOutput = await synthesizer.RunAsync(new List<ChatMessage> { new ChatMessage(ChatRole.User, $"Synthesize this analysis:\n{analysisOutput}") });

                return finalOutput.ToString();
            };

            return new WorkflowBuilder(handler.BindAsExecutor("MultiAgentPipeline")).Build();
        }
    }
}