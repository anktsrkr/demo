using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Workflows;
using Microsoft.Agents.AI.Workflows.AgenticUI;
using Microsoft.Extensions.AI;
using OpenAI;

namespace AgenticUI_BasicAPI
{
    public static class ParallelAgentWorkflow
    {
        public static Workflow Create(OpenAIClient chatClient)
        {
            var client = chatClient.GetChatClient("qwen3-4b").AsIChatClient();

            var prosAgent = new ChatClientAgent(client, name: "ProsExpert", instructions: "List all advantages and benefits.");
            var consAgent = new ChatClientAgent(client, name: "ConsExpert", instructions: "List all disadvantages and risks.");
            var feasibilityAgent = new ChatClientAgent(client, name: "FeasibilityExpert", instructions: "Assess feasibility and implementation challenges.");

            Func<string, IWorkflowContext, ValueTask<string>> handler = async (input, context) =>
            {
                var planId = "ParallelAnalysis_Plan";
                await context.EmitPlanningStepAsync("Launching parallel agent analysis", planId: planId);

                // Execute agents in parallel
                var prosTask = prosAgent.RunAsync(new List<ChatMessage> { new ChatMessage(ChatRole.User, $"Topic: {input}") });
                var consTask = consAgent.RunAsync(new List<ChatMessage> { new ChatMessage(ChatRole.User, $"Topic: {input}") });
                var feasibilityTask = feasibilityAgent.RunAsync(new List<ChatMessage> { new ChatMessage(ChatRole.User, $"Topic: {input}") });

                await Task.WhenAll(prosTask, consTask, feasibilityTask);

                var prosResult = await prosTask;
                var consResult = await consTask;
                var feasibilityResult = await feasibilityTask;

                await context.EmitPlanningStepAsync("Aggregating parallel results", planId: planId);

                var result = $"=== PROS ===\n{prosResult}\n\n=== CONS ===\n{consResult}\n\n=== FEASIBILITY ===\n{feasibilityResult}";
                return result;
            };

            return new WorkflowBuilder(handler.BindAsExecutor("ParallelAnalysis")).Build();
        }
    }
}