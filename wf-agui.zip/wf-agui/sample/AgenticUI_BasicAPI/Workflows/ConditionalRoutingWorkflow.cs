using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Workflows;
using Microsoft.Agents.AI.Workflows.AgenticUI;
using Microsoft.Extensions.AI;
using OpenAI;

namespace AgenticUI_BasicAPI
{
    public static class ConditionalRoutingWorkflow
    {
        public static Workflow Create(OpenAIClient chatClient)
        {
            var client = chatClient.GetChatClient("qwen3-4b").AsIChatClient();

            var router = new ChatClientAgent(
                client,
                name: "Router",
                instructions: "Analyze the user query and respond with ONLY the category: TECHNICAL, BUSINESS, or CREATIVE"
            );

            var technicalAgent = new ChatClientAgent(client, name: "Technical", instructions: "You are a technical expert. Provide detailed technical solutions.");
            var businessAgent = new ChatClientAgent(client, name: "Business", instructions: "You are a business strategist. Provide business insights and strategy.");
            var creativeAgent = new ChatClientAgent(client, name: "Creative", instructions: "You are a creative director. Provide innovative and creative solutions.");

            Func<string, IWorkflowContext, ValueTask<string>> handler = async (input, context) =>
            {
                var planId = "ConditionalRouting_Plan";

                // Route based on category
                await context.EmitPlanningStepAsync("Analyzing query category", planId: planId);
                var categoryResponse = await router.RunAsync(new List<ChatMessage> { new ChatMessage(ChatRole.User, input) });
                var category = categoryResponse.ToString().Trim().ToUpper();

                await context.EmitPlanningStepAsync($"Routing to {category} specialist", planId: planId);

                var agentResponse = category switch
                {
                    "TECHNICAL" => await technicalAgent.RunAsync(new List<ChatMessage> { new ChatMessage(ChatRole.User, input) }),
                    "BUSINESS" => await businessAgent.RunAsync(new List<ChatMessage> { new ChatMessage(ChatRole.User, input) }),
                    "CREATIVE" => await creativeAgent.RunAsync(new List<ChatMessage> { new ChatMessage(ChatRole.User, input) }),
                    _ => await technicalAgent.RunAsync(new List<ChatMessage> { new ChatMessage(ChatRole.User, input) }) // Default
                };

                return agentResponse.ToString();
            };

            return new WorkflowBuilder(handler.BindAsExecutor("ConditionalRouting")).Build();
        }
    }
}