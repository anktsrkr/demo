using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Workflows;
using Microsoft.Agents.AI.Workflows.AgenticUI;
using Microsoft.Agents.AI.Workflows.AgenticUI.Events;
using Microsoft.Extensions.AI;
using OpenAI;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace AgenticUI_BasicAPI
{
    public static class SmartResearchWorkflow
    {
        public static Workflow Create(OpenAIClient chatClient)
        {
            var client = chatClient.GetChatClient("qwen3-4b").AsIChatClient();

            var planner = new ResearchPlannerNode(client);
            var researcher = new ResearcherNode(client);
            var critic = new CriticNode(client);
            var finalizer = new ReportFinalizerNode(client);

            return new WorkflowBuilder(planner)
                .AddEdge(planner, researcher)
                .AddEdge(researcher, critic)
                .AddSwitch(critic, sw => sw
                    .AddCase<SmartResearchState>(s => s?.NeedsRevision == true && s?.IterationCount < 3, researcher)
                    .AddCase<SmartResearchState>(s => s?.NeedsRevision == false || s?.IterationCount >= 3, finalizer))
                .WithOutputFrom(finalizer)
                .Build();
        }

        internal class SmartResearchState
        {
            public string UserQuery { get; set; } = string.Empty;
            public string[] Goals { get; set; } = [];
            public string CurrentFindings { get; set; } = string.Empty;
            public string Feedback { get; set; } = string.Empty;
            public bool NeedsRevision { get; set; }
            public int IterationCount { get; set; }
            public string? PlanId { get; set; }
        }

        internal class ResearchPlannerNode : Executor<string>
        {
            private readonly AIAgent _agent;

            public ResearchPlannerNode(IChatClient chatClient) : base("Planner")
            {
                _agent = new ChatClientAgent(
                    chatClient,
                    name: "ResearchPlanner",
                    instructions: "You are a research coordinator. Based on the user query, create a specific research plan. Output ONLY a semicolon-separated list of research goals (e.g., 'Goal1;Goal2;Goal3')."
                );
            }

            public override async ValueTask HandleAsync(string message, IWorkflowContext context, CancellationToken ct = default)
            {
                var planId = Guid.NewGuid().ToString("N");
                await context.EmitPlanningStepAsync("Creating Research Plan", $"Analyzing query: {message}", planId: planId, ct: ct);

                var response = await _agent.RunAsync(message);
                var goals = response.ToString().Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

                var todos = goals.Select(g => new AgentTodo { Description = g }).ToList();
                await context.EmitPlanningStartAsync(todos, planId: planId, ct: ct);
                await context.EmitPlanningStepAsync("Plan Initialized", $"Research goals: {string.Join(", ", goals)}", planId: planId, ct: ct);

                await context.SendMessageAsync(new SmartResearchState
                {
                    UserQuery = message,
                    Goals = goals,
                    IterationCount = 0,
                    PlanId = planId
                }, ct);
            }
        }

        internal class ResearcherNode : Executor<SmartResearchState>
        {
            private readonly AIAgent _agent;

            public ResearcherNode(IChatClient chatClient) : base("Researcher")
            {
                // Define specialized tools
                static string WebSearch([Description("The search query")] string query)
                    => $"[Search Result for '{query}']: Comprehensive info about the topic found. Includes historical data, current trends, and key players.";

                static string FinanceData([Description("Company or Market symbol")] string symbol)
                    => $"[Finance Data for '{symbol}']: Price: $150.25 (+1.2%), Market Cap: $2.1T, P/E Ratio: 25.4. Recent news suggests bullish sentiment.";

                _agent = new ChatClientAgent(
                    chatClient,
                    name: "Researcher",
                    instructions: "You are an expert researcher. Use available tools to gather detailed information based on the research plan. Provide a detailed summary of your findings.",
                    tools: [AIFunctionFactory.Create(WebSearch), AIFunctionFactory.Create(FinanceData)]
                );
            }

            public override async ValueTask HandleAsync(SmartResearchState state, IWorkflowContext context, CancellationToken ct = default)
            {
                state.IterationCount++;

                await context.EmitPlanningStepAsync($"Phase {state.IterationCount}: Executing Research", $"Searching for information related to: {state.UserQuery}", planId: state.PlanId, ct: ct);

                var researchInput = string.IsNullOrEmpty(state.CurrentFindings)
                    ? state.UserQuery
                    : $"Original Input: {state.UserQuery}\nPrevious Findings: {state.CurrentFindings}\nFeedback: {state.Feedback}\nExpand on missing areas.";

                var response = await _agent.RunAsync(researchInput);
                state.CurrentFindings = response.ToString();

                await context.EmitPlanningStepAsync($"Research Phase {state.IterationCount} Complete", "Information gathered from tools.", planId: state.PlanId, ct: ct);
                await context.SendMessageAsync(state, ct);
            }
        }

        internal class CriticNode : Executor<SmartResearchState>
        {
            private readonly AIAgent _agent;

            public CriticNode(IChatClient chatClient) : base("Critic")
            {
                _agent = new ChatClientAgent(
                    chatClient,
                    name: "Critic",
                    instructions: "You are a picky editor. Review the research findings. If anything is missing or unclear, respond with 'NEEDS_REVISION: [feedback]'. If it is excellent, respond with 'APPROVED'."
                );
            }

            public override async ValueTask HandleAsync(SmartResearchState state, IWorkflowContext context, CancellationToken ct = default)
            {
                await context.EmitPlanningStepAsync("Reviewing Quality", "Critic is evaluating the research findings...", planId: state.PlanId, ct: ct);

                var response = await _agent.RunAsync(state.CurrentFindings);
                var reviewText = response.ToString();

                if (reviewText.StartsWith("APPROVED", StringComparison.OrdinalIgnoreCase))
                {
                    state.NeedsRevision = false;
                    await context.EmitPlanningStepAsync("Research Approved", "The findings meet the quality standards.", planId: state.PlanId, ct: ct);
                }
                else
                {
                    state.NeedsRevision = true;
                    state.Feedback = reviewText.Replace("NEEDS_REVISION:", "").Trim();
                    await context.EmitPlanningStepAsync("Iteration Required", $"Critic Feedback: {state.Feedback}", planId: state.PlanId, ct: ct);
                }

                await context.SendMessageAsync(state, ct);
            }
        }

        internal class ReportFinalizerNode : Executor<SmartResearchState>
        {
            private readonly AIAgent _agent;

            public ReportFinalizerNode(IChatClient chatClient) : base("Finalizer")
            {
                _agent = new ChatClientAgent(
                    chatClient,
                    name: "Summarizer",
                    instructions: "You are a professional technical writer. Take the research findings and create a polished, comprehensive report with clear sections and insights."
                );
            }

            public override async ValueTask HandleAsync(SmartResearchState state, IWorkflowContext context, CancellationToken ct = default)
            {
                await context.EmitPlanningStepAsync("Finalizing Report", "Synthesizing research into final document...", planId: state.PlanId, ct: ct);

                var response = await _agent.RunAsync(state.CurrentFindings);
                var finalReport = response.ToString();

                await context.EmitPlanningEndAsync("Smart Research Complete", planId: state.PlanId, ct: ct);
                await context.YieldOutputAsync(finalReport, ct);
            }
        }
    }
}