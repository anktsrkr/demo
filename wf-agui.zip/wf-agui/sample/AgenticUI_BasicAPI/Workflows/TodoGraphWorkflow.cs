using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Workflows;
using Microsoft.Agents.AI.Workflows.AgenticUI;
using Microsoft.Agents.AI.Workflows.AgenticUI.Events;
using Microsoft.Extensions.AI;
using OpenAI;
using System.Text;

namespace AgenticUI_BasicAPI
{
    public static class TodoGraphWorkflow
    {
        public static Workflow Create(OpenAIClient chatClient)
        {
            var client = chatClient.GetChatClient("gpt-3.5-turbo").AsIChatClient();

            var planner = new TodoPlannerNode(client);
            var executor = new TodoExecutorNode(client);
            var finalizer = new TodoFinalizerNode();

            return new WorkflowBuilder(planner)
                .AddEdge(planner, executor)
                .AddSwitch(executor, sw => sw
                    .AddCase<TodoState>(s => s?.CurrentGoalIndex < s?.Goals.Count, executor)
                    .AddCase<TodoState>(s => s?.CurrentGoalIndex >= s?.Goals.Count, finalizer))
                .WithOutputFrom(finalizer)
                .Build();
        }

        internal class TodoState
        {
            public string Input { get; set; } = string.Empty;
            public List<string> Goals { get; set; } = [];
            public int CurrentGoalIndex { get; set; }
            public List<string> Results { get; set; } = [];
            public string? PlanId { get; set; }
        }

        internal class TodoPlannerNode : Executor<string>
        {
            private readonly AIAgent _agent;

            public TodoPlannerNode(IChatClient chatClient) : base("TodoPlanner")
            {
                _agent = new ChatClientAgent(
                    chatClient,
                    name: "TodoPlanner",
                    instructions: "You are a task planner. Based on user input, break down the request into 3-5 clear, actionable goals. Output ONLY a semicolon-separated list of goals."
                );
            }

            public override async ValueTask HandleAsync(string input, IWorkflowContext context, CancellationToken ct = default)
            {
                var planId = Guid.NewGuid().ToString("N");
                await context.EmitPlanningStepAsync("Planning", $"Analyzing: {input}", planId: planId, ct: ct);

                var response = await _agent.RunAsync(input);
                var goals = response.ToString().Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();

                var todos = goals.Select(g => new AgentTodo { Description = g }).ToList();
                await context.EmitPlanningStartAsync(todos, planId: planId, ct: ct);
                await context.EmitPlanningStepAsync("Goals Identified", $"Plan: {string.Join(", ", goals)}", planId: planId, ct: ct);

                await context.SendMessageAsync(new TodoState
                {
                    Input = input,
                    Goals = goals,
                    CurrentGoalIndex = 0,
                    PlanId = planId
                }, ct);
            }
        }

        internal class TodoExecutorNode : Executor<TodoState>
        {
            private readonly AIAgent _agent;

            public TodoExecutorNode(IChatClient chatClient) : base("TodoExecutor")
            {
                _agent = new ChatClientAgent(
                    chatClient,
                    name: "TodoExecutor",
                    instructions: "You are a task executor. Complete the specific goal provided. Be concise."
                );
            }

            public override async ValueTask HandleAsync(TodoState state, IWorkflowContext context, CancellationToken ct = default)
            {
                var goal = state.Goals[state.CurrentGoalIndex];

                // 1. Mark as Executing
                await context.EmitPlanningStepAsync(
                    action: $"Executing Goal {state.CurrentGoalIndex + 1}",
                    reasoning: $"Working on: {goal}",
                    goalIndex: state.CurrentGoalIndex,
                    goalStatus: "executing",
                    planId: state.PlanId,
                    ct: ct
                );

                // Simulate some work
                List<AgentRunResponseUpdate> updates = [];

                await foreach (var update in _agent.RunStreamingAsync($"Goal: {goal}"))
                {
                    updates.Add(update);
                    await context.AddEventAsync(new AgentRunUpdateEvent("TodoExecutor", update), ct);
                }

                var response = updates.ToAgentRunResponse().ToString();
                state.Results.Add(response);


                // 2. Mark as Completed
                await context.EmitPlanningStepAsync(
                    action: $"Completed Goal {state.CurrentGoalIndex + 1}",
                    reasoning: $"Result: {response}",
                    goalIndex: state.CurrentGoalIndex,
                    goalStatus: "completed",
                    planId: state.PlanId,
                    ct: ct
                );

                state.CurrentGoalIndex++;
                await context.SendMessageAsync(state, ct);
            }
        }

        internal class TodoFinalizerNode : Executor<TodoState>
        {
            public TodoFinalizerNode() : base("Finalizer") { }

            public override async ValueTask HandleAsync(TodoState state, IWorkflowContext context, CancellationToken ct = default)
            {
                await context.EmitPlanningEndAsync("All tasks completed.", planId: state.PlanId, ct: ct);

                var finalOutput = new StringBuilder();
                finalOutput.AppendLine("### Todo Execution Summary");
                for (int i = 0; i < state.Goals.Count; i++)
                {
                    finalOutput.AppendLine($"- **{state.Goals[i]}**: {state.Results[i]}");
                }

                await context.YieldOutputAsync(finalOutput.ToString(), ct);
            }
        }
    }
}