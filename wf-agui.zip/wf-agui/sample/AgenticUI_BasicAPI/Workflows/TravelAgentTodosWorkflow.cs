using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Workflows;
using Microsoft.Agents.AI.Workflows.AgenticUI;
using Microsoft.Agents.AI.Workflows.AgenticUI.Events;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.FileSystemGlobbing;
using Microsoft.VisualBasic;
using OpenAI;
using System;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Diagnostics.Metrics;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Text.Json;
// Use an alias to resolve RouteBuilder ambiguity
using WorkflowRouteBuilder = Microsoft.Agents.AI.Workflows.RouteBuilder;

namespace AgenticUI_BasicAPI
{
    public static class TravelAgentTodosWorkflow
    {
        public static Workflow Create(OpenAIClient chatClient, AmadeusService amadeusService)
        {
            var client = chatClient.GetChatClient("moonshotai/kimi-k2-instruct-0905").AsIChatClient();
            var toolset = new AmadeusToolset(amadeusService);

            // 1. Define specialized agents with Tools
            var flightAgent = new ChatClientAgent(client, name: "FlightAgent",
                instructions: "You are a flight booking expert. \n" +
                              "CRITICAL: You MUST use the 'SearchFlights' tool to find REAL flight options. \n" +
                              "CRITICAL:  You must use the provided tools to gather information before generating any final output.Do not output JSON until after tool execution. \n" +
                              "DO NOT invent flight data, prices, or flight numbers. \n" +
                              "If the tool returns no results, state that clearly and do not hallucinate a response. \n" +
                              "Always use 3-letter IATA codes (e.g., 'LON', 'PAR') for the 'origin' and 'destination' parameters. \n" +
                              "After receiving tool results, select the best option and return a structured FlightInfo result containing exactly what the tool provided.",
                tools: [AIFunctionFactory.Create(toolset.SearchFlights)]);

            var hotelAgent = new ChatClientAgent(client, name: "HotelAgent",
                instructions: "You are a hotel booking expert. \n" +
                              "CRITICAL: Use the 'SearchHotels' and 'GetHotelRates' tools to find REAL information. \n" +
                              "Include the 'adults' count when fetching rates. \n" +
                              "DO NOT invent hotels, ratings, or prices. \n" +
                              "Return a list of structured HotelInfo results based ONLY on the tool output.",
                tools: [
                    AIFunctionFactory.Create(toolset.SearchHotels),
                    AIFunctionFactory.Create(toolset.GetHotelRates)
                ]);

            var safetyAgent = new ChatClientAgent(client, name: "SafetyAgent",
                instructions: "You are a safety expert. Use the GetAreaSafety tool to check travel safety ratings. Provide a concise summary.",
                tools: [AIFunctionFactory.Create(toolset.GetAreaSafety)]);

            var activityAgent = new ChatClientAgent(client, name: "ActivityAgent",
                instructions: "You are a local activities expert. Use the GetNearbyActivities tool to find things to do. Provide a concise summary.",
                tools: [AIFunctionFactory.Create(toolset.GetNearbyActivities)]);

            var transferAgent = new ChatClientAgent(client, name: "TransferAgent",
                instructions: "You are a transportation expert. Use the SearchTransfers tool to find airport-to-hotel private transfers. Return a concise summary.",
                tools: [AIFunctionFactory.Create(toolset.SearchTransfers)]);

            var gathererAgent = new ChatClientAgent(client, name: "GathererAgent",
                instructions: @"You are a professional and helpful travel assistant. Your goal is to gather all necessary details for a complete travel plan.
Analyze the user's request and provide a structured 'GatheringStatus' object.

Data points to extract:
1. Origin City (resolve to IATA code, e.g., LON, NYC)
2. Destination City (resolve to IATA code)
3. Departure Date (YYYY-MM-DD)
4. Return Date (YYYY-MM-DD)
5. Number of Passengers (Adults/Children)
6. Total Trip Budget (Decimal, e.g., 5000.00)
7. Preferences (Hotels star rating, Flight cabin class e.g., Economy, Business)
8. Interests (Activities, food, sightseeing, etc.)

Guidelines:
- If any mandatory information (Cities, Dates, Passengers, Budget) is missing or unclear, set 'IsReady' to false and provide a polite 'Message' to the user.
- IMPORTANT: Even if 'IsReady' is false, you SHOULD populate the 'Trip' object with any data you have gathered so far if you are confident in it. This helps track progress.
- Only set 'IsReady' to true when you have enough information to form a solid travel plan.
- When 'IsReady' is true, provide a concise summary of the trip in the 'Message' field and populate the 'Trip' object with all gathered details.");

            // 2. Define executors
            var gatherer = new DataGatheringExecutor(gathererAgent);
            var aggregator = new TravelAggregator();

            // 3. Define the Planning Executor (Dynamic)
            var planner = new PlanningAgentExecutor(client);

            // 4. Create Subworkflows for all agents
            var flightSubworkflow = CreateSubworkflow<FlightInfo>(chatClient, "FlightAgent", flightAgent.Instructions, flightAgent.GetService<ChatOptions>()?.Tools);
            var hotelSubworkflow = CreateSubworkflow<List<HotelInfo>>(chatClient, "HotelAgent", hotelAgent.Instructions, hotelAgent.GetService<ChatOptions>()?.Tools);
            var safetySubworkflow = CreateSubworkflow<string>(chatClient, "SafetyAgent", safetyAgent.Instructions, safetyAgent.GetService<ChatOptions>()?.Tools);
            var activitySubworkflow = CreateSubworkflow<string>(chatClient, "ActivityAgent", activityAgent.Instructions, activityAgent.GetService<ChatOptions>()?.Tools);
            var transferSubworkflow = CreateSubworkflow<string>(chatClient, "TransferAgent", transferAgent.Instructions, transferAgent.GetService<ChatOptions>()?.Tools);

            return new WorkflowBuilder(gatherer)
                .AddEdge<GatheringStatus>(gatherer, planner, status => status?.IsReady ?? false)
                .AddFanOutEdge<List<AgentTodo>>(planner, [
                    flightSubworkflow.BindAsExecutor("FlightSubworkflow"),
                    hotelSubworkflow.BindAsExecutor("HotelSubworkflow"),
                    safetySubworkflow.BindAsExecutor("SafetySubworkflow"),
                    activitySubworkflow.BindAsExecutor("ActivitySubworkflow"),
                    transferSubworkflow.BindAsExecutor("TransferSubworkflow")
                ], (todoList, count) =>
                {
                    if (todoList == null) return Enumerable.Empty<int>();
                    var activeIndices = new List<int>();
                    if (todoList.Any(t => t.Executor == "FlightExecutor")) activeIndices.Add(0);
                    if (todoList.Any(t => t.Executor == "HotelExecutor")) activeIndices.Add(1);
                    if (todoList.Any(t => t.Executor == "SafetyExecutor")) activeIndices.Add(2);
                    if (todoList.Any(t => t.Executor == "ActivityExecutor")) activeIndices.Add(3);
                    if (todoList.Any(t => t.Executor == "TransferExecutor")) activeIndices.Add(4);
                    return activeIndices;
                })
                .AddEdge("FlightSubworkflow", aggregator)
                .AddEdge("HotelSubworkflow", aggregator)
                .AddEdge("SafetySubworkflow", aggregator)
                .AddEdge("ActivitySubworkflow", aggregator)
                .AddEdge("TransferSubworkflow", aggregator)
                .AddEdge<string?>(aggregator, planner, (prompt) => prompt != null)
                .WithOutputFrom(aggregator, gatherer)
                .Build();
        }

        private static Workflow CreateSubworkflow<T>(OpenAIClient chatClient, string agentName, string? instructions, IList<AITool>? tools = null)
        {
            var client = chatClient.GetChatClient("moonshotai/kimi-k2-instruct-0905").AsIChatClient();

            // Discovery Agent: Focuses ONLY on tool execution and raw reporting.
            var discoveryAgent = new ChatClientAgent(client,
                name: $"{agentName}_Discovery",
                instructions: instructions + "\nIMPORTANT: Your task is to gather raw data using your tools and provide a detailed text summary. DO NOT output JSON.",
                tools: tools);

            // Extraction Agent: Focuses ONLY on mapping text to the JSON schema.
            var extractionAgent = new ChatClientAgent(client,
                name: $"{agentName}_Extraction",
                instructions: $"You are a data extraction expert. Take the following raw text and map it to the requested JSON structure: {typeof(T).Name}. " +
                             "Ensure all fields are correctly populated based on the provided text. Output ONLY the JSON object.");

            var discoveryNode = new DiscoveryNode(discoveryAgent);
            var extractionNode = new ExtractionNode<T>(extractionAgent);

            return new WorkflowBuilder(discoveryNode)
                .AddEdge(discoveryNode, extractionNode)
                .WithOutputFrom(extractionNode)
                .Build();
        }

        internal class DiscoveryNode(ChatClientAgent agent) : Executor<List<AgentTodo>, string>("Discovery")
        {
            private readonly ChatClientAgent _agent = agent;

            public override async ValueTask<string> HandleAsync(List<AgentTodo> todos, IWorkflowContext context, CancellationToken ct = default)
            {
                // Find relevant todo for this subworkflow instance
                // Since this is a subworkflow, we might need a way to pass the specific task description.
                // For now, let's assume the first relevant todo is our task.
                var myTask = todos.FirstOrDefault();
                var taskDescription = myTask?.Description ?? "Search for information.";

                await context.EmitPlanningStepAsync("Discovery Starting", $"Searching for: {taskDescription}", ct: ct);

                var response = await _agent.RunAsync(taskDescription, cancellationToken: ct);
                var result = response.ToString();

                await context.EmitPlanningStepAsync("Discovery Complete", "Information gathered from tools.", ct: ct);
                return result;
            }
        }

        internal class ExtractionNode<T>(ChatClientAgent agent) : Executor<string, T>("Extraction")
        {
            private readonly ChatClientAgent _agent = agent;

            public override async ValueTask<T> HandleAsync(string rawText, IWorkflowContext context, CancellationToken ct = default)
            {
                await context.EmitPlanningStepAsync("Finalizing Data", "Mapping results to structured format...", ct: ct);

                var response = await _agent.RunAsync<T>(rawText, cancellationToken: ct);
                var result = response.Result;

                await context.EmitPlanningStepAsync("Extraction Complete", "Data finalized.", ct: ct);
                return result!;
            }
        }

        internal class TripDetails
        {
            public string? Origin { get; set; }
            public string? Destination { get; set; }
            public string? DepartureDate { get; set; }
            public string? ReturnDate { get; set; }
            public int? Passengers { get; set; }
            public decimal? Budget { get; set; }
            public string? Preferences { get; set; }
            public string? Interests { get; set; }
        }

        internal class GatheringStatus
        {
            public bool IsReady { get; set; }
            public string? Message { get; set; }
            public TripDetails? Trip { get; set; }
        }


        internal class WorkflowChatHistory
        {
            public List<ChatMessage> Messages { get; set; } = new();
        }

        internal class FlightInfo
        {
            public string Airline { get; set; } = string.Empty;
            public string FlightNumber { get; set; } = string.Empty;
            public string DepartureAirport { get; set; } = string.Empty;
            public string ArrivalAirport { get; set; } = string.Empty;
            public string DepartureTime { get; set; } = string.Empty;
            public string ArrivalTime { get; set; } = string.Empty;
            public int DurationMinutes { get; set; }
            public string[] Layovers { get; set; } = [];
            public decimal Price { get; set; }
            public string Currency { get; set; } = "USD";
            public int Passengers { get; set; } = 1;
            public bool IsRoundTrip { get; set; }
            public string Summary { get; set; } = string.Empty;
        }

        internal class HotelInfo
        {
            public string HotelName { get; set; } = string.Empty;
            public string Location { get; set; } = string.Empty;
            public int StarRating { get; set; }
            public string RoomType { get; set; } = string.Empty;
            public decimal PricePerNight { get; set; }
            public string Currency { get; set; } = "USD";
            public int Adults { get; set; } = 1;
            public string[] Amenities { get; set; } = [];
            public string Description { get; set; } = string.Empty;
        }

        internal class DataGatheringExecutor(ChatClientAgent agent) : Executor<string, GatheringStatus?>("DataGatherer")
        {
            private readonly ChatClientAgent _agent = agent;

            public override async ValueTask<GatheringStatus?> HandleAsync(string input, IWorkflowContext context, CancellationToken ct = default)
            {
                var accumulatedInfo = await context.ReadStateAsync<string>("accumulated_info", cancellationToken: ct) ?? string.Empty;
                var currentTrip = await context.ReadStateAsync<TripDetails>("trip_details", cancellationToken: ct) ?? new TripDetails();
                var planId = "Gathering_Plan";

                // Persist User Message to History
                var history = await context.ReadStateAsync<WorkflowChatHistory>("workflow_message_store", cancellationToken: ct) ?? new WorkflowChatHistory();
                history.Messages.Add(new ChatMessage(ChatRole.User, input));
                await context.QueueStateUpdateAsync("workflow_message_store", history, cancellationToken: ct);

                var currentRequest = PrepareUserQuery(input, accumulatedInfo, currentTrip);

                await context.EmitPlanningStepAsync("Verifying Trip Details", $"Analyzing request... Received: {input}", planId: planId, ct: ct);

                var response = await _agent.RunAsync<GatheringStatus>(currentRequest, cancellationToken: ct);
                var result = response.Result;

                // Update Trip Details in state even if not ready
                if (result?.Trip != null)
                {
                    await context.QueueStateUpdateAsync("trip_details", result.Trip, cancellationToken: ct);
                }

                if (result != null && result.IsReady)
                {
                    await context.EmitPlanningStepAsync("Validation Complete", "All required details gathered. Handing over to planner.", planId: planId, ct: ct);
                    return result;
                }
                else
                {
                    // Update conversation history
                    var newAccumulated = $"{accumulatedInfo}\nUser: {input}\nAssistant: {result?.Message}";
                    await context.QueueStateUpdateAsync("accumulated_info", newAccumulated, cancellationToken: ct);

                    await context.EmitPlanningStepAsync("Information Missing", $"Still missing details. Current knowledge: {SummarizeTrip(result?.Trip ?? currentTrip)}", planId: planId, ct: ct);
                    await context.EmitPlanningStepAsync("Information Missing", $"Still missing details. Current knowledge: {SummarizeTrip(result?.Trip ?? currentTrip)}", planId: planId, ct: ct);

                    var reply = result?.Message ?? "Could you please provide more details?";
                    await context.YieldOutputAsync(reply, ct); // Direct response to user

                    // Persist Assistant Message to History (for intermediate replies)
                    var history2 = await context.ReadStateAsync<WorkflowChatHistory>("workflow_message_store", cancellationToken: ct) ?? new WorkflowChatHistory();
                    history2.Messages.Add(new ChatMessage(ChatRole.Assistant, reply));
                    await context.QueueStateUpdateAsync("workflow_message_store", history2, cancellationToken: ct);

                    return null;
                }
            }

            private string PrepareUserQuery(string input, string accumulatedInfo, TripDetails currentTrip)
            {
                var contextBuilder = new StringBuilder();
                if (!string.IsNullOrEmpty(accumulatedInfo))
                {
                    contextBuilder.AppendLine("### Previous Conversation Log:");
                    contextBuilder.AppendLine(accumulatedInfo);
                }

                contextBuilder.AppendLine("\n### Currently Gathered Trip Data (Structured):");
                contextBuilder.AppendLine($"- Origin: {currentTrip.Origin ?? "Unknown"}");
                contextBuilder.AppendLine($"- Destination: {currentTrip.Destination ?? "Unknown"}");
                contextBuilder.AppendLine($"- Departure: {currentTrip.DepartureDate ?? "Unknown"}");
                contextBuilder.AppendLine($"- Return: {currentTrip.ReturnDate ?? "Unknown"}");
                contextBuilder.AppendLine($"- Passengers: {currentTrip.Passengers?.ToString() ?? "Unknown"}");
                contextBuilder.AppendLine($"- Budget: {currentTrip.Budget?.ToString("C") ?? "Unknown"}");
                contextBuilder.AppendLine($"- Preferences: {currentTrip.Preferences ?? "None"}");
                contextBuilder.AppendLine($"- Interests: {currentTrip.Interests ?? "None"}");

                return $"{contextBuilder}\n\nUser: {input}";
            }

            private string SummarizeTrip(TripDetails trip)
            {
                var parts = new List<string>();
                if (!string.IsNullOrEmpty(trip.Origin)) parts.Add($"Origin: {trip.Origin}");
                if (!string.IsNullOrEmpty(trip.Destination)) parts.Add($"Dest: {trip.Destination}");
                if (!string.IsNullOrEmpty(trip.DepartureDate)) parts.Add($"Dep: {trip.DepartureDate}");
                return parts.Count > 0 ? string.Join(", ", parts) : "No data yet";
            }
        }


        internal class TravelAggregator : Executor<PortableValue, string?>
        {
            public TravelAggregator() : base("TravelAggregator") { }

            public override async ValueTask<string?> HandleAsync(PortableValue message, IWorkflowContext context, CancellationToken ct = default)
            {
                var combinedResults = await context.ReadStateAsync<List<PortableValue>>("raw_results", cancellationToken: ct) ?? new List<PortableValue>();
                combinedResults.Add(message);
                await context.QueueStateUpdateAsync("raw_results", combinedResults, cancellationToken: ct);

                var plan = await context.ReadStateAsync<List<AgentTodo>>("workflow_plan", cancellationToken: ct) ?? new List<AgentTodo>();
                var expectedAgents = plan.Select(t => t.Executor).Distinct().Count();

                // Wait until we have results from all expected agents
                if (combinedResults.Count >= expectedAgents)
                {
                    var planId = await context.ReadStateAsync<string>("current_plan_id", cancellationToken: ct);
                    var trip = await context.ReadStateAsync<TripDetails>("trip_details", cancellationToken: ct);

                    decimal totalCost = 0;
                    var summaryBuilder = new StringBuilder();

                    var flights = combinedResults.SelectMany(m => m.Is(out List<FlightInfo>? f) && f != null ? f : []).ToList();
                    var hotels = combinedResults.SelectMany(m => m.Is(out List<HotelInfo>? h) && h != null ? h : []).ToList();
                    var strings = combinedResults.Where(m => m.Is<string>(out var s) && !string.IsNullOrEmpty(s) && !s.StartsWith("REPLAN")).Select(m => m.As<string>()).ToList();

                    if (flights.Any())
                    {
                        summaryBuilder.AppendLine($"### Flights Found ({flights.Count})");
                        foreach (var f in flights)
                        {
                            var cost = f.Price * f.Passengers;
                            summaryBuilder.AppendLine($"- {f.Airline} {f.FlightNumber}: {f.DepartureAirport} -> {f.ArrivalAirport}. Price: {f.Price} {f.Currency} x {f.Passengers} passengers. Total: {cost} {f.Currency}");
                            totalCost += cost;
                        }
                    }

                    if (hotels.Any())
                    {
                        summaryBuilder.AppendLine($"\n### Hotels Found ({hotels.Count})");
                        int nights = 1;
                        if (DateTime.TryParse(trip?.DepartureDate, out var dep) && DateTime.TryParse(trip?.ReturnDate, out var ret))
                        {
                            nights = Math.Max(1, (ret - dep).Days);
                        }

                        foreach (var h in hotels)
                        {
                            var cost = h.PricePerNight * nights;
                            summaryBuilder.AppendLine($"- {h.HotelName} ({h.StarRating}*): {h.Location}. {h.RoomType} for {nights} nights. Total: {cost} {h.Currency}");
                            totalCost += cost;
                        }
                    }

                    if (strings.Any())
                    {
                        summaryBuilder.AppendLine("\n### Additional Information");
                        foreach (var s in strings)
                        {
                            summaryBuilder.AppendLine($"- {s}");
                        }
                    }

                    var budget = trip?.Budget ?? decimal.MaxValue;
                    if (totalCost > budget)
                    {
                        await context.EmitPlanningStepAsync("Budget Exceeded", $"Total cost {totalCost} exceeds budget {budget}. Requesting cheaper options.", planId: planId, ct: ct);
                        await context.QueueStateUpdateAsync("raw_results", new List<PortableValue>(), cancellationToken: ct); // Clear for next round

                        return $"REPLAN: The current plan costs {totalCost:C}, which exceeds the budget of {budget:C}. Please generate a new plan with more affordable flights and hotels while keeping the same destination and dates.";
                    }

                    await context.EmitPlanningEndAsync("Travel plans finalized.", planId: planId, ct: ct);

                    // Persist Assistant Message to History
                    var history = await context.ReadStateAsync<WorkflowChatHistory>("workflow_message_store", cancellationToken: ct) ?? new WorkflowChatHistory();
                    history.Messages.Add(new ChatMessage(ChatRole.Assistant, summaryBuilder.ToString()));
                    await context.QueueStateUpdateAsync("workflow_message_store", history, cancellationToken: ct);

                    await context.YieldOutputAsync(summaryBuilder.ToString(), ct);
                    await context.QueueStateUpdateAsync("raw_results", new List<PortableValue>(), cancellationToken: ct); // Reset
                }

                return null;
            }
        }

        internal class PlanningAgentExecutor : Executor
        {
            private readonly ChatClientAgent _agent;

            public PlanningAgentExecutor(IChatClient chatClient) : base("PlanningAgent")
            {
                _agent = new ChatClientAgent(
                    chatClient,
                    name: "Planner",
                    instructions: @"You are a high-level travel planning expert. Your goal is to orchestrate a comprehensive travel itinerary by delegating tasks to specialized agents.

Analyze the trip summary provided and create a logical list of tasks (todos).

### Supported Executors & When to Use Them:
- **'FlightExecutor'**: Use this for all air travel needs. Requires origin, destination, and departure dates.
- **'HotelExecutor'**: Use this for finding and booking accommodation. Focus on the destination city and the duration of stay. Mention any specific preferences like star rating or amenities.
- **'SafetyExecutor'**: Use this to assess the safety and security of the destination. This should be a priority for international travel or if the user expresses safety concerns.
- **'ActivityExecutor'**: Use this to suggest experiences, tours, and attractions at the destination. Consider the user's interests (e.g., food, history, nature).
- **'TransferExecutor'**: Use this for ground transportation, specifically airport-to-hotel private transfers or similar point-to-point bookings.

### Planning Strategy:
1. **Core Logistics**: Always start with Flights and Hotels as they are the foundation of any trip.
2. **Contextual Awareness**: If the destination is unfamiliar or international, include a Safety Check.
3. **Enhancement**: Add Activities and Transfers to complete the itinerary and ensure a smooth experience.
4. **Detail**: Each task description must be detailed enough for the specialized agent to act without further user input. Include all relevant IATA codes, dates, and preferences extracted from the summary."
                );
            }

            protected override WorkflowRouteBuilder ConfigureRoutes(WorkflowRouteBuilder routeBuilder)
            {
                return routeBuilder
                    .AddHandler<string>(HandleAsync)
                    .AddHandler<GatheringStatus>(HandleGatheringStatusAsync);
            }

            public async ValueTask HandleGatheringStatusAsync(GatheringStatus status, IWorkflowContext context, CancellationToken ct = default)
            {
                var currentTrip = status.Trip ?? new TripDetails();
                var preparedQuery = PrepareUserQuery(status.Message ?? "No message", currentTrip);
                await HandleAsync(preparedQuery, context, ct);
            }

            public async ValueTask HandleAsync(string input, IWorkflowContext context, CancellationToken ct = default)
            {
                var planId = Guid.NewGuid().ToString("N");
                await context.QueueStateUpdateAsync("current_plan_id", planId, cancellationToken: ct);

                await context.EmitPlanningStepAsync("Planning Trip", $"Analyzing request: {input}", planId: planId, ct: ct);

                var response = await _agent.RunAsync<List<AgentTodo>>(input, cancellationToken: ct);
                var todos = response.Result ?? [];

                await context.QueueStateUpdateAsync("workflow_plan", todos, cancellationToken: ct);
                await context.EmitPlanningStartAsync(todos, planId: planId, ct: ct);
                await context.EmitPlanningStepAsync("Plan Created", $"Generated {todos.Count} tasks.", planId: planId, ct: ct);

                await context.SendMessageAsync(todos, ct);
            }

            private string PrepareUserQuery(string message, TripDetails trip)
            {
                return $"Trip Summary:\n{message}\n\nDetails:\n" +
                       $"- Origin: {trip.Origin ?? "Unknown"}\n" +
                       $"- Destination: {trip.Destination ?? "Unknown"}\n" +
                       $"- Departure: {trip.DepartureDate ?? "Unknown"}\n" +
                       $"- Return: {trip.ReturnDate ?? "Unknown"}\n" +
                       $"- Passengers: {trip.Passengers?.ToString() ?? "Unknown"}\n" +
                       $"- Budget: {trip.Budget?.ToString("C") ?? "Unknown"}\n" +
                       $"- Preferences: {trip.Preferences ?? "None"}\n" +
                       $"- Interests: {trip.Interests ?? "None"}";
            }
        }

        /// <summary>
        /// A set of tools that agents can use to interact with Amadeus APIs.
        /// </summary>
        internal class AmadeusToolset
        {
            private readonly AmadeusService _service;

            public AmadeusToolset(AmadeusService service)
            {
                _service = service;
            }

            [Description("Search for flights between two airports, with optional return date and number of passengers. Returns a list of available flights. ")]
            public async Task<string> SearchFlights(
                [Description("Origin IATA code (e.g. PAR)")] string origin,
                [Description("Destination IATA code (e.g. LON)")] string destination,
                [Description("Departure date in YYYY-MM-DD format")] string departureDate,
                [Description("Return date in YYYY-MM-DD format (optional)")] string? returnDate = null,
                [Description("Number of adult passengers")] int adults = 1)
            {
                try
                {
                    Console.WriteLine($"[TOOL] SearchFlights: {origin} -> {destination}, date={departureDate}, return={returnDate}, adults={adults}");
                    var result = await _service.SearchFlightsAsync(origin, destination, departureDate, returnDate, adults);

                    if (result.TryGetProperty("data", out var data) && data.ValueKind == JsonValueKind.Array)
                    {
                        var flightList = new List<object>();
                        foreach (var offer in data.EnumerateArray().Take(5))
                        {
                            var price = offer.GetProperty("price");
                            var itinerary = offer.GetProperty("itineraries")[0];
                            var segment = itinerary.GetProperty("segments")[0];

                            flightList.Add(new
                            {
                                Airline = segment.GetProperty("carrierCode").GetString(),
                                FlightNumber = segment.GetProperty("number").GetString(),
                                DepartureAirport = segment.GetProperty("departure").GetProperty("iataCode").GetString(),
                                ArrivalAirport = segment.GetProperty("arrival").GetProperty("iataCode").GetString(),
                                DepartureTime = segment.GetProperty("departure").GetProperty("at").GetString(),
                                ArrivalTime = segment.GetProperty("arrival").GetProperty("at").GetString(),
                                Price = price.GetProperty("total").GetString(),
                                Currency = price.GetProperty("currency").GetString()
                            });
                        }

                        var summary = flightList.Any()
                            ? JsonSerializer.Serialize(flightList, new JsonSerializerOptions { WriteIndented = true })
                            : "No flights found for the specified criteria. Try different dates or nearby airports.";

                        Console.WriteLine($"[TOOL] SearchFlights returned {flightList.Count} flights.");
                        return summary;
                    }

                    return "Received an unexpected response format from the flight service.";
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[TOOL] SearchFlights ERROR: {ex.Message}");
                    return $"Error: The flight search failed ({ex.Message}). Ensure you used valid 3-letter IATA codes and dates.";
                }
            }

            [Description("Search for hotels in a city. Returns a list of hotel IDs.")]
            public async Task<string> SearchHotels(
                [Description("City IATA code (e.g. NYC)")] string cityCode)
            {
                try
                {
                    Console.WriteLine($"[TOOL] SearchHotels: city={cityCode}");
                    var result = await _service.GetHotelIdsAsync(cityCode);
                    if (result.TryGetProperty("data", out var data) && data.ValueKind == JsonValueKind.Array)
                    {
                        var hotels = data.EnumerateArray().Take(10).Select(h => new
                        {
                            Id = h.GetProperty("hotelId").GetString(),
                            Name = h.GetProperty("name").GetString()
                        });
                        return JsonSerializer.Serialize(hotels, new JsonSerializerOptions { WriteIndented = true });
                    }
                    return "No hotels found in this city.";
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[TOOL] SearchHotels ERROR: {ex.Message}");
                    return $"Error: {ex.Message}";
                }
            }

            [Description("Get hotel rates for specific hotel IDs. Returns pricing and availability.")]
            public async Task<string> GetHotelRates(
                [Description("Comma-separated list of hotel IDs")] string hotelIds,
                [Description("Number of adults")] int adults = 1)
            {
                try
                {
                    Console.WriteLine($"[TOOL] GetHotelRates: id={hotelIds}, adults={adults}");
                    var result = await _service.GetHotelOffersAsync(hotelIds, adults);
                    if (result.TryGetProperty("data", out var data) && data.ValueKind == JsonValueKind.Array)
                    {
                        var offers = data.EnumerateArray().Take(5).Select(o => new
                        {
                            HotelId = o.GetProperty("hotel").GetProperty("hotelId").GetString(),
                            HotelName = o.GetProperty("hotel").GetProperty("name").GetString(),
                            Price = o.GetProperty("offers")[0].GetProperty("price").GetProperty("total").GetString(),
                            Currency = o.GetProperty("offers")[0].GetProperty("price").GetProperty("currency").GetString(),
                            RoomType = o.GetProperty("offers")[0].GetProperty("room").GetProperty("typeEstimated").GetProperty("category").GetString()
                        });
                        return JsonSerializer.Serialize(offers, new JsonSerializerOptions { WriteIndented = true });
                    }
                    return "No rates found for these hotels.";
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[TOOL] GetHotelRates ERROR: {ex.Message}");
                    return $"Error: {ex.Message}";
                }
            }

            [Description("Get safety data for a location.")]
            public async Task<string> GetAreaSafety(
                [Description("Latitude")] double latitude,
                [Description("Longitude")] double longitude)
            {
                try
                {
                    Console.WriteLine($"[TOOL] GetAreaSafety: {latitude}, {longitude}");
                    var result = await _service.GetSafetyDataAsync(latitude, longitude);
                    return result.ToString(); // Safety data is usually small enough
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[TOOL] GetAreaSafety ERROR: {ex.Message}");
                    return "Safety data unavailable.";
                }
            }

            [Description("Get nearby activities for a location.")]
            public async Task<string> GetNearbyActivities(
                [Description("Latitude")] double latitude,
                [Description("Longitude")] double longitude)
            {
                try
                {
                    Console.WriteLine($"[TOOL] GetNearbyActivities: {latitude}, {longitude}");
                    var result = await _service.GetActivitiesAsync(latitude, longitude);
                    if (result.TryGetProperty("data", out var data) && data.ValueKind == JsonValueKind.Array)
                    {
                        var activities = data.EnumerateArray().Take(5).Select(a => a.GetProperty("name").GetString());
                        return string.Join(", ", activities);
                    }
                    return "No activities found.";
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[TOOL] GetNearbyActivities ERROR: {ex.Message}");
                    return "Activity data unavailable.";
                }
            }

            [Description("Search for airport-to-hotel private transfers.")]
            public async Task<string> SearchTransfers(
                [Description("Origin location code (e.g. CDG)")] string startLocationCode,
                [Description("Destination city name (e.g. Paris)")] string endCityName,
                [Description("Pickup date and time in ISO format (e.g. 2025-07-10T09:00:00)")] string startDateTime)
            {
                try
                {
                    Console.WriteLine($"[TOOL] SearchTransfers: {startLocationCode} -> {endCityName}");
                    var result = await _service.GetTransferOffersAsync(startLocationCode, endCityName, startDateTime);
                    return result.ToString();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[TOOL] SearchTransfers ERROR: {ex.Message}");
                    return "Transfer search failed.";
                }
            }
        }
    }
}