using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Workflows;
using Microsoft.Agents.AI.Workflows.AgenticUI;
using Microsoft.Agents.AI.Workflows.AgenticUI.Events;
using Microsoft.Extensions.AI;
using OpenAI;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
// Use an alias to resolve RouteBuilder ambiguity
using WorkflowRouteBuilder = Microsoft.Agents.AI.Workflows.RouteBuilder;

namespace AgenticUI_BasicAPI
{
    public static class TravelPlannerWorkflow
    {
        public static Workflow Create(OpenAIClient chatClient)
        {
            var client = chatClient.GetChatClient("gpt-3.5-turbo").AsIChatClient();

            // 1. Initialize API client
            var amadeusClient = new AmadeusApiClient();

            // 2. Define specialized agents with tools
            var flightAgent = new ChatClientAgent(
                client,
                name: "FlightAgent",
                instructions: "You are a flight booking expert. Use the FlightSearch tool to find the best flights based on user requirements.");

            var hotelAgent = new ChatClientAgent(
                client,
                name: "HotelAgent",
                instructions: "You are a hotel booking expert. Use the HotelSearch tool to find the best hotels based on user requirements.");

            // 3. Add tools to agents
            var flightTools = new[]
            {
                new ToolDefinition
                {
                    Name = "FlightSearch",
                    Description = "Search for flights using Amadeus Flight Offers API",
                    InputSchema = typeof(FlightSearchInput)
                }
            };

            var hotelTools = new[]
            {
                new ToolDefinition
                {
                    Name = "HotelSearch",
                    Description = "Search for hotels using Amadeus Hotel Search API",
                    InputSchema = typeof(HotelSearchInput)
                }
            };

            // 4. Define executors
            var flightExecutor = new FlightExecutor(flightAgent, amadeusClient);
            var hotelExecutor = new HotelExecutor(hotelAgent, amadeusClient);
            var aggregator = new TravelAggregator();

            // 5. Define the Planning Executor (Dynamic)
            var planner = new PlanningAgentExecutor(client);

            return new WorkflowBuilder(planner)
                .AddFanOutEdge<List<AgentTodo>>(planner, [flightExecutor, hotelExecutor], (todoList, count) =>
                {
                    return Enumerable.Range(0, count);
                })
                .AddFanInEdge([flightExecutor, hotelExecutor], aggregator)
                .WithOutputFrom(aggregator)
                .Build();
        }

        // ====================================
        // Amadeus API Models
        // ====================================

        internal class FlightSearchInput
        {
            [Description("Origin airport code (e.g., SYD, JFK)")]
            public string OriginLocationCode { get; set; } = string.Empty;

            [Description("Destination airport code (e.g., BKK, DEN)")]
            public string DestinationLocationCode { get; set; } = string.Empty;

            [Description("Departure date in YYYY-MM-DD format")]
            public string DepartureDate { get; set; } = string.Empty;

            [Description("Return date in YYYY-MM-DD format (optional for one-way flights)")]
            public string? ReturnDate { get; set; }

            [Description("Number of adults")]
            public int Adults { get; set; } = 1;

            [Description("Maximum number of results")]
            public int Max { get; set; } = 5;
        }

        internal class HotelSearchInput
        {
            [Description("City code (e.g., BKK for Bangkok, LON for London)")]
            public string CityCode { get; set; } = string.Empty;

            [Description("Check-in date in YYYY-MM-DD format")]
            public string CheckInDate { get; set; } = string.Empty;

            [Description("Check-out date in YYYY-MM-DD format")]
            public string CheckOutDate { get; set; } = string.Empty;

            [Description("Number of adults")]
            public int Adults { get; set; } = 1;

            [Description("Room quantity")]
            public int Rooms { get; set; } = 1;
        }

        internal class FlightOffer
        {
            [JsonPropertyName("id")]
            public string Id { get; set; } = string.Empty;

            [JsonPropertyName("source")]
            public string Source { get; set; } = string.Empty;

            [JsonPropertyName("instantTicketingRequired")]
            public bool InstantTicketingRequired { get; set; }

            [JsonPropertyName("nonHomogeneous")]
            public bool NonHomogeneous { get; set; }

            [JsonPropertyName("oneWay")]
            public bool OneWay { get; set; }

            [JsonPropertyName("lastTicketingDate")]
            public string? LastTicketingDate { get; set; }

            [JsonPropertyName("numberOfBookableSeats")]
            public int NumberOfBookableSeats { get; set; }

            [JsonPropertyName("itineraries")]
            public List<Itinerary>? Itineraries { get; set; }

            [JsonPropertyName("price")]
            public Price? Price { get; set; }

            [JsonPropertyName("pricingOptions")]
            public PricingOptions? PricingOptions { get; set; }

            [JsonPropertyName("validatingAirlineCodes")]
            public List<string>? ValidatingAirlineCodes { get; set; }

            [JsonPropertyName("travelerPricings")]
            public List<TravelerPricing>? TravelerPricings { get; set; }
        }

        internal class Itinerary
        {
            [JsonPropertyName("duration")]
            public string? Duration { get; set; }

            [JsonPropertyName("segments")]
            public List<Segment>? Segments { get; set; }
        }

        internal class Segment
        {
            [JsonPropertyName("departure")]
            public Airport? Departure { get; set; }

            [JsonPropertyName("arrival")]
            public Airport? Arrival { get; set; }

            [JsonPropertyName("carrierCode")]
            public string? CarrierCode { get; set; }

            [JsonPropertyName("number")]
            public string? Number { get; set; }

            [JsonPropertyName("aircraft")]
            public Aircraft? Aircraft { get; set; }

            [JsonPropertyName("operating")]
            public Operating? Operating { get; set; }

            [JsonPropertyName("duration")]
            public string? SegmentDuration { get; set; }

            [JsonPropertyName("id")]
            public string? SegmentId { get; set; }

            [JsonPropertyName("numberOfStops")]
            public int NumberOfStops { get; set; }

            [JsonPropertyName("blacklistedInEU")]
            public bool BlacklistedInEU { get; set; }
        }

        internal class Airport
        {
            [JsonPropertyName("iataCode")]
            public string? IataCode { get; set; }

            [JsonPropertyName("terminal")]
            public string? Terminal { get; set; }

            [JsonPropertyName("at")]
            public string? At { get; set; }
        }

        internal class Aircraft
        {
            [JsonPropertyName("code")]
            public string? Code { get; set; }
        }

        internal class Operating
        {
            [JsonPropertyName("carrierCode")]
            public string? CarrierCode { get; set; }
        }

        internal class Price
        {
            [JsonPropertyName("currency")]
            public string? Currency { get; set; }

            [JsonPropertyName("total")]
            public string? Total { get; set; }

            [JsonPropertyName("base")]
            public string? Base { get; set; }

            [JsonPropertyName("fee")]
            public string? Fee { get; set; }

            [JsonPropertyName("grandTotal")]
            public string? GrandTotal { get; set; }
        }

        internal class PricingOptions
        {
            [JsonPropertyName("fareType")]
            public List<string>? FareType { get; set; }

            [JsonPropertyName("includedCheckedBagsOnly")]
            public bool IncludedCheckedBagsOnly { get; set; }
        }

        internal class TravelerPricing
        {
            [JsonPropertyName("travelerId")]
            public string? TravelerId { get; set; }

            [JsonPropertyName("fareOption")]
            public string? FareOption { get; set; }

            [JsonPropertyName("travelerType")]
            public string? TravelerType { get; set; }

            [JsonPropertyName("price")]
            public Price? Price { get; set; }
        }

        internal class HotelProperty
        {
            [JsonPropertyName("hotelId")]
            public string? HotelId { get; set; }

            [JsonPropertyName("chainCode")]
            public string? ChainCode { get; set; }

            [JsonPropertyName("name")]
            public string? Name { get; set; }

            [JsonPropertyName("cityCode")]
            public string? CityCode { get; set; }

            [JsonPropertyName("latitude")]
            public double Latitude { get; set; }

            [JsonPropertyName("longitude")]
            public double Longitude { get; set; }

            [JsonPropertyName("lastModifiedDate")]
            public string? LastModifiedDate { get; set; }
        }

        internal class FlightInfo
        {
            public string Airline { get; set; } = string.Empty;
            public string FlightNumber { get; set; } = string.Empty;
            public string DepartureAirport { get; set; } = string.Empty;
            public string ArrivalAirport { get; set; } = string.Empty;
            public string DepartureTime { get; set; } = string.Empty;
            public string ArrivalTime { get; set; } = string.Empty;
            public int DurationMinutes { get; set; }
            public string[] Layovers { get; set; } = [];
            public decimal Price { get; set; }
            public string Currency { get; set; } = "USD";
            public string Summary { get; set; } = string.Empty;
        }

        internal class HotelInfo
        {
            public string HotelName { get; set; } = string.Empty;
            public string Location { get; set; } = string.Empty;
            public int StarRating { get; set; }
            public string RoomType { get; set; } = string.Empty;
            public decimal PricePerNight { get; set; }
            public string Currency { get; set; } = "USD";
            public string[] Amenities { get; set; } = [];
            public string Description { get; set; } = string.Empty;
        }

        // ====================================
        // Amadeus API Client
        // ====================================

        internal class AmadeusApiClient
        {
            private readonly string _baseUrl = "https://test.api.amadeus.com";
            private readonly HttpClient _httpClient = new();
            private string? _accessToken;

            public async Task<string> GetAccessTokenAsync(string clientId, string clientSecret, CancellationToken ct = default)
            {
                if (_accessToken != null)
                    return _accessToken;

                var request = new HttpRequestMessage(HttpMethod.Post, $"{_baseUrl}/v1/security/oauth2/token");
                var content = new FormUrlEncodedContent(new Dictionary<string, string>
                {
                    { "client_id", clientId },
                    { "client_secret", clientSecret },
                    { "grant_type", "client_credentials" }
                });
                request.Content = content;

                var response = await _httpClient.SendAsync(request, ct);
                response.EnsureSuccessStatusCode();

                var json = await response.Content.ReadAsStringAsync(ct);
                var doc = JsonDocument.Parse(json);
                _accessToken = doc.RootElement.GetProperty("access_token").GetString();

                return _accessToken ?? throw new InvalidOperationException("No access token returned");
            }

            public async Task<List<FlightOffer>> SearchFlightsAsync(
                string accessToken,
                string origin,
                string destination,
                string departureDate,
                string? returnDate = null,
                int adults = 1,
                int max = 5,
                CancellationToken ct = default)
            {
                var builder = new StringBuilder($"{_baseUrl}/v2/shopping/flight-offers?");
                builder.Append($"originLocationCode={origin}&");
                builder.Append($"destinationLocationCode={destination}&");
                builder.Append($"departureDate={departureDate}&");
                builder.Append($"adults={adults}&");
                builder.Append($"max={max}");

                if (!string.IsNullOrEmpty(returnDate))
                    builder.Append($"&returnDate={returnDate}");

                var request = new HttpRequestMessage(HttpMethod.Get, builder.ToString());
                request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", accessToken);

                try
                {
                    var response = await _httpClient.SendAsync(request, ct);
                    response.EnsureSuccessStatusCode();

                    var json = await response.Content.ReadAsStringAsync(ct);
                    var doc = JsonDocument.Parse(json);
                    var offers = new List<FlightOffer>();

                    if (doc.RootElement.TryGetProperty("data", out var data))
                    {
                        var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                        foreach (var element in data.EnumerateArray())
                        {
                            var offer = JsonSerializer.Deserialize<FlightOffer>(element.GetRawText(), options);
                            if (offer != null)
                                offers.Add(offer);
                        }
                    }

                    return offers;
                }
                catch (HttpRequestException ex)
                {
                    Console.WriteLine($"Flight search error: {ex.Message}");
                    return new List<FlightOffer>();
                }
            }

            public async Task<List<HotelProperty>> SearchHotelsAsync(
                string accessToken,
                string cityCode,
                string checkInDate,
                string checkOutDate,
                int adults = 1,
                CancellationToken ct = default)
            {
                var url = $"{_baseUrl}/v2/shopping/hotel-search?cityCode={cityCode}&checkInDate={checkInDate}&checkOutDate={checkOutDate}&adults={adults}";

                var request = new HttpRequestMessage(HttpMethod.Get, url);
                request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", accessToken);

                try
                {
                    var response = await _httpClient.SendAsync(request, ct);
                    response.EnsureSuccessStatusCode();

                    var json = await response.Content.ReadAsStringAsync(ct);
                    var doc = JsonDocument.Parse(json);
                    var hotels = new List<HotelProperty>();

                    if (doc.RootElement.TryGetProperty("data", out var data))
                    {
                        var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                        foreach (var element in data.EnumerateArray())
                        {
                            var hotel = JsonSerializer.Deserialize<HotelProperty>(element.GetRawText(), options);
                            if (hotel != null)
                                hotels.Add(hotel);
                        }
                    }

                    return hotels;
                }
                catch (HttpRequestException ex)
                {
                    Console.WriteLine($"Hotel search error: {ex.Message}");
                    return new List<HotelProperty>();
                }
            }
        }

        // ====================================
        // Workflow Executors
        // ====================================

        internal class FlightExecutor : Executor<List<AgentTodo>>
        {
            private readonly ChatClientAgent _agent;
            private readonly AmadeusApiClient _apiClient;

            public FlightExecutor(ChatClientAgent agent, AmadeusApiClient apiClient) : base("FlightExecutor")
            {
                _agent = agent;
                _apiClient = apiClient;
            }

            public override async ValueTask HandleAsync(List<AgentTodo> todos, IWorkflowContext context, CancellationToken ct = default)
            {
                var plan = await context.ReadStateAsync<List<AgentTodo>>("workflow_plan", cancellationToken: ct) ?? todos;

                var pendingTasks = plan.Where(t => t.Executor == "FlightExecutor" && (t.Status == "pending" || t.Status == "in_progress")).ToList();
                if (!pendingTasks.Any()) return;

                var planId = await context.ReadStateAsync<string>("current_plan_id", cancellationToken: ct);
                var results = new List<FlightInfo>();

                // Get credentials from environment
                var clientId = Environment.GetEnvironmentVariable("AMADEUS_CLIENT_ID") ?? "YOUR_CLIENT_ID";
                var clientSecret = Environment.GetEnvironmentVariable("AMADEUS_CLIENT_SECRET") ?? "YOUR_CLIENT_SECRET";

                try
                {
                    var accessToken = await _apiClient.GetAccessTokenAsync(clientId, clientSecret, ct);

                    foreach (var myTask in pendingTasks)
                    {
                        var myTaskIndex = plan.IndexOf(myTask);
                        myTask.Status = "executing";
                        await context.QueueStateUpdateAsync("workflow_plan", plan, cancellationToken: ct);
                        await context.EmitPlanningStepAsync("Searching Flights", $"Working on: {myTask.Description}", ct: ct, goalIndex: myTaskIndex, goalStatus: "executing", planId: planId);

                        // Use agent to interpret search requirements
                        var response = await _agent.RunAsync<FlightSearchInput>($"Task: {myTask.Description}. Parse requirements and provide search parameters.", cancellationToken: ct);
                        var searchInput = response.Result;

                        if (searchInput != null)
                        {
                            var offers = await _apiClient.SearchFlightsAsync(
                                accessToken,
                                searchInput.OriginLocationCode,
                                searchInput.DestinationLocationCode,
                                searchInput.DepartureDate,
                                searchInput.ReturnDate,
                                searchInput.Adults,
                                searchInput.Max,
                                ct);

                            if (offers.Any())
                            {
                                foreach (var offer in offers.Take(3))
                                {
                                    var flight = ParseFlightOffer(offer);
                                    if (flight != null)
                                        results.Add(flight);
                                }
                            }
                        }

                        myTask.Status = "completed";
                        await context.QueueStateUpdateAsync("workflow_plan", plan, cancellationToken: ct);

                        string summary = results.Any()
                            ? $"Found {results.Count} flight(s) matching criteria"
                            : "No suitable flights found.";

                        await context.EmitPlanningStepAsync("Flight Search Complete", summary, ct: ct, goalIndex: myTaskIndex, goalStatus: "completed", planId: planId);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Flight executor error: {ex.Message}");
                }

                if (results.Any())
                {
                    await context.SendMessageAsync(results, ct);
                }
                else
                {
                    await context.SendMessageAsync("No flights found", ct);
                }
            }

            private FlightInfo? ParseFlightOffer(FlightOffer offer)
            {
                if (offer.Itineraries?.Count == 0 || offer.Price == null)
                    return null;

                var firstSegment = offer.Itineraries?.FirstOrDefault()?.Segments?.FirstOrDefault();
                if (firstSegment == null)
                    return null;

                return new FlightInfo
                {
                    Airline = firstSegment.CarrierCode ?? "Unknown",
                    FlightNumber = firstSegment.Number ?? "Unknown",
                    DepartureAirport = firstSegment.Departure?.IataCode ?? "Unknown",
                    ArrivalAirport = firstSegment.Arrival?.IataCode ?? "Unknown",
                    DepartureTime = firstSegment.Departure?.At ?? "Unknown",
                    ArrivalTime = firstSegment.Arrival?.At ?? "Unknown",
                    DurationMinutes = ParseDuration(offer.Itineraries?.FirstOrDefault()?.Duration),
                    Price = decimal.TryParse(offer.Price.Total, out var price) ? price : 0,
                    Currency = offer.Price.Currency ?? "USD"
                };
            }

            private int ParseDuration(string? duration)
            {
                if (string.IsNullOrEmpty(duration)) return 0;

                var match = System.Text.RegularExpressions.Regex.Match(duration, @"PT(?:(\d+)H)?(?:(\d+)M)?");
                if (match.Success)
                {
                    int hours = int.TryParse(match.Groups[1].Value, out var h) ? h : 0;
                    int minutes = int.TryParse(match.Groups[2].Value, out var m) ? m : 0;
                    return hours * 60 + minutes;
                }

                return 0;
            }
        }

        internal class HotelExecutor : Executor<List<AgentTodo>>
        {
            private readonly ChatClientAgent _agent;
            private readonly AmadeusApiClient _apiClient;

            public HotelExecutor(ChatClientAgent agent, AmadeusApiClient apiClient) : base("HotelExecutor")
            {
                _agent = agent;
                _apiClient = apiClient;
            }

            public override async ValueTask HandleAsync(List<AgentTodo> todos, IWorkflowContext context, CancellationToken ct = default)
            {
                var plan = await context.ReadStateAsync<List<AgentTodo>>("workflow_plan", cancellationToken: ct) ?? todos;

                var pendingTasks = plan.Where(t => t.Executor == "HotelExecutor" && (t.Status == "pending" || t.Status == "in_progress")).ToList();
                if (!pendingTasks.Any()) return;

                var planId = await context.ReadStateAsync<string>("current_plan_id", cancellationToken: ct);
                var results = new List<HotelInfo>();

                var clientId = Environment.GetEnvironmentVariable("AMADEUS_CLIENT_ID") ?? "YOUR_CLIENT_ID";
                var clientSecret = Environment.GetEnvironmentVariable("AMADEUS_CLIENT_SECRET") ?? "YOUR_CLIENT_SECRET";

                try
                {
                    var accessToken = await _apiClient.GetAccessTokenAsync(clientId, clientSecret, ct);

                    foreach (var myTask in pendingTasks)
                    {
                        var myTaskIndex = plan.IndexOf(myTask);
                        myTask.Status = "executing";
                        await context.QueueStateUpdateAsync("workflow_plan", plan, cancellationToken: ct);
                        await context.EmitPlanningStepAsync("Searching Hotels", $"Working on: {myTask.Description}", ct: ct, goalIndex: myTaskIndex, goalStatus: "executing", planId: planId);

                        var response = await _agent.RunAsync<HotelSearchInput>($"Task: {myTask.Description}. Parse requirements and provide search parameters.", cancellationToken: ct);
                        var searchInput = response.Result;

                        if (searchInput != null)
                        {
                            var hotels = await _apiClient.SearchHotelsAsync(
                                accessToken,
                                searchInput.CityCode,
                                searchInput.CheckInDate,
                                searchInput.CheckOutDate,
                                searchInput.Adults,
                                ct);

                            if (hotels.Any())
                            {
                                foreach (var hotel in hotels.Take(3))
                                {
                                    var hotelInfo = new HotelInfo
                                    {
                                        HotelName = hotel.Name ?? "Unknown Hotel",
                                        Location = hotel.CityCode ?? "Unknown",
                                        StarRating = 4,
                                        RoomType = "Standard Room",
                                        PricePerNight = 150,
                                        Currency = "USD"
                                    };
                                    results.Add(hotelInfo);
                                }
                            }
                        }

                        myTask.Status = "completed";
                        await context.QueueStateUpdateAsync("workflow_plan", plan, cancellationToken: ct);

                        string summary = results.Any()
                            ? $"Found {results.Count} hotel(s) matching criteria"
                            : "No suitable hotels found.";

                        await context.EmitPlanningStepAsync("Hotel Search Complete", summary, ct: ct, goalIndex: myTaskIndex, goalStatus: "completed", planId: planId);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Hotel executor error: {ex.Message}");
                }

                if (results.Any())
                {
                    await context.SendMessageAsync(results, ct);
                }
                else
                {
                    await context.SendMessageAsync("No hotels found", ct);
                }
            }
        }

        internal class TravelAggregator : Executor
        {
            public TravelAggregator() : base("TravelAggregator") { }

            protected override WorkflowRouteBuilder ConfigureRoutes(WorkflowRouteBuilder routeBuilder)
            {
                return routeBuilder.AddCatchAll(HandleAsync);
            }

            public async ValueTask HandleAsync(PortableValue message, IWorkflowContext context, CancellationToken ct = default)
            {
                var results = await context.ReadStateAsync<List<string>>("aggregated_results", cancellationToken: ct) ?? new List<string>();

                if (message.Is(out List<FlightInfo> flights))
                {
                    var flightSummary = new StringBuilder();
                    flightSummary.AppendLine($"### Flights Found ({flights.Count})");
                    foreach (var f in flights)
                    {
                        flightSummary.AppendLine($"- {f.Airline} {f.FlightNumber}: {f.DepartureAirport} → {f.ArrivalAirport}");
                        flightSummary.AppendLine($"  Departs: {f.DepartureTime} | Arrives: {f.ArrivalTime}");
                        flightSummary.AppendLine($"  Duration: {f.DurationMinutes / 60}h {f.DurationMinutes % 60}m | Price: {f.Price} {f.Currency}");
                    }
                    results.Add(flightSummary.ToString());
                }
                else if (message.Is(out List<HotelInfo> hotels))
                {
                    var hotelSummary = new StringBuilder();
                    hotelSummary.AppendLine($"### Hotels Found ({hotels.Count})");
                    foreach (var h in hotels)
                    {
                        hotelSummary.AppendLine($"- {h.HotelName} ({h.StarRating}★)");
                        hotelSummary.AppendLine($"  Location: {h.Location}");
                        hotelSummary.AppendLine($"  {h.RoomType}: {h.PricePerNight} {h.Currency}/night");
                    }
                    results.Add(hotelSummary.ToString());
                }
                else if (message.Is(out string text))
                {
                    results.Add(text);
                }

                await context.QueueStateUpdateAsync("aggregated_results", results, cancellationToken: ct);

                if (results.Count >= 2)
                {
                    var planId = await context.ReadStateAsync<string>("current_plan_id", cancellationToken: ct);
                    var combinedSummary = string.Join("\n", results);
                    await context.EmitPlanningEndAsync("Travel plans finalized.", planId: planId, ct: ct);
                    await context.YieldOutputAsync(combinedSummary, ct);
                    await context.QueueStateUpdateAsync("aggregated_results", new List<string>(), cancellationToken: ct);
                }
            }
        }

        internal class PlanningAgentExecutor : Executor<string>
        {
            private readonly ChatClientAgent _agent;

            public PlanningAgentExecutor(IChatClient chatClient) : base("PlanningAgent")
            {
                _agent = new ChatClientAgent(
                    chatClient,
                    name: "Planner",
                    instructions: @"You are a travel planning expert using Amadeus travel APIs.
Based on the user's request, create a list of tasks (todos) to be executed by specialized agents.
Supported Executors: 'FlightExecutor', 'HotelExecutor'.
For each flight requirement, create a FlightExecutor task.
For each hotel requirement, create a HotelExecutor task."
                );
            }

            public override async ValueTask HandleAsync(string input, IWorkflowContext context, CancellationToken ct = default)
            {
                var planId = Guid.NewGuid().ToString("N");
                await context.QueueStateUpdateAsync("current_plan_id", planId, cancellationToken: ct);

                await context.EmitPlanningStepAsync("Planning Trip", $"Analyzing request: {input}", ct: ct, planId: planId);

                var response = await _agent.RunAsync<List<AgentTodo>>($"Request: {input}", cancellationToken: ct);
                var todos = response.Result ?? [];

                await context.QueueStateUpdateAsync("workflow_plan", todos, cancellationToken: ct);
                await context.EmitPlanningStartAsync(todos, planId: planId, ct: ct);
                await context.EmitPlanningStepAsync("Plan Created", $"Generated {todos.Count} tasks.", ct: ct, planId: planId);

                await context.SendMessageAsync(todos, ct);
            }
        }
    }
}
