using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Workflows;
using Microsoft.Agents.AI.Workflows.AgenticUI;
using Microsoft.Extensions.AI;
using OpenAI;
using System.Diagnostics.CodeAnalysis;

// Use an alias to resolve RouteBuilder ambiguity
using WorkflowRouteBuilder = Microsoft.Agents.AI.Workflows.RouteBuilder;

namespace AgenticUI_BasicAPI
{
    public static class WriterCriticWorkflow
    {
        public static Workflow Create(OpenAIClient chatClient)
        {
            var client = chatClient.GetChatClient("qwen3-4b").AsIChatClient();

            // Create Writer agent
            var writer = new WriterAgentExecutor(client);
            var critic = new CriticAgentExecutor(client);
            var summary = new SummaryAgentExecutor(client);

            // Build workflow with conditional routing
            var workflowBuilder = new WorkflowBuilder(writer)
                .AddEdge(writer, critic)
                .AddSwitch(critic, sw => sw
                    .AddCase<CriticFeedback>(cd => cd?.Approved == true, summary)
                    .AddCase<CriticFeedback>(cd => cd?.Approved == false, writer))
                .WithOutputFrom(summary);

            return workflowBuilder.Build();
        }

        // ====================================
        // Custom Executors for Writer-Critic Workflow
        // ====================================

        internal sealed class WriterAgentExecutor : Executor
        {
            private readonly AIAgent _agent;

            public WriterAgentExecutor(IChatClient chatClient) : base("Writer")
            {
                _agent = new ChatClientAgent(
                    chatClient,
                    name: "Writer",
                    instructions: "You are a skilled writer. Create clear, engaging content. If you receive feedback, revise based on the suggestions."
                );
            }

            protected override WorkflowRouteBuilder ConfigureRoutes(WorkflowRouteBuilder routeBuilder) =>
                routeBuilder
                    .AddHandler<string>(HandleStringInputAsync)
                    .AddHandler<CriticFeedback>(HandleCriticFeedbackInputAsync);

            private async ValueTask HandleStringInputAsync(string input, IWorkflowContext context, CancellationToken ct = default)
            {
                var planId = Guid.NewGuid().ToString("N");
                await context.QueueStateUpdateAsync("current_plan_id", planId, cancellationToken: ct);

                await context.EmitPlanningStepAsync("Drafting Content", $"Creating initial draft for: {input.Substring(0, Math.Min(30, input.Length))}...", planId: planId, ct: ct);

                var response = await _agent.RunAsync(new List<ChatMessage> { new ChatMessage(ChatRole.User, input) });
                var responseText = response.ToString();

                await context.EmitPlanningStepAsync("Draft Created", "Initial content generation completed.", planId: planId, ct: ct);
                await context.YieldOutputAsync(responseText, ct);
            }

            private async ValueTask HandleCriticFeedbackInputAsync(CriticFeedback input, IWorkflowContext context, CancellationToken ct = default)
            {
                var planId = await context.ReadStateAsync<string>("current_plan_id", cancellationToken: ct);
                await context.EmitPlanningStepAsync("Refining Content", $"Applying feedback: {input.Feedback.Substring(0, Math.Min(30, input.Feedback.Length))}...", planId: planId, ct: ct);

                string prompt = $"Revise based on feedback:\n{input.Feedback}\n\nOriginal:\n{input.Content}";
                var response = await _agent.RunAsync(prompt);
                var responseText = response.ToString();

                input.Content = responseText;
                await context.EmitPlanningStepAsync("Revision Complete", "Content updated based on feedback.", planId: planId, ct: ct);
                await context.YieldOutputAsync(responseText, ct);
            }
        }

        internal sealed class CriticAgentExecutor : Executor
        {
            private readonly AIAgent _agent;

            public CriticAgentExecutor(IChatClient chatClient) : base("Critic")
            {
                _agent = new ChatClientAgent(
                    chatClient,
                    name: "Critic",
                    instructions: "You are a constructive critic. Review content and decide if it's ready. Respond with APPROVED or NEEDS_REVISION"
                );
            }

            protected override WorkflowRouteBuilder ConfigureRoutes(WorkflowRouteBuilder routeBuilder) =>
                routeBuilder
                    .AddHandler<ChatMessage>(HandleChatMessageInputAsync);

            private async ValueTask HandleChatMessageInputAsync(ChatMessage input, IWorkflowContext context, CancellationToken ct = default)
            {
                var planId = await context.ReadStateAsync<string>("current_plan_id", cancellationToken: ct);
                await context.EmitPlanningStepAsync("Reviewing Content", "Critic is evaluating the current draft...", planId: planId, ct: ct);

                var response = await _agent.RunAsync(input.Text ?? "");
                var responseText = response.ToString();
                var approved = responseText.Contains("APPROVED", StringComparison.OrdinalIgnoreCase);

                var feedback = new CriticFeedback
                {
                    Approved = approved,
                    Content = input.Text ?? "",
                    Feedback = approved ? "Content approved!" : responseText
                };

                await context.EmitPlanningStepAsync(approved ? "Approved" : "Revision Requested", feedback.Feedback, planId: planId, ct: ct);
                await context.YieldOutputAsync(feedback, ct);
            }
        }

        internal sealed class SummaryAgentExecutor : Executor
        {
            private readonly AIAgent _agent;

            public SummaryAgentExecutor(IChatClient chatClient) : base("Summary")
            {
                _agent = new ChatClientAgent(
                    chatClient,
                    name: "Summary",
                    instructions: "Present the final approved content clearly and professionally."
                );
            }

            protected override WorkflowRouteBuilder ConfigureRoutes(WorkflowRouteBuilder routeBuilder) =>
                routeBuilder
                    .AddHandler<CriticFeedback>(HandleCriticFeedbackInputAsync);

            private async ValueTask HandleCriticFeedbackInputAsync(CriticFeedback input, IWorkflowContext context, CancellationToken ct = default)
            {
                var planId = await context.ReadStateAsync<string>("current_plan_id", cancellationToken: ct);
                await context.EmitPlanningStepAsync("Final Presentation", "Formatting the approved content for the user...", planId: planId, ct: ct);

                var result = await _agent.RunAsync($"Present this content:\n{input.Content}");
                var resultText = result.ToString();

                await context.EmitPlanningStepAsync("Presentation Ready", "Workflow completed successfully.", planId: planId, ct: ct);
                await context.EmitPlanningEndAsync("Writer-Critic Workflow Complete", planId: planId, ct: ct);
                await context.YieldOutputAsync(resultText, ct);
            }
        }

        [SuppressMessage("Performance", "CA1812:Avoid uninstantiated internal classes", Justification = "Instantiated via routing")]
        internal sealed class CriticFeedback
        {
            public bool Approved { get; set; }
            public string Content { get; set; } = "";
            public string Feedback { get; set; } = "";
        }
    }
}