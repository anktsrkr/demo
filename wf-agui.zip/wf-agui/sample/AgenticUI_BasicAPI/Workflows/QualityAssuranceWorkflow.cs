using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Workflows;
using Microsoft.Agents.AI.Workflows.AgenticUI;
using Microsoft.Extensions.AI;
using OpenAI;

namespace AgenticUI_BasicAPI
{
    public static class QualityAssuranceWorkflow
    {
        public static Workflow Create(OpenAIClient chatClient)
        {
            var client = chatClient.GetChatClient("qwen3-4b").AsIChatClient();

            var generator = new ChatClientAgent(client, name: "Generator", instructions: "Generate high-quality content.");
            var validator = new ChatClientAgent(client, name: "Validator", instructions: "Validate content for accuracy and quality. Respond with VALID or INVALID");
            var enhancer = new ChatClientAgent(client, name: "Enhancer", instructions: "Enhance and polish the content for maximum impact.");

            Func<string, IWorkflowContext, ValueTask<string>> handler = async (input, context) =>
            {
                var planId = "QAWorkflow_Plan";

                // Stage 1: Generate
                await context.EmitPlanningStepAsync("Stage 1: Generating content", planId: planId);
                var generatedResponse = await generator.RunAsync(new List<ChatMessage> { new ChatMessage(ChatRole.User, input) });
                var generated = generatedResponse.ToString();

                // Stage 2: Validate
                await context.EmitPlanningStepAsync("Stage 2: Validating quality", planId: planId);
                var validationResponse = await validator.RunAsync(new List<ChatMessage> { new ChatMessage(ChatRole.User, generated) });
                var validation = validationResponse.ToString();

                // Stage 3: Enhance if valid
                if (validation.Contains("VALID", StringComparison.OrdinalIgnoreCase))
                {
                    await context.EmitPlanningStepAsync("Stage 3: Enhancing content", planId: planId);
                    var enhancedResponse = await enhancer.RunAsync(new List<ChatMessage> { new ChatMessage(ChatRole.User, generated) });
                    var enhanced = enhancedResponse.ToString();
                    return $"✅ Quality Assured\n\n{enhanced}";
                }
                else
                {
                    return $"❌ Quality validation failed. Generated content:\n{generated}";
                }
            };

            return new WorkflowBuilder(handler.BindAsExecutor("QAWorkflow")).Build();
        }
    }
}