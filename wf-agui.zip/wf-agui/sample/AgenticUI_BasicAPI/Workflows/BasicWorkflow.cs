using Microsoft.Agents.AI.Workflows;
using Microsoft.Agents.AI.Workflows.AgenticUI;

namespace AgenticUI_BasicAPI
{
    public static class BasicWorkflow
    {
        public static Workflow Create()
        {
            Func<string, IWorkflowContext, ValueTask<string>> handler = async (input, context) =>
            {
                await context.EmitPlanningStepAsync("Hello from AgenticUI Workflow!", planId: "BasicWorkflow_Plan");
                return $"Processed: {input}";
            };

            return new WorkflowBuilder(handler.BindAsExecutor("BasicWorkflow")).Build();
        }
    }
}