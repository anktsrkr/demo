using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Workflows;
using Microsoft.Agents.AI.Workflows.AgenticUI;
using Microsoft.Agents.AI.Workflows.AgenticUI.Events;
using Microsoft.Extensions.AI;
using OpenAI;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace AgenticUI_BasicAPI
{
    public static class FunctionToolsStreamingWorkflow
    {
        public static Workflow Create(OpenAIClient chatClient)
        {
            // Define a function tool for weather lookup
            static string GetWeather([Description("The location to get weather for")] string location)
                => $"Weather in {location}: Mostly cloudy with 72°F temperature.";

            static string GetTimeInZone([Description("The timezone (e.g., EST, PST)")] string timezone)
                => $"Current time in {timezone}: {DateTime.UtcNow:HH:mm:ss} UTC";

            static string SearchNews([Description("Search query for news")] string query)
                => $"Found 5 articles matching '{query}' in tech news.";

            var aiChatClient = chatClient.GetChatClient("qwen3-4b").AsIChatClient();

            // Create agent with multiple tools
            AIAgent toolAgent = new ChatClientAgent(
                aiChatClient,
                instructions: "You are a helpful assistant with access to weather, time, and news search tools. Use them to answer user queries accurately.",
                tools:
                [
                    AIFunctionFactory.Create(GetWeather),
                    AIFunctionFactory.Create(GetTimeInZone),
                    AIFunctionFactory.Create(SearchNews)
                ]
            );

            Func<string, IWorkflowContext, ValueTask<string>> handler = async (input, context) =>
            {
                var planId = "StreamingToolAgent_Plan";
                await context.EmitPlanningStepAsync($"Processing request (streaming): {input}", planId: planId);

                var chatMessages = new List<ChatMessage> { new ChatMessage(ChatRole.User, input) };
                List<AgentRunResponseUpdate> updates = [];

                await foreach (var update in toolAgent.RunStreamingAsync(chatMessages))
                {
                    updates.Add(update);
                    await context.AddEventAsync(new AgentRunUpdateEvent("StreamingToolAgent", update));
                }

                await context.EmitPlanningStepAsync("Streaming completed", planId: planId);

                return updates.ToAgentRunResponse().ToString();
            };

            return new WorkflowBuilder(handler.BindAsExecutor("StreamingToolAgent")).Build();
        }
    }
}