using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Workflows;
using Microsoft.Agents.AI.Workflows.AgenticUI;
using Microsoft.Agents.AI.Workflows.AgenticUI.Events;
using Microsoft.Extensions.AI;
using OpenAI;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace AgenticUI_BasicAPI
{
    public static class ToolOutputYieldingWorkflow
    {
        public static Workflow Create(OpenAIClient chatClient)
        {
            // Define function tools that return JSON
            static string GetWeather([Description("The location to get weather for")] string location)
            {
                var weatherData = new
                {
                    location = location,
                    temperature = 72,
                    condition = "Mostly cloudy",
                    humidity = 65,
                    windSpeed = 10
                };
                return System.Text.Json.JsonSerializer.Serialize(weatherData);
            }

            static string GetTimeInZone([Description("The timezone (e.g., EST, PST)")] string timezone)
            {
                var timeData = new
                {
                    timezone = timezone,
                    currentTime = DateTime.UtcNow.ToString("HH:mm:ss"),
                    utcOffset = GetUtcOffset(timezone)
                };
                return System.Text.Json.JsonSerializer.Serialize(timeData);
            }

            static string SearchNews([Description("Search query for news")] string query)
            {
                var newsData = new
                {
                    query = query,
                    articlesFound = 5,
                    source = "Tech News",
                    articles = new[] { "Article 1", "Article 2", "Article 3", "Article 4", "Article 5" }
                };
                return System.Text.Json.JsonSerializer.Serialize(newsData);
            }

            static string GetUtcOffset(string timezone) =>
                timezone.ToUpper() switch
                {
                    "EST" => "-05:00",
                    "PST" => "-08:00",
                    "GMT" => "+00:00",
                    "IST" => "+05:30",
                    _ => "+00:00"
                };

            var aiChatClient = chatClient.GetChatClient("qwen3-4b").AsIChatClient();

            // Create agent with multiple tools
            AIAgent toolAgent = new ChatClientAgent(
                aiChatClient,
                instructions: "You are a helpful assistant with access to weather, time, and news search tools. Use them to answer user queries accurately.",
                tools:
                [
                    AIFunctionFactory.Create(GetWeather),
                    AIFunctionFactory.Create(GetTimeInZone),
                    AIFunctionFactory.Create(SearchNews)
                ]
            );

            // Create executors for the workflow
            var toolExecutor = new ToolExecutingExecutor(toolAgent);
            var weatherProcessor = new ToolResultProcessorExecutor("weather");
            var timeProcessor = new ToolResultProcessorExecutor("time");
            var newsProcessor = new ToolResultProcessorExecutor("news");
            var toolResultAggregator = new ToolResultAggregatorExecutor();

            // Build workflow with switch-case routing based on tool type
            var workflowBuilder = new WorkflowBuilder(toolExecutor)
                .AddSwitch(toolExecutor, sw => sw
                    .AddCase<ToolExecutionResult>(
                        toolResult => toolResult?.ToolType == "weather",
                        weatherProcessor
                    )
                    .AddCase<ToolExecutionResult>(
                        toolResult => toolResult?.ToolType == "time",
                        timeProcessor
                    )
                    .AddCase<ToolExecutionResult>(
                        toolResult => toolResult?.ToolType == "news",
                        newsProcessor
                    )
                    .WithDefault(toolResultAggregator)
                )
                .AddEdge(weatherProcessor, toolResultAggregator)
                .AddEdge(timeProcessor, toolResultAggregator)
                .AddEdge(newsProcessor, toolResultAggregator)
                .WithOutputFrom(toolResultAggregator);

            return workflowBuilder.Build();
        }

        // ====================================
        // Tool Output Yielding Executors (JSON + Shared State + Conditional Routing)
        // ====================================

        /// <summary>
        /// Constants for shared state scopes in tool output workflow.
        /// </summary>
        internal static class ToolOutputStateConstants
        {
            public const string ToolResponseStateScope = "ToolResponseState";
        }

        /// <summary>
        /// Represents the result of a tool execution with type information.
        /// </summary>
        internal sealed class ToolExecutionResult
        {
            public string ToolType { get; set; } = string.Empty;
            public string ToolName { get; set; } = string.Empty;
            public string Response { get; set; } = string.Empty;
            public string StateId { get; set; } = string.Empty;
            public string? PlanId { get; set; }
        }

        /// <summary>
        /// Executes agent with tool capabilities and routes based on tool type.
        /// </summary>
        internal sealed class ToolExecutingExecutor : Executor<string>
        {
            private readonly AIAgent _toolAgent;

            public ToolExecutingExecutor(AIAgent toolAgent) : base("ToolExecutor")
            {
                _toolAgent = toolAgent;
            }

            public override async ValueTask HandleAsync(string input, IWorkflowContext context, CancellationToken ct = default)
            {
                var planId = Guid.NewGuid().ToString("N");
                await context.EmitPlanningStepAsync($"Processing request with tool-based routing: {input}", planId: planId, ct: ct);

                var chatMessages = new List<ChatMessage> { new ChatMessage(ChatRole.User, input) };
                List<AgentRunResponseUpdate> updates = [];
                string toolResponse = "";

                // Stream agent responses
                await foreach (var update in _toolAgent.RunStreamingAsync(chatMessages, cancellationToken: ct))
                {
                    updates.Add(update);
                    await context.AddEventAsync(new AgentRunUpdateEvent("ToolExecutor", update), ct);
                }

                // Generate final response
                toolResponse = updates.ToAgentRunResponse().ToString();

                // Detect tool type from the response content
                string detectedToolType = DetectToolType(toolResponse);

                // Store response in shared state
                string stateId = Guid.NewGuid().ToString("N");
                await context.QueueStateUpdateAsync(
                    stateId,
                    toolResponse,
                    scopeName: ToolOutputStateConstants.ToolResponseStateScope,
                    cancellationToken: ct
                );

                await context.EmitPlanningStepAsync($"Tool execution completed, detected type: {detectedToolType}", planId: planId, ct: ct);

                // Create execution result with type for routing
                var executionResult = new ToolExecutionResult
                {
                    ToolType = detectedToolType,
                    ToolName = detectedToolType,
                    Response = toolResponse,
                    StateId = stateId,
                    PlanId = planId
                };

                await context.SendMessageAsync(executionResult, ct);
            }

            private static string DetectToolType(string response)
            {
                var lowerResponse = response.ToLowerInvariant();

                if (lowerResponse.Contains("weather") || lowerResponse.Contains("temperature") ||
                    lowerResponse.Contains("condition") || lowerResponse.Contains("humidity"))
                    return "weather";

                if (lowerResponse.Contains("time") || lowerResponse.Contains("timezone") ||
                    lowerResponse.Contains("utc"))
                    return "time";

                if (lowerResponse.Contains("news") || lowerResponse.Contains("article") ||
                    lowerResponse.Contains("search query"))
                    return "news";

                return "unknown";
            }
        }

        /// <summary>
        /// Processes tool results for a specific tool type with state retrieval.
        /// </summary>
        internal sealed class ToolResultProcessorExecutor : Executor<ToolExecutionResult>
        {
            private readonly string _toolType;

            public ToolResultProcessorExecutor(string toolType) : base($"ToolProcessor_{toolType}")
            {
                _toolType = toolType;
            }

            public override async ValueTask HandleAsync(ToolExecutionResult input, IWorkflowContext context, CancellationToken ct = default)
            {
                // Validate tool type
                if (input.ToolType != _toolType)
                {
                    throw new InvalidOperationException($"This processor handles {_toolType} tools, but received {input.ToolType}");
                }

                // Retrieve response from shared state
                var response = await context.ReadStateAsync<string>(
                    input.StateId,
                    scopeName: ToolOutputStateConstants.ToolResponseStateScope,
                    cancellationToken: ct
                ) ?? throw new InvalidOperationException("Tool response state not found");

                await context.EmitPlanningStepAsync($"Processing {_toolType} tool result", planId: input.PlanId, ct: ct);

                // Format response based on tool type
                var formattedResponse = FormatToolResponse(_toolType, response);

                // Pass to aggregator
                var aggregationInput = new ToolExecutionResult
                {
                    ToolType = input.ToolType,
                    ToolName = input.ToolName,
                    Response = formattedResponse,
                    StateId = input.StateId,
                    PlanId = input.PlanId
                };

                await context.SendMessageAsync(aggregationInput, ct);
            }

            private static string FormatToolResponse(string toolType, string response) =>
                toolType switch
                {
                    "weather" => $"🌤️ **Weather Information**\n```json\n{response}\n```",
                    "time" => $"⏰ **Time Information**\n```json\n{response}\n```",
                    "news" => $"📰 **News Results**\n```json\n{response}\n```",
                    _ => $"📋 **Result**\n```json\n{response}\n```"
                };
        }

        /// <summary>
        /// Yields tool results directly without accumulation.
        /// Each tool result is yielded independently to avoid cross-request state pollution.
        /// </summary>
        internal sealed class ToolResultAggregatorExecutor : Executor<ToolExecutionResult>
        {
            public ToolResultAggregatorExecutor() : base("ToolResultAggregator")
            {
            }

            public override async ValueTask HandleAsync(ToolExecutionResult input, IWorkflowContext context, CancellationToken ct = default)
            {
                await context.EmitPlanningStepAsync($"Yielding {input.ToolName} result", planId: input.PlanId, ct: ct);

                // Yield result directly without accumulation to avoid state pollution
                var finalOutput = $"{input.Response}";
                await context.YieldOutputAsync(finalOutput, ct);
            }
        }
    }
}