using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Workflows;
using Microsoft.Extensions.AI;
using OpenAI;

namespace AgenticUI_BasicAPI
{
    public static class SimpleAgentWorkflow
    {
        public static Workflow Create(OpenAIClient chatClient)
        {
            ChatClientAgent GetTranslationAgent(string targetLanguage, IChatClient chatClient) =>
                new(chatClient, $"You are a translation assistant that translates the provided text to {targetLanguage}.");

            ChatClientAgent SmartAssist(IChatClient chatClient) =>
                new(chatClient, $"You are a smart assistant", name: "Smart Assist");

            AIAgent frenchAgent = GetTranslationAgent("French", chatClient.GetChatClient("gpt-3.5-turbo").AsIChatClient());
            AIAgent spanishAgent = GetTranslationAgent("Spanish", chatClient.GetChatClient("gpt-3.5-turbo").AsIChatClient());
            AIAgent bengaliAgent = GetTranslationAgent("Bengali", chatClient.GetChatClient("gpt-3.5-turbo").AsIChatClient());
            AIAgent smartAssit = SmartAssist(chatClient.GetChatClient("gpt-3.5-turbo").AsIChatClient());

            return AgentWorkflowBuilder.BuildSequential(smartAssit);
        }
    }
}