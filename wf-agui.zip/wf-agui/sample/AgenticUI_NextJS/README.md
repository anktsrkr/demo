# Agentic UI - Next.js + DaisyUI

A modern, real-time frontend for Microsoft Agents AI Workflows using Next.js 15 and DaisyUI.

## Features

- 🔄 **Real-time SSE Streaming** - Watch agent events as they happen
- 🎨 **Multiple Themes** - Light, Dark, Cupcake, Cyberpunk, Forest
- 🧠 **Planning Visualization** - See agent planning steps
- 🔧 **Tool Call Tracking** - Monitor tool executions with args and results
- 📊 **Event Timeline** - Complete event stream visualization
- 📱 **Responsive Design** - Works on desktop and mobile

## Prerequisites

- Node.js 18+
- The AgenticUI_BasicAPI backend running on port 5000

## Quick Start

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the backend API (from the repository root):
   ```bash
   dotnet run --project sample/AgenticUI_BasicAPI
   ```

3. Start the Next.js development server:
   ```bash
   npm run dev
   ```

4. Open [http://localhost:3000](http://localhost:3000)

## Project Structure

```
src/
├── app/
│   ├── globals.css      # Tailwind + DaisyUI styles
│   ├── layout.tsx       # Root layout with theme
│   └── page.tsx         # Main chat interface
├── components/
│   ├── ChatInput.tsx    # Message input form
│   ├── EventTimeline.tsx # Event stream display
│   ├── OutputDisplay.tsx # Agent responses
│   ├── PlanningSteps.tsx # Planning visualization
│   ├── ThemeToggle.tsx  # Theme switcher
│   └── ToolCallCard.tsx # Tool execution cards
├── hooks/
│   └── useAgenticUI.ts  # SSE client hook
└── types/
    └── events.ts        # TypeScript event types
```

## Event Types Supported

| Event Type | Description |
|------------|-------------|
| `RUN_STARTED` | Workflow execution begins |
| `RUN_FINISHED` | Workflow completes successfully |
| `RUN_ERROR` | Error during execution |
| `AGENT_PLANNING_*` | Planning phase events |
| `TOOL_CALL_*` | Tool invocation events |
| `EXECUTOR_*` | Executor lifecycle events |
| `WORKFLOW_OUTPUT` | Final workflow output |

## Configuration

The API endpoint is proxied via `next.config.ts`. Update the destination URL if your backend runs on a different port:

```typescript
// next.config.ts
{
  source: "/api/agent",
  destination: "https://localhost:58185/api/agent",
}
```

## Customization

### Themes

Edit `tailwind.config.ts` to add or remove DaisyUI themes:

```typescript
daisyui: {
  themes: ["light", "dark", "cupcake", "cyberpunk", "forest"],
}
```

### Colors

DaisyUI uses semantic color names. Customize in your theme or via CSS variables.

## License

Copyright (c) Microsoft. All rights reserved.
