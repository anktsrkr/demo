// Copyright (c) Microsoft. All rights reserved.

"use client";

import type { MessageContent, MessageContentText } from "@/types/events";
import { normalizeValue } from "../utils";

/**
 * Utility to check if content is text type.
 */
export function isTextContent(
    content: MessageContent
): content is MessageContentText {
    return content.$type === "text";
}

/**
 * Utility to extract combined text from message contents.
 */
export function extractText(contents: MessageContent[]): string {
    return contents
        .filter(isTextContent)
        .map((c) => normalizeValue(c.text))
        .join("");
}
