// Copyright (c) Microsoft. All rights reserved.

import type { TypedValue } from "@/types/events";

/**
 * Normalizes a value that might be wrapped in a C# TypedValue object.
 */
export function normalizeValue<T>(val: T | TypedValue<T>): T {
    if (val && typeof val === "object" && "typeId" in val && "value" in (val as any)) {
        return (val as any).value;
    }
    return val as T;
}
