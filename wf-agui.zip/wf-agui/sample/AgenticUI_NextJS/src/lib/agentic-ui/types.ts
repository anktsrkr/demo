// Copyright (c) Microsoft. All rights reserved.

import type { ComponentType } from "react";
import type {
    AnyAgenticUIEvent,
    AgenticUIEventType,
    MessageContent,
} from "@/types/events";
import type { ChatMessage, SuperStep, ExecutorInfo } from "@/types/chat";

// ============================================================================
// Event Component Types
// ============================================================================

/**
 * Props passed to custom event renderer components.
 */
export interface EventComponentProps<T extends AnyAgenticUIEvent = AnyAgenticUIEvent> {
    /** The event to render */
    event: T;
    /** Whether this event is currently streaming/active */
    isStreaming?: boolean;
}

/**
 * Registry type for custom event components.
 * Map event type strings to component types.
 */
export type EventComponentRegistry = Partial<
    Record<AgenticUIEventType, ComponentType<EventComponentProps>>
>;

// ============================================================================
// Content Component Types
// ============================================================================

/**
 * Props passed to custom message content renderer components.
 */
export interface ContentComponentProps<T = unknown> {
    /** The content object to render */
    content: T;
    /** Whether this message is currently streaming */
    isStreaming?: boolean;
}

/**
 * Registry type for custom content components.
 * Map $type strings to component types.
 */
export type ContentComponentRegistry = Partial<
    Record<string, ComponentType<ContentComponentProps>>
>;

// ============================================================================
// Tool Result Component Types
// ============================================================================

/**
 * Props passed to custom tool result components.
 */
export interface ToolResultComponentProps<T = any> {
    /** The name of the tool */
    name: string;
    /** The arguments passed to the tool */
    args: any;
    /** The result returned by the tool */
    result: T;
    /** Whether the result is still being accumulated (if applicable) */
    isStreaming?: boolean;
}

/**
 * Registry type for custom tool result components.
 * Map tool names to component types.
 */
export type ToolResultComponentRegistry = Record<
    string,
    ComponentType<ToolResultComponentProps>
>;

// ============================================================================
// UI Component Types
// ============================================================================

/**
 * Props for custom message bubble components.
 */
export interface MessageComponentProps {
    message: ChatMessage;
    // Callback to toggle the agent workspace panel from within a message
    onToggleWorkspace?: () => void;
}

/**
 * Props for custom chat input components.
 */
export interface InputComponentProps {
    onSend: (message: string) => void;
    disabled?: boolean;
}

/**
 * Props for custom header components.
 */
export interface HeaderComponentProps {
    isRunning: boolean;
    eventCount: number;
    messageCount: number;
    onReset: () => void;
    onTogglePanel: () => void;
    showPanel: boolean;
}

/**
 * Props for custom execution panel components.
 */
export interface PanelComponentProps {
    superSteps: SuperStep[];
    executors: Map<string, ExecutorInfo>;
    events: AnyAgenticUIEvent[];
    isRunning: boolean;
}

/**
 * Props for custom chat container components.
 */
export interface ContainerComponentProps {
    messages: ChatMessage[];
    isRunning: boolean;
}

// ============================================================================
// Theme Types
// ============================================================================

/**
 * DaisyUI theme configuration for the framework.
 */
export interface AgenticUITheme {
    /** DaisyUI theme name or 'system' for auto-detection */
    name: "light" | "dark" | "cupcake" | "dracula" | "cyberpunk" | "system";

    /** Component variant class overrides */
    variants: {
        messageBubble: {
            user: string;
            assistant: string;
            system: string;
        };
        eventCard: {
            base: string;
            active: string;
        };
        badge: {
            running: string;
            success: string;
            error: string;
            info: string;
        };
    };
}

/**
 * Default theme configuration using DaisyUI classes.
 */
export const defaultTheme: AgenticUITheme = {
    name: "system",
    variants: {
        messageBubble: {
            user: "chat-bubble-neutral",
            assistant: "chat-bubble-primary",
            system: "bg-base-300 text-base-content/70",
        },
        eventCard: {
            base: "card bg-base-200 shadow-sm",
            active: "ring-2 ring-primary",
        },
        badge: {
            running: "badge-primary animate-pulse",
            success: "badge-success",
            error: "badge-error",
            info: "badge-info",
        },
    },
};

// ============================================================================
// Configuration Types
// ============================================================================

/**
 * Callback hooks for framework events.
 */
export interface AgenticUICallbacks {
    /** Called when any event is received */
    onEvent?: (event: AnyAgenticUIEvent) => void;
    /** Called when a message is added/updated */
    onMessage?: (message: ChatMessage) => void;
    /** Called when an error occurs */
    onError?: (error: Error) => void;
}

/**
 * Full configuration for the AgenticUI framework.
 */
export interface AgenticUIConfig {
    /** API endpoint URL for SSE stream */
    apiUrl: string;

    /** Optional consistent runId for session persistence. */
    runId?: string;

    /** Custom event component overrides */
    eventComponents?: EventComponentRegistry;

    /** Custom message content component overrides */
    contentComponents?: ContentComponentRegistry;

    /** Custom tool result component overrides (mapped by tool name) */
    toolResultComponents?: ToolResultComponentRegistry;

    /** Custom message bubble component */
    messageComponent?: ComponentType<MessageComponentProps>;

    /** Custom chat input component */
    inputComponent?: ComponentType<InputComponentProps>;

    /** Custom header component */
    headerComponent?: ComponentType<HeaderComponentProps>;

    /** Custom execution panel component */
    panelComponent?: ComponentType<PanelComponentProps>;

    /** Custom chat container component */
    containerComponent?: ComponentType<ContainerComponentProps>;

    /** Theme configuration */
    theme?: Partial<AgenticUITheme>;

    /** Event callbacks */
    callbacks?: AgenticUICallbacks;
}

// ============================================================================
// State Types
// ============================================================================

/**
 * Tool call state tracked by the framework.
 */
export interface ToolCall {
    id: string;
    name: string;
    args: string;
    result?: unknown;
    status: "pending" | "completed" | "failed";
}

export interface PlanningState {
    goals: (string | any)[];
    goalStatuses: string[];
    steps: {
        action: string;
        reasoning?: string;
        timestamp: string;
        goal_index?: number;
        goal_status?: string;
    }[];
    finalPlan?: string;
    status: "idle" | "planning" | "executing" | "completed";
}

/**
 * Workspace update for streaming agent activity.
 * Displayed in the Agent Workspace panel, not in chat bubbles.
 */
export interface WorkspaceUpdate {
    id: string;
    timestamp: string;
    type: "tool_call" | "tool_result" | "text" | "reasoning";
    /** Tool/function name if applicable */
    toolName?: string;
    /** Tool/function arguments if applicable */
    toolArgs?: string;
    /** Tool/function result if applicable */
    toolResult?: unknown;
    /** Text content for reasoning or intermediate output */
    text?: string;
    /** Status of the update */
    status: "pending" | "streaming" | "completed";
    /** Agent ID that produced this update */
    agentId?: string;
    /** Executor ID that produced this update */
    executorId?: string;
}

/**
 * Complete state managed by the AgenticUI framework.
 */
export interface AgentState {
    isRunning: boolean;
    events: AnyAgenticUIEvent[];
    toolCalls: Map<string, ToolCall>;
    planningSteps: string[];
    planning: PlanningState;
    messages: ChatMessage[];
    /** Workspace updates for streaming activity (tool calls, reasoning, etc.) */
    workspaceUpdates: WorkspaceUpdate[];
    superSteps: SuperStep[];
    executors: Map<string, ExecutorInfo>;
    /** Consistent session identifier */
    runId?: string;
    error?: string;
    threads: AgentThread[];
}

export interface AgentThread {
    id: string;
    lastModified: string;
    metadata?: Record<string, string>;
}

/**
 * Context value exposed by AgenticUIProvider.
 */
export interface AgenticUIContextValue {
    /** Current agent state */
    state: AgentState;
    /** Resolved configuration with defaults */
    config: Required<Pick<AgenticUIConfig, "apiUrl">> & AgenticUIConfig;
    /** Resolved theme with defaults */
    theme: AgenticUITheme;
    /** Current session identifier */
    runId?: string;
    /** Send a message to the agent */
    sendMessage: (input: string) => Promise<void>;
    /** Reset the state */
    reset: () => void;
    /** Switch to a different thread (runId) */
    switchThread: (runId: string) => void;
    /** Create a new thread */
    newThread: () => void;
}

/**
 * Utility to find a custom component for a tool name from the registry.
 * Supports exact, case-insensitive, suffix, and normalized matching.
 */
export function findToolComponent(
    toolName: string,
    registry?: ToolResultComponentRegistry
): ComponentType<ToolResultComponentProps> | undefined {
    if (!registry) {
        return undefined;
    }

    // 1. Exact match
    if (registry[toolName]) {
        return registry[toolName];
    }

    const lowerToolName = toolName.toLowerCase();
    const normalize = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, "");
    const normalizedToolName = normalize(toolName);

    const entries = Object.entries(registry);

    // 2. Case-insensitive exact match
    const exactMatch = entries.find(([key]) => key.toLowerCase() === lowerToolName);
    if (exactMatch) {
        return exactMatch[1];
    }

    // 3. Normalized match (remove non-alphanumeric, compare lowercase)
    const normalizedMatch = entries.find(([key]) => {
        const nKey = normalize(key);
        if (!nKey) return false;
        const matched = (
            normalizedToolName.endsWith(nKey) ||
            nKey.endsWith(normalizedToolName) ||
            normalizedToolName.includes(nKey) ||
            nKey.includes(normalizedToolName)
        );
        return matched;
    });

    return normalizedMatch ? normalizedMatch[1] : undefined;
}

// Re-export event types for convenience
export type { AnyAgenticUIEvent, AgenticUIEventType } from "@/types/events";
export type { ChatMessage, SuperStep, ExecutorInfo } from "@/types/chat";
