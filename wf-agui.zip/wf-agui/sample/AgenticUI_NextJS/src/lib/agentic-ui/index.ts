// Copyright (c) Microsoft. All rights reserved.

/**
 * Agentic UI Framework
 *
 * A flexible, extensible React framework for building agentic chat interfaces.
 *
 * @example
 * ```tsx
 * import { AgenticUIProvider } from "@/lib/agentic-ui";
 *
 * export default function App() {
 *   return (
 *     <AgenticUIProvider config={{ apiUrl: "/api/agent" }}>
 *       <YourChatUI />
 *     </AgenticUIProvider>
 *   );
 * }
 * ```
 */

// Core Provider
export { AgenticUIProvider, useAgenticUIContext } from "./AgenticUIProvider";

// Types
export type {
    // Configuration
    AgenticUIConfig,
    AgenticUITheme,
    AgenticUICallbacks,
    AgenticUIContextValue,
    // Component Props
    EventComponentProps,
    ContentComponentProps,
    MessageComponentProps,
    InputComponentProps,
    HeaderComponentProps,
    PanelComponentProps,
    ContainerComponentProps,
    ToolResultComponentProps,
    // Registries
    EventComponentRegistry,
    ContentComponentRegistry,
    ToolResultComponentRegistry,
    // State
    AgentState,
    ToolCall,
    WorkspaceUpdate,
} from "./types";

export { defaultTheme, findToolComponent } from "./types";

// Content Rendering Utilities
export {
    isTextContent,
    extractText,
} from "./messages/ContentRenderer";

// Re-export event types for convenience
export type {
    AnyAgenticUIEvent,
    AgenticUIEventType,
    AgentUpdateEvent,
    RunStartedEvent as RunStartedEventType,
    RunFinishedEvent as RunFinishedEventType,
    RunErrorEvent as RunErrorEventType,
    ToolCallStartEvent as ToolCallStartEventType,
    ToolCallArgsEvent,
    ToolCallEndEvent,
    ToolCallResultEvent as ToolCallResultEventType,
    ExecutorInvokedEvent as ExecutorInvokedEventType,
    ExecutorCompletedEvent,
    ExecutorFailedEvent,
    SuperStepStartedEvent as SuperStepStartedEventType,
    SuperStepCompletedEvent,
    WorkflowOutputEvent,
    WorkflowWarningEvent,
    RequestInfoEvent,
    MessageContent,
    MessageContentText,
    MessageContentUsage,
    MessageContentToolCall,
    MessageContentToolResult,
} from "@/types/events";

export type {
    ChatMessage,
    SuperStep,
    ExecutorInfo,
} from "@/types/chat";
