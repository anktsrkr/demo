// Copyright (c) Microsoft. All rights reserved.

"use client";

import {
    createContext,
    useContext,
    useState,
    useCallback,
    useRef,
    useEffect,
    useMemo,
    type ReactNode,
} from "react";
import type {
    AgenticUIConfig,
    AgenticUIContextValue,
    AgenticUITheme,
    AgentState,
    ToolCall,
} from "./types";
import { defaultTheme } from "./types";
import type {
    AnyAgenticUIEvent,
    AgentUpdateEvent,
    MessageContent,
    MessageContentText,
    MessageContentUsage,
    TypedValue,
} from "@/types/events";
import { isTextContent, isToolCall, isToolResult } from "@/types/events";
import { normalizeValue } from "./utils";
import type { ChatMessage } from "@/types/chat";

// ============================================================================
// Context
// ============================================================================

const AgenticUIContext = createContext<AgenticUIContextValue | null>(null);

/**
 * Hook to access the AgenticUI context.
 * Must be used within an AgenticUIProvider.
 */
export function useAgenticUIContext(): AgenticUIContextValue {
    const context = useContext(AgenticUIContext);
    if (!context) {
        throw new Error(
            "useAgenticUIContext must be used within an AgenticUIProvider"
        );
    }
    return context;
}

// ============================================================================
// Helper Functions
// ============================================================================

function extractTextFromContents(contents: MessageContent[]): string {
    return contents
        .filter((c): c is MessageContentText => c.$type === "text")
        .map((c) => normalizeValue(c.text))
        .join("");
}

function extractUsageFromContents(
    contents: MessageContent[]
): ChatMessage["tokenUsage"] | undefined {
    const usage = contents.find(
        (c): c is MessageContentUsage => c.$type === "usage"
    );
    if (usage) {
        return {
            inputTokens: usage.details.inputTokenCount,
            outputTokens: usage.details.outputTokenCount,
            totalTokens: usage.details.totalTokenCount,
        };
    }
    return undefined;
}

function mergeTheme(
    base: AgenticUITheme,
    overrides?: Partial<AgenticUITheme>
): AgenticUITheme {
    if (!overrides) return base;

    return {
        name: overrides.name ?? base.name,
        variants: {
            messageBubble: {
                ...base.variants.messageBubble,
                ...overrides.variants?.messageBubble,
            },
            eventCard: {
                ...base.variants.eventCard,
                ...overrides.variants?.eventCard,
            },
            badge: {
                ...base.variants.badge,
                ...overrides.variants?.badge,
            },
        },
    };
}

// ============================================================================
// Initial State
// ============================================================================

const initialState: AgentState = {
    isRunning: false,
    events: [],
    toolCalls: new Map(),
    planningSteps: [],
    planning: {
        goals: [],
        goalStatuses: [],
        steps: [],
        status: "idle",
    },
    messages: [],
    workspaceUpdates: [],
    superSteps: [],
    executors: new Map(),
    threads: [],
};

// ============================================================================
// Provider Props
// ============================================================================

interface AgenticUIProviderProps {
    /** Configuration for the framework */
    config: AgenticUIConfig;
    /** Child components */
    children: ReactNode;
}

// ============================================================================
// Provider Component
// ============================================================================

/**
 * AgenticUIProvider - Main context provider for the Agentic UI Framework.
 *
 * Wraps your application and provides:
 * - State management for agent interactions
 * - SSE streaming for real-time updates
 * - Custom component registry access
 * - Theme configuration
 *
 * @example
 * ```tsx
 * <AgenticUIProvider config={{ apiUrl: "/api/agent" }}>
 *   <AgenticUILayout />
 * </AgenticUIProvider>
 * ```
 */
export function AgenticUIProvider({
    config,
    children,
}: AgenticUIProviderProps) {
    const [runId, setRunId] = useState<string | undefined>(undefined);
    const [state, setState] = useState<AgentState>({ ...initialState, runId });

    // Initialize runId from config or localStorage
    useEffect(() => {
        if (typeof window !== "undefined") {
            const savedRunId = localStorage.getItem("agentic_ui_run_id");
            const initialRunId = config.runId || savedRunId || `run-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

            if (initialRunId !== runId) {
                setRunId(initialRunId);
                localStorage.setItem("agentic_ui_run_id", initialRunId);
                // setState done in sync effect below or via fetchHistory
            }
        }
    }, [config.runId]); // Dependency on config.runId only

    // Fetch threads list
    const fetchThreads = useCallback(async () => {
        try {
            const res = await fetch(`${config.apiUrl}/threads`);
            if (res.ok) {
                const threads = await res.json();
                setState(prev => ({ ...prev, threads }));
            }
        } catch (e) {
            console.error("Failed to fetch threads", e);
        }
    }, [config.apiUrl]);

    // Initial fetch of threads
    useEffect(() => {
        fetchThreads();
        const interval = setInterval(fetchThreads, 10000); // Poll every 10s? Or just rely on manual refresh?
        return () => clearInterval(interval);
    }, [fetchThreads]);

    // Fetch history when runId changes
    useEffect(() => {
        if (!runId) return;

        const loadHistory = async () => {
            // Reset state for new run (mostly)
            setState(prev => ({
                ...initialState,
                runId,
                threads: prev.threads, // Keep threads
                isRunning: false // Start as idle
            }));

            try {
                const res = await fetch(`${config.apiUrl}/threads/${runId}/history`);
                if (res.ok) {
                    const messages = await res.json();
                    if (Array.isArray(messages) && messages.length > 0) {
                        // Restore messages
                        // Backend returns: { role: "user"|"assistant", contents: [{$type:"text",text:"..."}] }
                        const restoredMessages = messages.map((m: any, idx: number) => {
                            // Handle contents extraction - it's an array of content items
                            const contentsArray = m.contents || m.Contents || [];
                            const textContent = contentsArray
                                .filter((c: any) => c.$type === "text" || c.type === "text")
                                .map((c: any) => c.text || c.Text || "")
                                .join("");

                            return {
                                id: m.id || m.Id || `hist-${idx}`,
                                role: m.role || m.Role?.Label || m.Role || "unknown",
                                content: textContent,
                                contents: contentsArray.length > 0 ? contentsArray : [{ $type: "text", text: textContent }],
                                createdAt: m.createdAt || m.CreatedAt || new Date().toISOString(),
                                isStreaming: false
                            };
                        });

                        setState(prev => ({ ...prev, messages: restoredMessages }));
                    }
                }
            } catch (e) {
                console.error("Failed to load history", e);
            }
        };

        loadHistory();
    }, [runId, config.apiUrl]);

    const processedEvents = useRef<Set<string>>(new Set());
    const stateRef = useRef(state);

    // Keep ref in sync with state
    useEffect(() => {
        stateRef.current = state;
    }, [state]);

    // Merge theme with defaults
    const theme = useMemo(
        () => mergeTheme(defaultTheme, config.theme),
        [config.theme]
    );

    // Sync state from the already-updated Ref (Legacy method removed)
    // Legacy handleAgentUpdate removed as it is no longer used for chat messages


    // Process incoming SSE events
    const processEvent = useCallback(
        (event: AnyAgenticUIEvent) => {
            if (event.eventType === "AGENT_UPDATE") {
                const agentUpdate = event as AgentUpdateEvent;
                // Avoid processing identical event objects twice
                // Simplified key to avoid content-based deduplication
                const eventKey = `${agentUpdate.eventType}-${agentUpdate.update.messageId}-${agentUpdate.timestamp}`;

                if (processedEvents.current.has(eventKey)) {
                    return;
                }
                processedEvents.current.add(eventKey);

                // Keep set size manageable
                if (processedEvents.current.size > 1000) {
                    const first = processedEvents.current.values().next().value;
                    if (first) {
                        processedEvents.current.delete(first);
                    }
                }

                // updateStreamingRef call removed (legacy)
            } else {
                console.log(`[processEvent] Received event: ${event.eventType}`);
            }

            // Call onEvent callback if provided
            config.callbacks?.onEvent?.(event);

            setState((prev) => {
                const newState = { ...prev, events: [...prev.events, event] };

                switch (event.eventType) {
                    case "RUN_STARTED":
                        newState.isRunning = true;
                        newState.error = undefined;
                        break;

                    case "RUN_FINISHED":
                        newState.isRunning = false;
                        break;

                    case "RUN_ERROR":
                        newState.isRunning = false;
                        newState.error = event.error;
                        config.callbacks?.onError?.(new Error(event.error));
                        break;
                    case "AGENT_PLANNING_START": {
                        const startEvent = event as any;
                        const normalizedGoals = (startEvent.goals || []).map((g: any) => normalizeValue(g));
                        newState.planning = {
                            ...prev.planning,
                            goals: normalizedGoals,
                            goalStatuses: normalizedGoals.map(() => "pending"),
                            steps: [],
                            status: "planning",
                        };
                        break;
                    }

                    case "AGENT_PLANNING_STEP": {
                        const stepEvent = event as any;
                        newState.planningSteps = [...prev.planningSteps, normalizeValue(stepEvent.action)];

                        // Update goal status if provided
                        let updatedGoalStatuses = [...prev.planning.goalStatuses];
                        if (typeof stepEvent.goal_index === "number" && stepEvent.goal_status) {
                            updatedGoalStatuses[stepEvent.goal_index] = stepEvent.goal_status;
                        }

                        newState.planning = {
                            ...prev.planning,
                            status: stepEvent.goal_status === "executing" ? "executing" : prev.planning.status,
                            goalStatuses: updatedGoalStatuses,
                            steps: [
                                ...prev.planning.steps,
                                {
                                    action: normalizeValue(stepEvent.action),
                                    reasoning: normalizeValue(stepEvent.reasoning),
                                    timestamp: stepEvent.timestamp,
                                    goal_index: stepEvent.goal_index,
                                    goal_status: stepEvent.goal_status,
                                },
                            ],
                        };
                        break;
                    }

                    case "AGENT_PLANNING_END":
                        newState.planning = {
                            ...prev.planning,
                            finalPlan: event.final_plan,
                            status: "completed",
                            steps: [
                                ...prev.planning.steps,
                                {
                                    action: "Mission Complete",
                                    reasoning: event.final_plan,
                                    timestamp: event.timestamp || new Date().toISOString(),
                                },
                            ],
                        };
                        break;

                    case "AGENT_UPDATE": {
                        console.log(`[setState] AGENT_UPDATE: processing for workspace`);

                        // Extract text content from the update
                        const textDelta = event.update.contents
                            .filter(c => c.$type === "text")
                            // @ts-ignore - we know it has text property if type is text
                            .map(c => c.text)
                            .join("");

                        if (textDelta) {
                            // Update the last workspace update if it is a streaming text, or create new one
                            const lastIdx = prev.workspaceUpdates.length - 1;
                            const last = prev.workspaceUpdates[lastIdx];

                            if (last && last.type === "text" && last.status === "streaming") {
                                // Update existing streaming text block
                                const updatedLast = {
                                    ...last,
                                    text: (last.text || "") + textDelta
                                };
                                newState.workspaceUpdates = [
                                    ...prev.workspaceUpdates.slice(0, lastIdx),
                                    updatedLast
                                ];
                            } else {
                                // Create new streaming text block
                                newState.workspaceUpdates = [
                                    ...prev.workspaceUpdates,
                                    {
                                        id: `text-${Date.now()}`,
                                        timestamp: event.timestamp || new Date().toISOString(),
                                        type: "text",
                                        text: textDelta,
                                        status: "streaming"
                                    }
                                ];
                            }
                        }

                        // NOTE: We do NOT update newState.messages here anymore.
                        // Chat bubbles are reserved for WORKFLOW_OUTPUT only.
                        break;
                    }

                    case "TOOL_CALL_START": {
                        const toolCalls = new Map(prev.toolCalls);
                        toolCalls.set(event.tool_call_id, {
                            id: event.tool_call_id,
                            name: event.tool_name,
                            args: "",
                            status: "pending",
                        });
                        newState.toolCalls = toolCalls;

                        // Add to workspace updates for real-time display
                        newState.workspaceUpdates = [
                            ...prev.workspaceUpdates,
                            {
                                id: event.tool_call_id,
                                timestamp: event.timestamp,
                                type: "tool_call" as const,
                                toolName: event.tool_name,
                                toolArgs: "",
                                status: "pending" as const,
                            },
                        ];
                        break;
                    }

                    case "TOOL_CALL_ARGS": {
                        const toolCalls = new Map(prev.toolCalls);
                        const existing = toolCalls.get(event.tool_call_id);
                        if (existing) {
                            toolCalls.set(event.tool_call_id, {
                                ...existing,
                                args: existing.args + event.args_delta,
                            });
                            newState.toolCalls = toolCalls;

                            // Update workspace update with streaming args
                            newState.workspaceUpdates = prev.workspaceUpdates.map((u) =>
                                u.id === event.tool_call_id
                                    ? { ...u, toolArgs: (u.toolArgs || "") + event.args_delta, status: "streaming" as const }
                                    : u
                            );
                        }
                        break;
                    }

                    case "TOOL_CALL_RESULT": {
                        const toolCalls = new Map(prev.toolCalls);
                        const existing = toolCalls.get(event.tool_call_id);
                        if (existing) {
                            toolCalls.set(event.tool_call_id, {
                                ...existing,
                                result: event.result,
                                status: "completed",
                            });
                            newState.toolCalls = toolCalls;

                            // Update workspace update with completed result
                            newState.workspaceUpdates = prev.workspaceUpdates.map((u) =>
                                u.id === event.tool_call_id
                                    ? { ...u, toolResult: event.result, status: "completed" as const }
                                    : u
                            );
                        }
                        break;
                    }

                    case "SUPERSTEP_STARTED": {
                        newState.superSteps = [
                            ...prev.superSteps,
                            {
                                stepNumber: event.step_number,
                                status: "started",
                                executors: [],
                                startTime: event.timestamp,
                            },
                        ];
                        break;
                    }

                    case "SUPERSTEP_COMPLETED": {
                        newState.superSteps = prev.superSteps.map((step) => {
                            if (
                                step.stepNumber === event.step_number &&
                                step.status === "started"
                            ) {
                                return {
                                    ...step,
                                    status: "completed" as const,
                                    endTime: event.timestamp,
                                };
                            }
                            return step;
                        });
                        break;
                    }

                    case "EXECUTOR_INVOKED": {
                        const executors = new Map(prev.executors);
                        const normalizedInput = normalizeValue(event.input);
                        executors.set(event.executor_id, {
                            id: event.executor_id,
                            status: "invoked",
                            input: normalizedInput,
                        });
                        newState.executors = executors;

                        const currentStep = prev.superSteps.find(
                            (s) => s.status === "started"
                        );
                        if (currentStep) {
                            newState.superSteps = prev.superSteps.map((step) => {
                                if (step.stepNumber === currentStep.stepNumber) {
                                    return {
                                        ...step,
                                        executors: [...step.executors, event.executor_id],
                                    };
                                }
                                return step;
                            });
                        }
                        break;
                    }

                    case "EXECUTOR_COMPLETED": {
                        const executors = new Map(prev.executors);
                        const existing = executors.get(event.executor_id);
                        if (existing) {
                            const normalizedOutput = normalizeValue(event.output);
                            executors.set(event.executor_id, {
                                ...existing,
                                status: "completed",
                                output: normalizedOutput,
                            });
                            newState.executors = executors;

                            // If there's an output string so we can log it (no longer creates message)
                            if (typeof event.output === "string") {
                                console.log(`[EXECUTOR_COMPLETED] Output received for ${event.executor_id}:`, event.output);
                                // No message creation for EXECUTOR_COMPLETED - we only use WORKFLOW_OUTPUT
                            }
                        }
                        break;
                    }

                    case "EXECUTOR_FAILED": {
                        const executors = new Map(prev.executors);
                        const existing = executors.get(event.executor_id);
                        if (existing) {
                            executors.set(event.executor_id, {
                                ...existing,
                                status: "failed",
                                error: event.error,
                            });
                            newState.executors = executors;
                        }
                        break;
                    }

                    case "WORKFLOW_OUTPUT": {
                        // WORKFLOW_OUTPUT is now the sole source of chat messages
                        // No check for hasStreamingMessages anymore as streaming doesn't create chat messages


                        if (event.output) {
                            let newMessages: ChatMessage[] = [];

                            const normalizedOutput = normalizeValue(event.output);

                            if (Array.isArray(normalizedOutput)) {
                                newMessages = normalizedOutput.map(
                                    (msg, idx) => ({
                                        id: `workflow-output-${Date.now()}-${idx}`,
                                        role: msg.role,
                                        content: extractTextFromContents(msg.contents),
                                        contents: msg.contents,
                                        authorName: msg.authorName ?? undefined,
                                        createdAt: msg.createdAt ?? event.timestamp,
                                        isStreaming: false,
                                        tokenUsage: extractUsageFromContents(msg.contents),
                                    })
                                );
                            } else if (typeof normalizedOutput === "string") {
                                // CRITICAL FIX: Handle string output by wrapping it in a message
                                newMessages = [{
                                    id: `workflow-output-string-${Date.now()}`,
                                    role: "assistant",
                                    content: normalizedOutput,
                                    contents: [{ $type: "text", text: normalizedOutput }],
                                    createdAt: event.timestamp,
                                    isStreaming: false,
                                }];
                            }

                            const existingIds = new Set(prev.messages.map((m) => m.id));
                            const filteredNew = newMessages.filter(
                                (m) => !existingIds.has(m.id)
                            );

                            if (filteredNew.length > 0) {
                                newState.messages = [...prev.messages, ...filteredNew];
                            }
                        }
                        break;
                    }
                }

                return newState;
            });
        },
        [config.callbacks]
    );

    // Send message to the API
    const sendMessage = useCallback(
        async (input: string) => {
            const userMessage: ChatMessage = {
                id: `user-${Date.now()}`,
                role: "user",
                content: input,
                contents: [{ $type: "text", text: input }],
                createdAt: new Date().toISOString(),
                isStreaming: false,
            };

            setState((prev) => ({
                ...prev,
                isRunning: true,
                events: [],
                toolCalls: new Map(),
                planningSteps: [],
                planning: initialState.planning,
                messages: [...prev.messages, userMessage],
                workspaceUpdates: [],
                superSteps: [],
                executors: new Map(),
                error: undefined,
            }));

            processedEvents.current.clear();
            processedEvents.current.clear();

            try {
                const response = await fetch(config.apiUrl, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        Accept: "text/event-stream",
                    },
                    body: JSON.stringify({ input, runId }),
                });

                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                const reader = response.body?.getReader();
                if (!reader) {
                    throw new Error("No response body");
                }

                const decoder = new TextDecoder();
                let buffer = "";

                while (true) {
                    const { done, value } = await reader.read();
                    if (done) break;

                    buffer += decoder.decode(value, { stream: true });
                    const parts = buffer.split("\n\n");
                    buffer = parts.pop() || "";

                    for (const part of parts) {
                        for (const line of part.split("\n")) {
                            if (line.startsWith("data: ")) {
                                const data = line.slice(6).trim();
                                if (data) {
                                    try {
                                        const event = JSON.parse(data) as AnyAgenticUIEvent;
                                        console.log("Received event:", JSON.stringify(event, null, 2));
                                        processEvent(event);
                                    } catch (error) {
                                        console.warn("Failed to parse SSE data:", data, error);
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (error) {
                const err = error instanceof Error ? error : new Error("Unknown error");
                config.callbacks?.onError?.(err);
                setState((prev) => ({
                    ...prev,
                    isRunning: false,
                    error: err.message,
                }));
            }
        },
        [config.apiUrl, config.callbacks, processEvent, runId, fetchThreads]
    );

    // Switch Thread
    const switchThread = useCallback((newRunId: string) => {
        if (newRunId === runId) return;
        setRunId(newRunId);
        localStorage.setItem("agentic_ui_run_id", newRunId);
        // State reset handled by useEffect [runId]
    }, [runId]);

    // New Thread
    const newThread = useCallback(() => {
        const newRunId = `run-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        switchThread(newRunId);
    }, [switchThread]);

    // Reset state
    const reset = newThread; // Alias reset to newThread for "Clear Chat" behavior in this threaded model

    // Build context value
    const contextValue = useMemo<AgenticUIContextValue>(
        () => ({
            state,
            config: { ...config, apiUrl: config.apiUrl },
            theme,
            runId,
            sendMessage,
            reset,
            switchThread,
            newThread,
        }),
        [state, config, theme, runId, sendMessage, reset, switchThread, newThread]
    );

    return (
        <AgenticUIContext.Provider value={contextValue}>
            {children}
        </AgenticUIContext.Provider>
    );
}
