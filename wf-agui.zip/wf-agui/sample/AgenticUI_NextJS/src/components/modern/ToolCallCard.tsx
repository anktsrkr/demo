import { type EventComponentProps } from "@/lib/agentic-ui";
import { type AnyAgenticUIEvent } from "@/types/events";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { vscDarkPlus } from "react-syntax-highlighter/dist/esm/styles/prism";

// Extend the props to include internal tool state management if needed, 
// though typically the provider handles state. 
// For this visual component, we mainly care about the event data.
// However, the standard EventRenderer passes the specific event that triggered the render.
// The PanelRenderer uses a list of events.
// For the chat stream, we usually see TOOL_CALL_START, then updates.
// But mostly we want to visualize the *State* of the tool call if possible, 
// or at least the start event.
// Actually, the plan says "Tool Outputs: Renders ToolCallCard for tool events embedded in the stream".

export function ToolCallCard({ event }: EventComponentProps) {
    const toolEvent = event as AnyAgenticUIEvent & {
        eventType: "TOOL_CALL_START";
        tool_name: string;
        tool_call_id: string;
    };

    // In a real app we might want to subscribe to updates for this tool call ID to show args/results lively.
    // For now, we'll render the clear "Tool Start" card.

    return (
        <div className="collapse collapse-arrow bg-base-200/50 border border-base-300/50 rounded-2xl my-3 shadow-sm hover:shadow-md transition-all duration-300">
            <input type="checkbox" className="peer" />
            <div className="collapse-title flex items-center gap-3 min-h-[3rem] py-2">
                <div className="w-9 h-9 rounded-xl bg-secondary/10 flex items-center justify-center text-secondary shadow-inner">
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        strokeWidth={1.5}
                        stroke="currentColor"
                        className="w-5 h-5"
                    >
                        <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="M14.25 9.75L16.5 12l-2.25 2.25m-4.5 0L7.5 12l2.25-2.25M6 20.25h12A2.25 2.25 0 0020.25 18V6A2.25 2.25 0 0018 3.75H6A2.25 2.25 0 003.75 6v12A2.25 2.25 0 006 20.25z"
                        />
                    </svg>
                </div>
                <div className="flex flex-col">
                    <span className="font-semibold text-sm">Use Tool</span>
                    <span className="text-xs font-mono opacity-60 text-secondary">
                        {toolEvent.tool_name}
                    </span>
                </div>
                <div className="ml-auto flex items-center gap-2">
                    <span className="badge badge-sm badge-ghost bg-base-300/50 border-none text-[10px] font-bold uppercase tracking-wider opacity-60">
                        {toolEvent.tool_call_id.slice(0, 8)}
                    </span>
                </div>
            </div>
            <div className="collapse-content text-sm bg-base-300/20 backdrop-blur-sm">
                <div className="pt-2 opacity-70">
                    Tool call initiated. Waiting for arguments and execution...
                </div>
            </div>
        </div>
    );
}
