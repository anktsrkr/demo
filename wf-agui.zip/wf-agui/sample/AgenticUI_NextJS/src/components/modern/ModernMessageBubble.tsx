"use client";
import React from "react";

import { useAgenticUIContext, type MessageComponentProps } from "@/lib/agentic-ui";
import { extractText } from "@/lib/agentic-ui";
import { isTextContent, isToolCall, isToolResult, isUsageContent, type MessageContent } from "@/types/events";
import clsx from "clsx";
import ReactMarkdown from "react-markdown";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { vscDarkPlus } from "react-syntax-highlighter/dist/esm/styles/prism";
import remarkGfm from "remark-gfm";

function getAgentColor(agentId?: string): string {
    if (!agentId) return "bg-primary";
    const hash = agentId.split("").reduce((acc, char) => {
        return char.charCodeAt(0) + ((acc << 5) - acc);
    }, 0);
    const colors = [
        "bg-primary",
        "bg-secondary",
        "bg-accent",
        "bg-info",
        "bg-success",
        "bg-warning",
    ];
    return colors[Math.abs(hash) % colors.length];
}

export function ModernMessageBubble({ message, onToggleWorkspace }: MessageComponentProps) {
    const { config, state } = useAgenticUIContext();
    const isUser = message.role === "user";
    const isSystem = message.role === "system";
    const agentColor = getAgentColor(message.agentId);
    const bubbleColor = isUser ? "chat-bubble-primary" : "";

    // System messages have special styling
    if (isSystem) {
        return (
            <div className="flex justify-center my-4 opacity-70">
                <div className="divider opacity-30 text-[10px] uppercase font-bold tracking-widest px-8">
                    {extractText(message.contents)}
                </div>
            </div>
        );
    }

    const combinedText = message.content || extractText(message.contents);

    // Render contents in order, grouping consecutive text and related tool interactions
    const renderedContent = React.useMemo(() => {
        const elements: React.ReactNode[] = [];
        const consumedIds = new Set<string>();

        // If contents is empty, fallback to message.content
        if (message.contents.length === 0 && message.content) {
            elements.push(
                <div key="fallback-text" className={clsx("prose prose-sm max-w-none break-words overflow-x-auto", isUser ? "prose-invert text-primary-content" : "text-base-content")}>
                    <ReactMarkdown
                        remarkPlugins={[remarkGfm]}
                        components={{
                            code({ node, inline, className, children, ...props }: any) {
                                const match = /language-(\w+)/.exec(className || "");
                                return !inline && match ? (
                                    <SyntaxHighlighter
                                        {...props}
                                        style={vscDarkPlus}
                                        language={match[1]}
                                        PreTag="div"
                                        customStyle={{ margin: 0, borderRadius: '0.5rem', fontSize: '0.85em' }}
                                    >
                                        {String(children).replace(/\n$/, "")}
                                    </SyntaxHighlighter>
                                ) : (
                                    <code className={clsx("bg-base-300/30 rounded px-1", className)} {...props}>
                                        {children}
                                    </code>
                                );
                            }
                        }}
                    >
                        {message.content}
                    </ReactMarkdown>
                </div>
            );
        }

        for (let i = 0; i < message.contents.length; i++) {
            const content = message.contents[i];

            if (isUsageContent(content)) continue;

            if (isTextContent(content)) {
                // Collect consecutive text chunks, ignoring non-visual elements like usage
                let text = content.text;
                while (i + 1 < message.contents.length) {
                    const next = message.contents[i + 1];
                    if (isTextContent(next)) {
                        i++;
                        text += next.text;
                    } else if (isUsageContent(next)) {
                        i++; // Skip usage and keep looking for text
                    } else {
                        break; // Stop at tool calls or other visual elements
                    }
                }
                elements.push(
                    <div key={`text-${i}`} className={clsx("prose prose-sm max-w-none break-words overflow-x-auto", isUser ? "prose-invert text-primary-content" : "text-base-content")}>
                        <ReactMarkdown
                            remarkPlugins={[remarkGfm]}
                            components={{
                                code({ node, inline, className, children, ...props }: any) {
                                    const match = /language-(\w+)/.exec(className || "");
                                    return !inline && match ? (
                                        <SyntaxHighlighter
                                            {...props}
                                            style={vscDarkPlus}
                                            language={match[1]}
                                            PreTag="div"
                                            customStyle={{ margin: 0, borderRadius: '0.5rem', fontSize: '0.85em' }}
                                        >
                                            {String(children).replace(/\n$/, "")}
                                        </SyntaxHighlighter>
                                    ) : (
                                        <code className={clsx("bg-base-300/30 rounded px-1", className)} {...props}>
                                            {children}
                                        </code>
                                    );
                                }
                            }}
                        >
                            {text}
                        </ReactMarkdown>
                        {message.isStreaming && i === message.contents.length - 1 && (
                            <span className="inline-block w-2 h-4 bg-current animate-pulse ml-1 align-middle"></span>
                        )}
                    </div>
                );
            } else if (isToolCall(content) || isToolResult(content)) {
                // Tool calls and results are now rendered in the Agent Workspace panel,
                // not in chat bubbles. Skip them here for a cleaner chat experience.
                continue;
            }
        }
        return elements;
    }, [message.contents, message.id, message.role, message.isStreaming, config.toolResultComponents, isUser]);

    return (
        <div className={clsx("chat", isUser ? "chat-end" : "chat-start group")}>
            <div className="chat-image avatar">
                <div className={clsx("w-10 rounded-full shadow-sm", isUser ? "bg-neutral text-neutral-content" : agentColor + " text-white")}>
                    <span className="text-sm font-bold flex items-center justify-center h-full">
                        {isUser ? "You" : (message.authorName?.[0] || "AI")}
                    </span>
                </div>
            </div>

            <div className="chat-header mb-1 opacity-50 text-xs flex items-center gap-2">
                {isUser ? "You" : (message.authorName || "Assistant")}
                <time className="text-[10px]">{new Date(message.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</time>
            </div>

            <div className={clsx(
                "chat-bubble shadow-md transition-shadow hover:shadow-lg",
                bubbleColor
            )}>
                {/* Ordered Content (Text and Tools) */}
                <div className="space-y-4">
                    {renderedContent}
                </div>

            </div>

            {message.tokenUsage && (
                <div className="chat-footer mt-1 flex items-center gap-2 transition-opacity duration-200 text-[10px] text-base-content/50">
                    <div className="flex items-center gap-3 mr-auto bg-base-300/30 rounded-full px-2 py-1">
                        {/* Input Tokens */}
                        <div className="flex items-center gap-1" title="Input Tokens">

                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-3 h-3 opacity-70">
                                <path fillRule="evenodd" d="M10 17a.75.75 0 01-.75-.75V5.612L5.29 9.77a.75.75 0 01-1.08-1.04l5.25-5.5a.75.75 0 011.08 0l5.25 5.5a.75.75 0 11-1.08 1.04l-3.96-4.158V16.25A.75.75 0 0110 17z" clipRule="evenodd" />
                            </svg>
                            <span>{message.tokenUsage.inputTokens}</span>
                        </div>
                        {/* Output Tokens */}
                        <div className="flex items-center gap-1 border-l border-base-content/10 pl-3" title="Output Tokens">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-3 h-3 opacity-70">
                                <path fillRule="evenodd" d="M10 3a.75.75 0 01.75.75v10.638l3.96-4.158a.75.75 0 111.08 1.04l-5.25 5.5a.75.75 0 01-1.08 0l-5.25-5.5a.75.75 0 111.08-1.04l3.96 4.158V3.75A.75.75 0 0110 3z" clipRule="evenodd" />
                            </svg>
                            <span>{message.tokenUsage.outputTokens}</span>
                        </div>
                        {/* Total Tokens */}
                        <div className="flex items-center gap-1 border-l border-base-content/10 pl-3 font-semibold text-base-content/70" title="Total Tokens">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-3 h-3 opacity-70">
                                <path fillRule="evenodd" d="M6 4.75A.75.75 0 016.75 4h10.5a.75.75 0 010 1.5H6.75A.75.75 0 016 4.75zM6 10a.75.75 0 01.75-.75h10.5a.75.75 0 010 1.5H6.75A.75.75 0 016 10zm0 5.25a.75.75 0 01.75-.75h10.5a.75.75 0 010 1.5H6.75a.75.75 0 01-.75-.75zM2 4.75A.75.75 0 012.75 4h1.5a.75.75 0 010 1.5h-1.5A.75.75 0 012 4.75zm0 5.25a.75.75 0 01.75-.75h1.5a.75.75 0 010 1.5h-1.5a.75.75 0 01-.75-.75zm0 5.25a.75.75 0 01.75-.75h1.5a.75.75 0 010 1.5h-1.5a.75.75 0 01-.75-.75z" clipRule="evenodd" />
                            </svg>
                            <span>{message.tokenUsage.totalTokens}</span>
                        </div>
                    </div>

                    {!isUser && !message.isStreaming && (
                        <div className="flex items-center gap-1">
                            {state.planning.steps.length > 0 && onToggleWorkspace && (
                                <div className="tooltip tooltip-bottom" data-tip="View Trace">
                                    <button
                                        onClick={onToggleWorkspace}
                                        className="btn btn-ghost btn-xs btn-square text-base-content/60 hover:text-primary"
                                    >
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
                                            <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456z" />
                                        </svg>
                                    </button>
                                </div>
                            )}
                            <MessageActions content={combinedText} />
                        </div>
                    )}
                </div>
            )}
            {!message.tokenUsage && !isUser && !message.isStreaming && (
                <div className="chat-footer mt-1 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 h-6">
                    <div className="flex items-center gap-1 ml-auto">
                        {state.planning.steps.length > 0 && onToggleWorkspace && (
                            <div className="tooltip tooltip-bottom" data-tip="View Trace">
                                <button
                                    onClick={onToggleWorkspace}
                                    className="btn btn-ghost btn-xs btn-square text-base-content/60 hover:text-primary"
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456z" />
                                    </svg>
                                </button>
                            </div>
                        )}
                        <MessageActions content={combinedText} />
                    </div>
                </div>
            )}
        </div>
    );
}

function MessageActions({ content }: { content: string }) {
    const [copied, setCopied] = React.useState(false);
    const [liked, setLiked] = React.useState<boolean | null>(null);

    const handleCopy = async () => {
        try {
            await navigator.clipboard.writeText(content);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        } catch (err) {
            console.error('Failed to copy:', err);
        }
    };

    return (
        <>
            <div className="tooltip tooltip-bottom" data-tip={copied ? "Copied!" : "Copy"}>
                <button onClick={handleCopy} className="btn btn-ghost btn-xs btn-square text-base-content/60 hover:text-primary">
                    {copied ? (
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4 text-success">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                    ) : (
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 17.25v3.375c0 .621-.504 1.125-1.125 1.125h-9.75a1.125 1.125 0 01-1.125-1.125V7.875c0-.621.504-1.125 1.125-1.125H6.75a9.06 9.06 0 011.5.124m7.5 10.376h3.375c.621 0 1.125-.504 1.125-1.125V11.25c0-4.46-3.243-8.161-7.5-8.876a9.06 9.06 0 00-1.5-.124H9.375c-.621 0-1.125.504-1.125 1.125v3.5m7.5 10.375H9.375a1.125 1.125 0 01-1.125-1.125v-9.25m12 6.625v-1.875a3.375 3.375 0 00-3.375-3.375h-1.5a1.125 1.125 0 01-1.125-1.125v-1.5a3.375 3.375 0 00-3.375-3.375H9.75" />
                        </svg>
                    )}
                </button>
            </div>

            <div className="tooltip tooltip-bottom" data-tip="Regenerate">
                <button className="btn btn-ghost btn-xs btn-square text-base-content/60 hover:text-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99" />
                    </svg>
                </button>
            </div>

            <div className="flex items-center border-l border-base-content/10 ml-1 pl-1 space-x-0.5">
                <button
                    onClick={() => setLiked(liked === true ? null : true)}
                    className={clsx("btn btn-ghost btn-xs btn-square hover:text-success", liked === true && "text-success")}
                >
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M6.633 10.5c.806 0 1.533-.446 2.031-1.08a9.041 9.041 0 012.861-2.4c.723-.384 1.35-.956 1.653-1.715a4.498 4.498 0 00.322-1.672V3a.75.75 0 01.75-.75A2.25 2.25 0 0116.5 4.5c0 1.152-.26 2.247-.723 3.218-.266.558.107 1.282.725 1.282h3.126c1.026 0 1.945.694 2.054 1.715.045.422.068.85.068 1.285a11.95 11.95 0 01-2.649 7.521c-.388.482-.987.729-1.605.729H13.48c-.483 0-.964-.078-1.423-.23l-3.114-1.04a4.501 4.501 0 00-1.423-.23H5.904M14.25 9h2.25M5.904 18.75c.083.205.173.405.27.602.197.4-.078.898-.523.898h-.908c-.889 0-1.713-.518-1.972-1.368a12 12 0 01-.521-3.507c0-1.553.295-3.036.831-4.398C3.287 9.463 4.107 9 5.097 9h.565c.445 0 .72.498.523.898a8.932 8.932 0 01-.27.602" />
                    </svg>
                </button>
                <button
                    onClick={() => setLiked(liked === false ? null : false)}
                    className={clsx("btn btn-ghost btn-xs btn-square hover:text-error", liked === false && "text-error")}
                >
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M7.5 15h2.25m8.024-9.75c.011.05.028.1.052.148.591 1.2.924 2.55.924 3.977a8.96 8.96 0 01-.999 4.125m.023-8.25c-.076-.365.183-.75.575-.75h.908c.889 0 1.713.518 1.972 1.368.339 1.11.521 2.287.521 3.507 0 1.553-.295 3.036-.831 4.398C20.713 14.537 19.893 15 18.903 15h-.565c-.445 0-.72-.498-.523-.898a8.913 8.913 0 01.27-.602M12.375 14.25a6.76 6.76 0 01-5.09-5.25m0-9.75c0 .242.18-.088.24-.138.806-.525 1.533-1.031 2.031-1.75a9.041 9.041 0 002.861 2.4c.723.384 1.35.956 1.653 1.715a4.498 4.498 0 01.322 1.672V19.5a.75.75 0 00.75.75h4.5c1.152 0 2.247.26 3.218.723.558.266 1.282-.107 1.282-.725V17.124c0-1.026.694-1.945 1.715-2.054.422-.045.85-.068 1.285-.068a11.95 11.95 0 007.521-2.649c.482-.388.729-.987.729-1.605V4.52a.75.75 0 00-.23-1.423l-1.04-3.114a4.501 4.501 0 01-.23-1.423H6.75" />
                    </svg>
                </button>
            </div>
        </>
    );
}
