"use client";

import { useState, useEffect } from "react";
import clsx from "clsx";

import { useAgenticUIContext } from "@/lib/agentic-ui";
import { ModernSidebar } from "./ModernSidebar";
import { ModernMessageList } from "./ModernMessageList";
import { InputArea } from "./InputArea";
import { PlanningProgress } from "./PlanningProgress";
import { AgentWorkspaceStream } from "./AgentWorkspaceStream";

export function ModernLayout() {
    const { state, sendMessage } = useAgenticUIContext();
    const [isSidebarOpen, setIsSidebarOpen] = useState(true);
    const [showWorkspacePanel, setShowWorkspacePanel] = useState(false);

    const isExecuting = state.planning.status === "executing";
    const isPanelVisible = isExecuting || showWorkspacePanel;

    // Auto-minimize sidebar when execution starts
    useEffect(() => {
        if (isExecuting && isSidebarOpen) {
            setIsSidebarOpen(false);
        }
    }, [isExecuting]);

    return (
        <div className="drawer lg:drawer-open overflow-hidden">
            <input id="my-drawer-2" type="checkbox" className="drawer-toggle" />

            {/* Main Content Area */}
            <div className="drawer-content flex flex-col h-screen bg-base-100 transition-all duration-500 ease-in-out relative">

                {/* Navbar */}
                <div className="w-full navbar bg-base-100/60 backdrop-blur-xl sticky top-0 z-30 border-b border-base-200/50 h-14 min-h-[3.5rem] px-4">
                    <div className="flex-none lg:hidden">
                        <label htmlFor="my-drawer-2" aria-label="open sidebar" className="btn btn-square btn-ghost btn-sm">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="inline-block w-5 h-5 stroke-current"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
                        </label>
                    </div>
                    <div className="flex-1 px-4">
                        <div className="text-sm font-bold tracking-tight opacity-80 flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
                            Agentic Workflow
                        </div>
                    </div>
                    <div className="flex-none hidden md:block">
                        <div className={clsx(
                            "text-[10px] font-bold uppercase tracking-widest px-4 py-1.5 rounded-full border border-base-300/50 bg-base-200/50 transition-colors duration-300",
                            state.isRunning ? "text-primary border-primary/20" : "opacity-40"
                        )}>
                            {state.isRunning ? "Running" : "Idle"}
                        </div>
                    </div>
                </div>

                {/* Content Wrapper (Split View Container) */}
                <div className="flex-1 overflow-hidden flex flex-row w-full">

                    {/* LEFT PANEL: Chat Area */}
                    <div className={clsx(
                        "flex flex-col h-full overflow-hidden transition-all duration-500 ease-in-out",
                        isPanelVisible ? "w-1/2 border-r border-base-300" : "w-full"
                    )}>
                        <div className="flex-1 overflow-hidden relative flex flex-col">
                            <ModernMessageList
                                messages={state.messages}
                                onToggleWorkspace={() => setShowWorkspacePanel(!showWorkspacePanel)}
                            />

                            <div className="sticky bottom-0 w-full bg-gradient-to-t from-base-100 via-base-100/90 to-transparent pt-8 z-20">
                                <InputArea onSend={sendMessage} disabled={state.isRunning} />
                            </div>
                        </div>
                    </div>

                    {/* RIGHT PANEL: Workspace/Agent Trace Area */}
                    {isPanelVisible && (
                        <div className="w-1/2 h-full bg-base-200/30 overflow-hidden animate-in slide-in-from-right duration-500 ease-in-out border-l border-base-300 flex flex-col">
                            <div className="flex-none p-4 border-b border-base-300 bg-base-200/50 flex items-center justify-between">
                                <div className="text-xs font-black uppercase tracking-[0.2em] flex items-center gap-2 opacity-60">
                                    <span className="w-2 h-2 rounded-full bg-primary animate-ping"></span>
                                    Agent Workspace
                                </div>
                                <div className="badge badge-primary badge-sm font-bold">
                                    {isExecuting ? "Execution Mode" : "Trace View"}
                                </div>
                            </div>
                            <div className="flex-1 overflow-y-auto p-6 scrollbar-thin">
                                <div className="max-w-2xl mx-auto space-y-8">
                                    <PlanningProgress isPanel />
                                    <AgentWorkspaceStream />
                                </div>
                            </div>
                        </div>
                    )}
                </div>

            </div>

            {/* Sidebar Area */}
            <div className="drawer-side z-40">
                <label htmlFor="my-drawer-2" aria-label="close sidebar" className="drawer-overlay"></label>
                <ModernSidebar isCollapsed={!isSidebarOpen} setIsCollapsed={(collapsed) => setIsSidebarOpen(!collapsed)} />
            </div>
        </div>
    );
}

