"use client";

import { useAgenticUIContext } from "@/lib/agentic-ui";
import { useState } from "react";
import clsx from "clsx";

interface ModernSidebarProps {
    isCollapsed: boolean;
    setIsCollapsed: (value: boolean) => void;
}

export function ModernSidebar({ isCollapsed, setIsCollapsed }: ModernSidebarProps) {
    const { state, reset, switchThread, runId } = useAgenticUIContext();
    const [activeAccount, setActiveAccount] = useState("Pro Plan");
    const [activeSection, setActiveSection] = useState("chats"); // "chats" | "execution"

    // Sort threads by last modified
    const threads = state.threads ? [...state.threads].sort((a, b) => new Date(b.lastModified).getTime() - new Date(a.lastModified).getTime()) : [];

    const projects = [
        { id: "p1", title: "Agentic UI" },
        { id: "p2", title: "Workflow Engine" },
    ];

    const themes = ["light", "dark", "corporate", "business", "winter", "night"];

    return (
        <div
            className={clsx(
                "flex flex-col h-full bg-base-200 text-base-content transition-all duration-300 border-r border-base-300",
                isCollapsed ? "w-16 items-center px-2" : "w-80 p-4"
            )}
        >
            {/* 1. Toggle & Brand / Account Switcher */}
            <div className={clsx("flex items-center gap-2 mb-6", isCollapsed && "flex-col mb-4")}>

                {!isCollapsed ? (
                    <div className="dropdown w-full">
                        <div tabIndex={0} role="button" className="btn btn-ghost btn-md w-full justify-between px-2 hover:bg-base-300/50 rounded-xl border border-transparent hover:border-base-300/30 transition-all">
                            <div className="flex items-center gap-3 overflow-hidden">
                                <div className="avatar placeholder">
                                    <div className="bg-primary text-primary-content rounded-lg w-8 h-8 shadow-sm">
                                        <span className="text-xs font-bold">A</span>
                                    </div>
                                </div>
                                <div className="flex flex-col items-start overflow-hidden">
                                    <span className="text-sm font-bold truncate">Acme Inc.</span>
                                    <span className="text-[10px] opacity-60 truncate font-medium uppercase tracking-wider">{activeAccount}</span>
                                </div>
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 opacity-50">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 15L12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9" />
                            </svg>
                        </div>
                        <ul tabIndex={0} className="dropdown-content z-[50] menu p-2 shadow-2xl bg-base-200 rounded-xl w-full border border-base-300/50 mt-2 backdrop-blur-lg">
                            <li><a className="rounded-lg py-2" onClick={() => setActiveAccount("Pro Plan")}>Pro Plan</a></li>
                            <li><a className="rounded-lg py-2" onClick={() => setActiveAccount("Team Plan")}>Team Plan</a></li>
                            <li className="menu-title mt-2 text-[10px] uppercase font-bold opacity-40 px-3 tracking-widest">Org Settings</li>
                            <li><a className="rounded-lg py-2">Beta Corp.</a></li>
                        </ul>
                    </div>
                ) : (
                    <div className="dropdown dropdown-right">
                        <div tabIndex={0} role="button" className="avatar placeholder mb-2 group cursor-pointer" title="Acme Inc.">
                            <div className="bg-primary text-primary-content rounded-md w-8 h-8 group-hover:ring-2 ring-primary/30 transition-all">
                                <span className="text-xs font-bold">A</span>
                            </div>
                        </div>
                        <ul tabIndex={0} className="dropdown-content z-[50] menu p-2 shadow-2xl bg-base-200 rounded-xl w-56 border border-base-300/50 ml-4 backdrop-blur-lg mt-[-10px]">
                            <li><a className="rounded-lg py-2" onClick={() => setActiveAccount("Pro Plan")}>Pro Plan</a></li>
                            <li><a className="rounded-lg py-2" onClick={() => setActiveAccount("Team Plan")}>Team Plan</a></li>
                            <li className="menu-title mt-2 text-[10px] uppercase font-bold opacity-40 px-3 tracking-widest">Org Settings</li>
                            <li><a className="rounded-lg py-2">Beta Corp.</a></li>
                        </ul>
                    </div>
                )}

                {/* Collapse Toggle (Desktop only normally, but here we control via props) */}
                <button
                    onClick={() => setIsCollapsed(!isCollapsed)}
                    className="btn btn-square btn-ghost btn-xs text-base-content/50 hover:text-base-content"
                    title={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
                >
                    {isCollapsed ? (
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M11.25 4.5l7.5 7.5-7.5 7.5m-6-15l7.5 7.5-7.5 7.5" />
                        </svg>
                    ) : (
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M18.75 19.5l-7.5-7.5 7.5-7.5m-6 15L5.25 12l7.5-7.5" />
                        </svg>
                    )}
                </button>
            </div>

            {/* 2. Quick Search */}
            {!isCollapsed ? (
                <label className="input input-bordered input-sm flex items-center gap-2 bg-base-100/50 focus-within:bg-base-100 focus-within:border-primary/30 transition-all duration-200 mb-6 rounded-xl">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 opacity-60" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
                    </svg>
                    <input type="text" className="grow bg-transparent placeholder:opacity-50" placeholder="Search..." />
                    <kbd className="kbd kbd-xs bg-base-300/50 border-base-300/50 opacity-60">⌘K</kbd>
                </label>
            ) : (
                <div className="tooltip tooltip-right mb-6" data-tip="Search (⌘K)">
                    <button className="btn btn-square btn-ghost btn-sm opacity-70 hover:opacity-100 transition-opacity">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
                        </svg>
                    </button>
                </div>
            )}

            {/* 3. New Chat Action */}
            <div className={clsx(isCollapsed && "tooltip tooltip-right", "w-full mb-6")} data-tip="New Chat">
                <button
                    className={clsx("btn btn-primary btn-sm shadow-md hover:shadow-lg transition-all", isCollapsed ? "btn-square mx-auto flex" : "w-full gap-2 rounded-xl h-10")}
                    onClick={reset}
                >
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                    </svg>
                    {!isCollapsed && <span className="font-semibold">New Chat</span>}
                </button>
            </div>

            {/* 4. Navigation Links (Expandable) */}
            <div className="flex-1 overflow-y-auto w-full scrollbar-none">
                <ul className="menu menu-sm px-0 w-full gap-1">
                    <li className={clsx(activeSection === "chats" && "bg-base-300/50 rounded-lg")}>
                        <a className={clsx("flex gap-3", activeSection === "chats" && "active font-bold")} onClick={() => setActiveSection("chats")}>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193-.34.027-.68.052-1.02.072v3.091l-3-3c-1.354 0-2.694-.055-4.02-.163a2.115 2.115 0 01-.825-.242m9.345-8.334a2.126 2.126 0 00-.476-.095 48.64 48.64 0 00-8.048 0c-1.131.094-1.976 1.057-1.976 2.192v4.286c0 .837.46 1.58 1.155 1.951m9.345-8.334V6.637c0-1.621-1.152-3.026-2.76-3.235A48.455 48.455 0 0011.25 3c-2.115 0-4.198.137-6.24.402-1.608.209-2.76 1.614-2.76 3.235v6.226c0 1.621 1.152 3.026 2.76 3.235.577.075 1.157.14 1.74.194V21l4.155-4.155" />
                            </svg>
                            {!isCollapsed && <span>Chats</span>}
                        </a>
                    </li>
                    <li className={clsx(activeSection === "execution" && "bg-base-300/50 rounded-lg")}>
                        <a className={clsx("flex gap-3", activeSection === "execution" && "active font-bold")} onClick={() => setActiveSection("execution")}>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 13.5l10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75z" />
                            </svg>
                            {!isCollapsed && <span>Execution Logs</span>}
                        </a>
                    </li>
                    {activeSection === "chats" ? (
                        <>
                            {/* Projects Submenu */}
                            {!isCollapsed && (
                                <li>
                                    <details open>
                                        <summary className="opacity-80">
                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 12.75V12A2.25 2.25 0 014.5 9.75h15A2.25 2.25 0 0121.75 12v.75m-8.69-6.44l-2.12-2.12a1.5 1.5 0 00-1.061-.44H4.5A2.25 2.25 0 002.25 6v12a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9a2.25 2.25 0 00-2.25-2.25h-5.379a1.5 1.5 0 01-1.06-.44z" />
                                            </svg>
                                            Projects
                                        </summary>
                                        <ul>
                                            {projects.map(p => (
                                                <li key={p.id}><a>{p.title}</a></li>
                                            ))}
                                        </ul>
                                    </details>
                                </li>
                            )}
                            {isCollapsed && (
                                <li>
                                    <a className="tooltip tooltip-right" data-tip="Projects">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                                            <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 12.75V12A2.25 2.25 0 014.5 9.75h15A2.25 2.25 0 0121.75 12v.75m-8.69-6.44l-2.12-2.12a1.5 1.5 0 00-1.061-.44H4.5A2.25 2.25 0 002.25 6v12a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9a2.25 2.25 0 00-2.25-2.25h-5.379a1.5 1.5 0 01-1.06-.44z" />
                                        </svg>
                                    </a>
                                </li>
                            )}

                            {/* History Submenu */}
                            {!isCollapsed && (
                                <>
                                    <li className="menu-title mt-4 text-xs opacity-50 uppercase tracking-wider">Recents</li>
                                    {threads.length > 0 ? (
                                        threads.map(thread => (
                                            <li key={thread.id}>
                                                <a
                                                    className={clsx(
                                                        "opacity-80 hover:opacity-100 truncate block max-w-full",
                                                        runId === thread.id && "active font-bold bg-base-300"
                                                    )}
                                                    onClick={() => switchThread(thread.id)}
                                                    title={thread.id}
                                                >
                                                    {/* Display Thread ID shortly or metadata title if available */}
                                                    {thread.metadata?.title || `Conversation ${thread.id.substring(0, 6)}...`}
                                                    <span className="block text-[9px] opacity-50 font-normal">
                                                        {new Date(thread.lastModified).toLocaleDateString()}
                                                    </span>
                                                </a>
                                            </li>
                                        ))
                                    ) : (
                                        <li className="opacity-50 text-xs px-4 py-2 italic">No history yet</li>
                                    )}
                                </>
                            )}
                        </>
                    ) : (
                        <div className={clsx("mt-2", isCollapsed ? "flex flex-col items-center gap-4" : "space-y-4 px-2")}>
                            {isCollapsed ? (
                                <>
                                    <div className="tooltip tooltip-right" data-tip={`${state.superSteps.length} Steps`}>
                                        <div className="w-8 h-8 rounded-lg bg-base-300 flex items-center justify-center font-bold text-xs">
                                            {state.superSteps.length}
                                        </div>
                                    </div>
                                    <div className="tooltip tooltip-right" data-tip={`${state.events.length} Events`}>
                                        <div className="w-8 h-8 rounded-lg bg-base-300 flex items-center justify-center">
                                            <span className="text-sm">📌</span>
                                        </div>
                                    </div>
                                </>
                            ) : (
                                <SidebarExecutionView state={state} />
                            )}
                        </div>
                    )}
                </ul>
            </div>

            {/* 5. Bottom Section (Updates & Theme) */}
            <div className={clsx("mt-auto pt-4 border-t border-base-300 w-full", isCollapsed && "items-center flex flex-col gap-2")}>

                {/* Updates Announcement */}
                {!isCollapsed ? (
                    <div className="bg-base-300/30 p-3 rounded-lg border border-base-300/50 mb-3 text-xs">
                        <div className="font-semibold text-primary mb-1 flex items-center gap-1">
                            <span className="badge badge-xs badge-primary animate-pulse"></span>
                            New Update
                        </div>
                        <div className="opacity-70 mb-2 text-base-content">Agentic v2.0 is live with enhanced reasoning steps.</div>
                        <button className="link link-primary no-underline text-[10px] font-bold">Read more →</button>
                    </div>
                ) : (
                    <div className="tooltip tooltip-right" data-tip="New Update: Agentic v2.0 is live">
                        <button className="btn btn-xs btn-circle btn-primary btn-outline mb-2">i</button>
                    </div>
                )}

                {/* Theme Toggle (Light/Dark + Controller) */}
                {/* We'll use a simple swap for Day/Night and keep the controller for specificity */}
                {!isCollapsed ? (
                    <div className="flex items-center gap-2 bg-base-300/30 p-1.5 rounded-xl border border-base-300/50">
                        <label className="swap swap-rotate btn btn-sm btn-circle btn-ghost text-base-content/70 hover:text-primary transition-colors">
                            <input type="checkbox" className="theme-controller shadow-none" value="night" />
                            <svg className="swap-off fill-current w-5 h-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round">
                                <path d="M12 3v2.25m6.364.386l-1.591 1.591M21 12h-2.25m-.386 6.364l-1.591-1.591M12 18.75V21m-4.773-4.227l-1.591 1.591M5.25 12H3m4.227-4.773L5.636 5.636M15.75 12a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0z" />
                            </svg>
                            <svg className="swap-on fill-current w-5 h-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round">
                                <path d="M21.752 15.002A9.718 9.718 0 0118 15.75c-5.385 0-9.75-4.365-9.75-9.75 0-1.33.266-2.597.748-3.752A9.753 9.753 0 003 11.25C3 16.635 7.365 21 12.75 21a9.753 9.753 0 009.002-5.998z" />
                            </svg>
                        </label>
                        <div className="dropdown dropdown-top flex-1">
                            <div tabIndex={0} role="button" className="btn btn-ghost btn-sm w-full justify-start font-medium text-xs opacity-70 hover:opacity-100 rounded-lg">
                                Themes
                            </div>
                            <ul tabIndex={0} className="dropdown-content z-[50] p-2 shadow-2xl bg-base-200 rounded-xl w-48 mb-2 border border-base-300/50 backdrop-blur-lg">
                                {themes.map(t => (
                                    <li key={t}>
                                        <input
                                            type="radio"
                                            name="theme-dropdown"
                                            className="theme-controller btn btn-sm btn-block btn-ghost justify-start rounded-lg text-xs"
                                            aria-label={t.charAt(0).toUpperCase() + t.slice(1)}
                                            value={t}
                                        />
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>
                ) : (
                    // Collapsed Theme Toggle (Proper dropdown)
                    <div className="dropdown dropdown-right dropdown-top">
                        <div tabIndex={0} role="button" className="btn btn-sm btn-circle btn-ghost">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 opacity-70">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M4.098 19.902a3.75 3.75 0 005.304 0l6.401-6.402M6.75 21A3.75 3.75 0 013 17.25V4.125C3 3.504 3.504 3 4.125 3h5.25c.621 0 1.125.504 1.125 1.125v4.072M6.75 21a3.75 3.75 0 003.75-3.75V8.197M6.75 21h13.125c.621 0 1.125-.504 1.125-1.125v-5.25c0-.621-.504-1.125-1.125-1.125h-4.072M10.5 8.197l2.88-2.88c.438-.439 1.15-.439 1.59 0l3.712 3.713c.44.44.44 1.152 0 1.59l-2.879 2.88M6.75 17.25h.008v.008H6.75v-.008z" />
                            </svg>
                        </div>
                        <ul tabIndex={0} className="dropdown-content z-[50] p-2 shadow-2xl bg-base-200 rounded-xl w-48 ml-4 mb-2 border border-base-300/50 backdrop-blur-lg">
                            <li className="menu-title text-[10px] uppercase font-bold opacity-40 px-3 tracking-widest mb-1">Select Theme</li>
                            {themes.map(t => (
                                <li key={t}>
                                    <input
                                        type="radio"
                                        name="theme-dropdown-collapsed"
                                        className="theme-controller btn btn-sm btn-block btn-ghost justify-start rounded-lg text-xs"
                                        aria-label={t.charAt(0).toUpperCase() + t.slice(1)}
                                        value={t}
                                    />
                                </li>
                            ))}
                        </ul>
                    </div>
                )}

            </div>
        </div>
    );
}

function SidebarExecutionView({ state }: { state: any }) {
    const recentEvents = [...state.events].reverse().slice(0, 10);

    return (
        <div className="space-y-6 animate-in fade-in slide-in-from-left-4 duration-300">
            {/* Super Steps */}
            {state.superSteps.length > 0 && (
                <div>
                    <div className="text-[10px] uppercase font-bold tracking-widest opacity-40 mb-3 px-1">Super Steps</div>
                    <div className="space-y-2">
                        {state.superSteps.map((step: any) => (
                            <div key={step.stepNumber} className="bg-base-300/30 rounded-xl p-3 border border-base-300/50 hover:border-primary/30 transition-all group">
                                <div className="flex items-center justify-between mb-1">
                                    <div className="flex items-center gap-2">
                                        <span className="text-xs font-bold text-primary">STEP {step.stepNumber}</span>
                                        {step.status === "started" && <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse"></span>}
                                    </div>
                                    <span className={clsx(
                                        "text-[10px] font-bold px-2 py-0.5 rounded-full uppercase",
                                        step.status === "completed" ? "bg-success/10 text-success" : "bg-primary/10 text-primary"
                                    )}>
                                        {step.status}
                                    </span>
                                </div>
                                {step.executors.length > 0 && (
                                    <div className="text-[10px] opacity-60 font-medium">{step.executors.length} executors triggered</div>
                                )}
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* Recent Events */}
            <div>
                <div className="text-[10px] uppercase font-bold tracking-widest opacity-40 mb-3 px-1">Recent Events ({state.events.length})</div>
                <div className="bg-base-300/20 rounded-2xl border border-base-300/30 overflow-hidden">
                    <div className="max-h-64 overflow-y-auto scrollbar-none">
                        {recentEvents.length > 0 ? (
                            recentEvents.map((event: any, i: number) => (
                                <div key={i} className="flex items-start gap-3 p-3 border-b border-base-300/30 last:border-0 hover:bg-base-300/40 transition-colors">
                                    <div className="bg-base-100 rounded-lg w-7 h-7 flex items-center justify-center shrink-0 shadow-sm text-xs">
                                        {getEventIcon(event.eventType)}
                                    </div>
                                    <div className="min-w-0">
                                        <div className="text-[10px] font-bold truncate leading-tight">{event.eventType.replace(/_/g, " ")}</div>
                                        <div className="text-[9px] opacity-50 mt-0.5">{new Date(event.timestamp).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}</div>
                                    </div>
                                </div>
                            ))
                        ) : (
                            <div className="p-8 text-center opacity-30 italic text-xs">No events yet</div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}

function getEventIcon(eventType: string): string {
    switch (eventType) {
        case "RUN_STARTED": return "🚀";
        case "RUN_FINISHED": return "✅";
        case "RUN_ERROR": return "❌";
        case "AGENT_PLANNING_STEP": return "🧠";
        case "TOOL_CALL_START": return "🔧";
        case "EXECUTOR_INVOKED": return "⚡";
        case "SUPERSTEP_STARTED": return "📊";
        case "AGENT_UPDATE": return "💬";
        default: return "📌";
    }
}
