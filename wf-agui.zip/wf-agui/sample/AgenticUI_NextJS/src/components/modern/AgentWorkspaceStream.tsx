"use client";

import React from "react";
import { useAgenticUIContext, type WorkspaceUpdate } from "@/lib/agentic-ui";
import { ToolInteractionCard } from "./ToolInteractionCard";
import clsx from "clsx";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

interface AgentWorkspaceStreamProps {
    className?: string;
}

export function AgentWorkspaceStream({ className }: AgentWorkspaceStreamProps) {
    const { state } = useAgenticUIContext();
    const { workspaceUpdates, toolCalls, isRunning } = state;
    const bottomRef = React.useRef<HTMLDivElement>(null);

    // Auto-scroll to bottom when new updates arrive
    React.useEffect(() => {
        if (bottomRef.current) {
            bottomRef.current.scrollIntoView({ behavior: "smooth" });
        }
    }, [workspaceUpdates.length]);

    // Convert toolCalls Map to array for display alongside workspaceUpdates
    const toolCallsArray = Array.from(toolCalls.values());

    if (workspaceUpdates.length === 0 && toolCallsArray.length === 0 && !isRunning) {
        return (
            <div className={clsx("flex items-center justify-center h-full text-base-content/40", className)}>
                <div className="text-center space-y-3">
                    <div className="w-16 h-16 mx-auto rounded-2xl bg-base-300/50 flex items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8 opacity-50">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 13.5l10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75z" />
                        </svg>
                    </div>
                    <p className="text-xs font-medium">Agent activity will appear here</p>
                </div>
            </div>
        );
    }

    return (
        <div className={clsx("space-y-4", className)}>
            {/* Streaming Updates Header */}
            {isRunning && (
                <div className="flex items-center gap-2 text-xs font-bold text-primary animate-pulse">
                    <span className="loading loading-ring loading-xs"></span>
                    <span>Streaming Agent Activity...</span>
                </div>
            )}

            {/* Workspace Updates Stream */}
            {workspaceUpdates.map((update, idx) => (
                <WorkspaceUpdateCard key={update.id || idx} update={update} />
            ))}

            {/* Also show any additional tool calls that might not be in workspaceUpdates */}
            {toolCallsArray
                .filter((tc) => !workspaceUpdates.some((u) => u.id === tc.id))
                .map((toolCall) => (
                    <ToolInteractionCard
                        key={toolCall.id}
                        name={toolCall.name}
                        args={toolCall.args}
                        result={toolCall.result}
                        status={toolCall.status === "pending" ? "pending" : "completed"}
                    />
                ))}

            <div ref={bottomRef} className="h-1" />
        </div>
    );
}

function WorkspaceUpdateCard({ update }: { update: WorkspaceUpdate }) {
    const isPending = update.status === "pending";
    const isStreaming = update.status === "streaming";
    const isCompleted = update.status === "completed";

    if (update.type === "tool_call" || update.type === "tool_result") {
        return (
            <ToolInteractionCard
                name={update.toolName || "Tool"}
                args={update.toolArgs}
                result={update.toolResult}
                status={isCompleted ? "completed" : "pending"}
            />
        );
    }

    if (update.type === "reasoning" || update.type === "text") {
        return (
            <div className={clsx(
                "rounded-xl border p-4 transition-all duration-300",
                isPending || isStreaming
                    ? "border-primary/30 bg-primary/5 animate-pulse"
                    : "border-base-300/50 bg-base-200/30"
            )}>
                <div className="flex items-center gap-2 mb-2">
                    <div className={clsx(
                        "w-2 h-2 rounded-full",
                        isPending || isStreaming ? "bg-primary animate-pulse" : "bg-success"
                    )} />
                    <span className="text-[10px] font-bold uppercase tracking-wider text-base-content/50">
                        {update.type === "reasoning" ? "Reasoning" : "Output"}
                    </span>
                    <time className="text-[9px] opacity-30 ml-auto">
                        {new Date(update.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                    </time>
                </div>
                {update.text && (
                    <div className="prose prose-sm max-w-none text-xs opacity-80">
                        <ReactMarkdown remarkPlugins={[remarkGfm]}>
                            {update.text}
                        </ReactMarkdown>
                    </div>
                )}
                {(isPending || isStreaming) && !update.text && (
                    <div className="flex items-center gap-2 text-xs text-base-content/50">
                        <span className="loading loading-dots loading-xs"></span>
                        <span>Processing...</span>
                    </div>
                )}
            </div>
        );
    }

    return null;
}
