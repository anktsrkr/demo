"use client";

import React from "react";
import { useAgenticUIContext } from "@/lib/agentic-ui";
import clsx from "clsx";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

interface PlanningProgressProps {
    isDocked?: boolean;
    isPanel?: boolean;
}

export function PlanningProgress({ isDocked, isPanel }: PlanningProgressProps) {
    const { state } = useAgenticUIContext();
    const { planning } = state;

    const completedGoals = planning.goalStatuses.filter(s => s === "completed").length;
    const totalGoals = planning.goals.length;
    const progressPercentage = totalGoals > 0 ? Math.round((completedGoals / totalGoals) * 100) : 0;

    const animations = (
        <style dangerouslySetInnerHTML={{
            __html: `
            @keyframes scan-intelligence {
                0% { transform: translateY(-100%); opacity: 0; }
                50% { opacity: 1; }
                100% { transform: translateY(2000%); opacity: 0; }
            }
            @keyframes ring-pulse {
                0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(var(--p), 0.7); }
                70% { transform: scale(1); box-shadow: 0 0 0 10px rgba(var(--p), 0); }
                100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(var(--p), 0); }
            }
        `}} />
    );

    const content = (
        <div className={clsx("p-0 space-y-8", !isPanel && "p-2 space-y-6")}>
            {/* 1. Planning Stats & Progress */}
            {planning.goals.length > 0 && (
                <div className="space-y-4">
                    <div className="stats shadow-lg bg-base-100/40 backdrop-blur-md border border-base-300/30 w-full overflow-hidden">
                        <div className="stat px-4 py-3">
                            <div className="stat-figure text-primary">
                                <div className="radial-progress text-primary" style={{ "--value": progressPercentage, "--size": "3rem", "--thickness": "4px" } as any} role="progressbar">
                                    <span className="text-[10px] font-bold">{progressPercentage}%</span>
                                </div>
                            </div>
                            <div className="stat-title text-[10px] uppercase font-black tracking-widest opacity-60">Mission Progress</div>
                            <div className="stat-value text-xl font-black text-primary drop-shadow-[0_0_8px_rgba(var(--p),0.4)]">
                                {completedGoals}<span className="opacity-30 mx-1">/</span>{totalGoals}
                            </div>
                            <div className="stat-desc text-[9px] font-medium opacity-50 mt-1">Objectives Reached</div>
                        </div>
                    </div>

                    {/* Custom Robust Steps Indicator */}
                    <div className={clsx(
                        "flex flex-col gap-0 py-4 transition-all duration-700",
                        !isPanel && "lg:flex-row lg:items-start lg:gap-4"
                    )}>
                        {planning.goals.map((goal, idx) => {
                            const status = planning.goalStatuses[idx] || "pending";
                            const isDone = status === "completed" || planning.status === "completed";
                            const isExecuting = status === "executing" && planning.status !== "completed";
                            const isLast = idx === planning.goals.length - 1;

                            return (
                                <div
                                    key={idx}
                                    className={clsx(
                                        "flex items-start gap-4 relative animate-in fade-in slide-in-from-left-4 fill-mode-both",
                                        isPanel ? "flex-row" : "flex-row lg:flex-col lg:flex-1 lg:items-center lg:text-center lg:gap-2"
                                    )}
                                    style={{ animationDelay: `${idx * 150}ms`, animationDuration: '600ms' }}
                                >
                                    {/* Line & Circle Container */}
                                    <div className={clsx(
                                        "flex flex-col items-center flex-none relative h-full",
                                        !isPanel && "lg:w-full lg:flex-row lg:h-auto"
                                    )}>
                                        {/* Step Circle */}
                                        <div className={clsx(
                                            "w-8 h-8 rounded-full flex items-center justify-center font-bold text-[11px] transition-all duration-500 z-10 relative",
                                            isDone ? "bg-primary text-primary-content" :
                                                isExecuting ? "bg-primary text-primary-content scale-110 shadow-[0_0_20px_rgba(var(--p),0.5)]" :
                                                    "bg-base-300 text-base-content/40"
                                        )}
                                            style={isExecuting ? { animation: 'ring-pulse 2s infinite' } : {}}>
                                            {isExecuting && (
                                                <div className="absolute inset-0 rounded-full border-2 border-primary animate-ping opacity-20"></div>
                                            )}
                                            {isDone ? "✓" : isExecuting ? "⚙️" : idx + 1}
                                        </div>

                                        {/* Connecting Line (Vertical) */}
                                        {!isLast && (
                                            <div className={clsx(
                                                "w-[2px] flex-1 min-h-[1.5rem] my-1 transition-colors duration-500",
                                                isDone ? "bg-primary" : "bg-base-300",
                                                !isPanel && "lg:hidden"
                                            )}></div>
                                        )}

                                        {/* Connecting Line (Horizontal for Desktop Inline View) */}
                                        {!isLast && !isPanel && (
                                            <div className={clsx(
                                                "hidden lg:block h-[2px] flex-1 mx-2 transition-colors duration-500",
                                                isDone ? "bg-primary" : "bg-base-300"
                                            )}></div>
                                        )}
                                    </div>

                                    {/* Goal Text Label */}
                                    <div className={clsx(
                                        "pb-8 flex-1 transition-all duration-300",
                                        isLast && "pb-0",
                                        isExecuting ? "opacity-100" : (isDone ? "opacity-70" : "opacity-30"),
                                        !isPanel && "lg:pb-0 lg:mt-1 lg:px-2"
                                    )}>
                                        <div className={clsx(
                                            "text-[11px] font-bold leading-tight",
                                            isExecuting && "text-primary drop-shadow-sm"
                                        )}>
                                            {typeof goal === 'string' ? goal : (goal as any).description}
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}

            {/* 2. Reasoning & Steps (Timeline Component inside Collapse) */}
            {planning.steps.length > 0 && (
                <div className={clsx(
                    "collapse collapse-arrow bg-base-100/40 border border-base-300/30 rounded-2xl shadow-xl backdrop-blur-md transition-all duration-500 hover:border-primary/30",
                    isPanel && "border-none bg-transparent shadow-none backdrop-blur-none"
                )}>
                    <input type="checkbox" defaultChecked />
                    <div className="collapse-title text-[10px] uppercase font-black tracking-[0.2em] flex items-center gap-3 min-h-0 py-4 px-5 pr-12">
                        <div className="relative flex h-3 w-3">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-40"></span>
                            <span className="relative inline-flex rounded-full h-3 w-3 bg-primary shadow-[0_0_8px_rgba(var(--p),0.6)]"></span>
                        </div>
                        <span className="text-base-content/70">Intelligence Trace</span>
                        <div className="ml-auto opacity-30 font-mono text-[9px] whitespace-nowrap">{planning.steps.length} ENTRIES</div>
                    </div>
                    <div className="collapse-content p-0">
                        <div className={clsx("px-5 pb-6", isPanel && "px-0 pb-0")}>
                            <ul className="timeline timeline-vertical timeline-compact timeline-snap-icon">
                                {[...planning.steps].reverse().map((step, rIdx, reversedArray) => {
                                    const sourceIdx = reversedArray.length - 1 - rIdx;
                                    const isLatestSource = sourceIdx === planning.steps.length - 1;
                                    const isFirst = rIdx === 0;
                                    const isLast = rIdx === reversedArray.length - 1;

                                    return (
                                        <li
                                            key={sourceIdx}
                                            className="group/item animate-in fade-in slide-in-from-bottom-2 fill-mode-both"
                                            style={{ animationDelay: `${(planning.goals.length * 150) + (rIdx * 100)}ms`, animationDuration: '500ms' }}
                                        >
                                            <hr className={clsx("transition-colors duration-500", isFirst ? "bg-transparent" : "bg-primary")} />
                                            <div className="timeline-middle">
                                                <div className={clsx(
                                                    "w-4 h-4 rounded-full border-2 flex items-center justify-center transition-all duration-500",
                                                    "border-primary bg-primary text-primary-content",
                                                    isLatestSource && planning.status !== "completed" ? "shadow-[0_0_12px_rgba(var(--p),0.5)] scale-110" : "scale-100"
                                                )}>
                                                    {isLatestSource && planning.status !== "completed" ? (
                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-2.5 h-2.5 animate-spin" style={{ animationDuration: '3s' }}>
                                                            <path fillRule="evenodd" d="M15.312 11.424a5.5 5.5 0 01-9.201 2.466l-.312-.311h2.433a.75.75 0 000-1.5H3.989a.75.75 0 00-.75.75v4.242a.75.75 0 001.5 0v-2.43l.31.31a7 7 0 0011.712-3.138.75.75 0 00-1.449-.39zm1.23-5.082L16.231 6a7 7 0 00-11.712 3.138.75.75 0 001.449.39 5.5 5.5 0 019.201-2.466l.312.311H13.06a.75.75 0 000 1.5h4.243a.75.75 0 00.75-.75V3.75a.75.75 0 00-1.5 0v2.43l-.31-.31z" clipRule="evenodd" />
                                                        </svg>
                                                    ) : (
                                                        <div className="w-1.5 h-1.5 rounded-full bg-primary-content"></div>
                                                    )}
                                                </div>
                                            </div>
                                            <div className="timeline-end mb-8 ml-4 w-full">
                                                <div className="flex items-center justify-between group/header">
                                                    <div className={clsx(
                                                        "text-[10px] font-black uppercase tracking-wider transition-colors",
                                                        isLatestSource ? "text-primary" : "opacity-40 group-hover/item:opacity-70"
                                                    )}>
                                                        {step.action}
                                                    </div>
                                                    <time className="text-[9px] opacity-20 font-mono italic group-hover/item:opacity-40 transition-opacity">
                                                        {new Date(step.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                                                    </time>
                                                </div>
                                                {step.reasoning && (
                                                    <div className={clsx(
                                                        "timeline-box mt-2 text-[11px] font-medium leading-relaxed bg-base-200/30 p-3 rounded-xl border border-base-300/20 shadow-sm backdrop-blur-sm transition-all duration-300 relative overflow-hidden",
                                                        isLatestSource ? "border-primary/30 bg-primary/5 shadow-[0_4px_12px_rgba(var(--p),0.05)]" : "group-hover/item:bg-base-200/50 group-hover/item:border-base-300/50"
                                                    )}>
                                                        {isLatestSource && planning.status !== "completed" && (
                                                            <div
                                                                className="absolute inset-x-0 top-0 h-[40px] bg-gradient-to-b from-transparent via-primary/20 to-transparent z-0 pointer-events-none"
                                                                style={{ animation: 'scan-intelligence 3s linear infinite' }}
                                                            />
                                                        )}
                                                        <div className="prose prose-sm max-w-none break-words opacity-80 text-left relative z-10">
                                                            <ReactMarkdown remarkPlugins={[remarkGfm]}>
                                                                {step.reasoning}
                                                            </ReactMarkdown>
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
                                            <hr className={clsx("transition-colors duration-500", isLast ? "bg-transparent" : "bg-primary")} />
                                        </li>
                                    );
                                })}
                            </ul>
                        </div>

                    </div>
                </div>
            )}
        </div>
    );

    if (isPanel) {
        return <div className="animate-in fade-in duration-1000 slide-in-from-right-4">{animations}{content}</div>;
    }

    return (
        <div className="card bg-base-200/40 border border-base-300/50 shadow-2xl overflow-hidden animate-in fade-in slide-in-from-bottom-8 duration-700 rounded-3xl backdrop-blur-xl group/card">
            <div className="card-body p-6">
                {animations}
                {content}
            </div>
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-secondary/5 opacity-0 group-hover/card:opacity-100 transition-opacity duration-1000 pointer-events-none"></div>
        </div>
    );
}


