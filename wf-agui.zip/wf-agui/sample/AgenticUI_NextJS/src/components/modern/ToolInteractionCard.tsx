"use client";

import React, { useState } from "react";
import clsx from "clsx";

import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { vscDarkPlus } from "react-syntax-highlighter/dist/esm/styles/prism";

interface ToolInteractionCardProps {
    name: string;
    args?: any;
    result?: any;
    status?: "pending" | "completed" | "failed";
}

export function ToolInteractionCard({ name, args, result, status = "completed" }: ToolInteractionCardProps) {
    const [isExpanded, setIsExpanded] = useState(false);
    const [copyStatus, setCopyStatus] = useState<string | null>(null);

    const handleCopy = (text: string, label: string) => {
        const content = typeof text === "string" ? text : JSON.stringify(text, null, 2);
        navigator.clipboard.writeText(content);
        setCopyStatus(label);
        setTimeout(() => setCopyStatus(null), 2000);
    };

    const formatContent = (content: any) => {
        if (typeof content === "string") return content;
        return JSON.stringify(content, null, 2);
    };

    return (
        <div className="group/tool border border-base-300/50 bg-base-200/40 rounded-2xl overflow-hidden transition-all duration-300 hover:shadow-lg hover:shadow-primary/5 hover:border-primary/20 backdrop-blur-sm my-4">
            {/* Header / Summary */}
            <div
                className="flex items-center gap-3 px-4 py-3 cursor-pointer select-none hover:bg-base-300/30 transition-colors"
                onClick={() => setIsExpanded(!isExpanded)}
            >
                {/* Icon Container */}
                <div className={clsx(
                    "w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-500",
                    result ? "bg-success/10 text-success ring-1 ring-success/20" : "bg-primary/10 text-primary ring-1 ring-primary/20 animate-pulse"
                )}>
                    {result ? (
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                    ) : (
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M15.59 14.37a6 6 0 01-5.84 7.38v-4.8m5.84-2.58a14.98 14.98 0 006.16-12.12A14.98 14.98 0 009.631 8.41m5.96 5.96a14.926 14.926 0 01-5.841 2.58m-.119-8.54a6 6 0 00-7.381 5.84h4.8m2.581-5.84a14.927 14.927 0 00-2.58 5.841m1.861-4.413a3.375 3.375 0 11-4.773 4.773 3.375 3.375 0 014.773-4.773z" />
                        </svg>
                    )}
                </div>

                {/* Title and Secondary Info */}
                <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold uppercase tracking-widest text-base-content/40">Executed Tool</span>
                        {result && (
                            <div className="badge badge-success badge-xs opacity-80 text-[8px] font-bold">COMPLETED</div>
                        )}
                        {!result && (
                            <div className="badge badge-primary badge-xs opacity-80 text-[8px] font-bold animate-pulse">RUNNING</div>
                        )}
                    </div>
                    <div className="text-sm font-bold text-primary truncate max-w-[200px] sm:max-w-none">
                        {name}
                    </div>
                </div>

                {/* Expand Chevron */}
                <div className={clsx(
                    "text-base-content/30 transition-transform duration-300",
                    isExpanded && "rotate-180 text-primary"
                )}>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className="w-4 h-4">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
                    </svg>
                </div>
            </div>

            {/* Content Area */}
            <div className={clsx(
                "overflow-hidden transition-all duration-500 ease-in-out",
                isExpanded ? "max-h-[1000px] border-t border-base-300/30" : "max-h-0"
            )}>
                <div className="p-4 space-y-5 bg-base-300/20 backdrop-blur-md">
                    {/* Input Section */}
                    <div className="space-y-2">
                        <div className="flex items-center justify-between px-1">
                            <div className="flex items-center gap-2">
                                <div className="w-1.5 h-1.5 rounded-full bg-primary/40"></div>
                                <span className="text-[10px] font-bold uppercase tracking-wider opacity-50">Parameters</span>
                            </div>
                            <button
                                onClick={(e) => { e.stopPropagation(); handleCopy(args, "Input"); }}
                                className="btn btn-ghost btn-xs opacity-40 hover:opacity-100 hover:bg-primary/10 transition-all rounded-md"
                            >
                                {copyStatus === "Input" ? "Copied!" : "Copy"}
                            </button>
                        </div>
                        <div className="relative group/code overflow-hidden rounded-xl border border-base-300/50 shadow-inner">
                            <SyntaxHighlighter
                                language="json"
                                style={vscDarkPlus}
                                customStyle={{
                                    margin: 0,
                                    padding: '1rem',
                                    fontSize: '11px',
                                    background: 'rgba(0,0,0,0.3)',
                                    maxHeight: '250px'
                                }}
                            >
                                {formatContent(args)}
                            </SyntaxHighlighter>
                        </div>
                    </div>

                    {/* Output Section */}
                    {result !== undefined && (
                        <div className="space-y-2 animate-in fade-in slide-in-from-top-2 duration-700">
                            <div className="flex items-center justify-between px-1">
                                <div className="flex items-center gap-2">
                                    <div className="w-1.5 h-1.5 rounded-full bg-success/40"></div>
                                    <span className="text-[10px] font-bold uppercase tracking-wider opacity-50">Response</span>
                                </div>
                                <button
                                    onClick={(e) => { e.stopPropagation(); handleCopy(result, "Output"); }}
                                    className="btn btn-ghost btn-xs opacity-40 hover:opacity-100 hover:bg-success/10 transition-all rounded-md"
                                >
                                    {copyStatus === "Output" ? "Copied!" : "Copy"}
                                </button>
                            </div>
                            <div className="relative group/code overflow-hidden rounded-xl border border-base-300/50 shadow-inner">
                                <SyntaxHighlighter
                                    language="json"
                                    style={vscDarkPlus}
                                    customStyle={{
                                        margin: 0,
                                        padding: '1rem',
                                        fontSize: '11px',
                                        background: 'rgba(0,0,0,0.3)',
                                        maxHeight: '350px'
                                    }}
                                >
                                    {formatContent(result)}
                                </SyntaxHighlighter>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
