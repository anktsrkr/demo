"use client";

import { useEffect, useRef } from "react";
import { normalizeValue } from "@/lib/agentic-ui/utils";
import { useAgenticUIContext } from "@/lib/agentic-ui";
import { ModernMessageBubble } from "./ModernMessageBubble";
import { ChatMessage } from "@/types/chat";

interface ModernMessageListProps {
    messages: ChatMessage[];
    onToggleWorkspace?: () => void;
}

export function ModernMessageList({ messages, onToggleWorkspace }: ModernMessageListProps) {
    const { state } = useAgenticUIContext();
    const bottomRef = useRef<HTMLDivElement>(null);
    const containerRef = useRef<HTMLDivElement>(null);
    const shouldAutoScroll = useRef(true);
    const isAutoScrolling = useRef(false);
    const lastScrollTop = useRef(0);
    const prevMessageCount = useRef(messages.length);

    // Scroll handler to pause auto-scroll if user interacts
    useEffect(() => {
        const container = containerRef.current;
        if (!container) return;

        const handleUserInteraction = () => {
            shouldAutoScroll.current = false;
        };

        const handleScroll = () => {
            const { scrollTop, scrollHeight, clientHeight } = container;

            if (isAutoScrolling.current) {
                lastScrollTop.current = scrollTop;
                return;
            }

            // Detect manual scroll-up independently of interaction events (e.g. scrollbar drag)
            if (scrollTop < lastScrollTop.current - 2) {
                if (shouldAutoScroll.current) {
                    shouldAutoScroll.current = false;
                }
            }

            const distanceToBottom = scrollHeight - scrollTop - clientHeight;
            const isAtBottom = distanceToBottom < 10;

            if (isAtBottom && !shouldAutoScroll.current) {
                shouldAutoScroll.current = true;
            }

            lastScrollTop.current = scrollTop;
        };

        container.addEventListener("scroll", handleScroll);
        container.addEventListener("wheel", handleUserInteraction, { passive: true });
        container.addEventListener("touchmove", handleUserInteraction, { passive: true });

        return () => {
            container.removeEventListener("scroll", handleScroll);
            container.removeEventListener("wheel", handleUserInteraction);
            container.removeEventListener("touchmove", handleUserInteraction);
        };
    }, [messages.length > 0]);

    // Auto-scroll logic
    useEffect(() => {
        // Force auto-scroll if message count increased and last message is from user
        if (messages.length > prevMessageCount.current) {
            const lastMessage = messages[messages.length - 1];
            if (lastMessage && lastMessage.role === "user") {
                shouldAutoScroll.current = true;
            }
        }
        prevMessageCount.current = messages.length;

        if (shouldAutoScroll.current && bottomRef.current) {
            isAutoScrolling.current = true;
            bottomRef.current.scrollIntoView({ behavior: "smooth" });

            // Longer delay for smooth scrolling animation to complete
            setTimeout(() => {
                isAutoScrolling.current = false;
            }, 500);
        }
    }, [messages, state.isRunning]);

    // Empty State
    if (messages.length === 0 && !state.isRunning) {
        return (
            <div className="flex-1 flex flex-col items-center justify-center p-8">
                <div className="text-center max-w-md">
                    <div className="avatar placeholder mb-6">
                        <div className="bg-gradient-to-br from-primary/20 to-secondary/20 text-primary rounded-2xl w-20 h-20 shadow-lg ring-2 ring-base-300">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-10 h-10">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456zM16.894 20.567L16.5 21.75l-.394-1.183a2.25 2.25 0 00-1.423-1.423L13.5 18.75l1.183-.394a2.25 2.25 0 001.423-1.423l.394-1.183.394 1.183a2.25 2.25 0 001.423 1.423l1.183.394-1.183.394a2.25 2.25 0 00-1.423 1.423z" />
                            </svg>
                        </div>
                    </div>
                    <h2 className="text-2xl font-bold mb-2 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">How can I help you today?</h2>
                    <p className="text-base-content/50 text-sm">Start a conversation with your AI assistant</p>
                </div>
            </div>
        );
    }

    // Check if we need to show a "Thinking..." indicator
    const lastMsg = messages[messages.length - 1];
    const isThinking = state.isRunning && (!lastMsg || !lastMsg.isStreaming);

    // Get current activity label from events
    const lastEvent = state.events[state.events.length - 1];
    const getActivityLabel = () => {
        if (!lastEvent) return "Thinking...";
        switch (lastEvent.eventType) {
            case "AGENT_PLANNING_STEP": return `Planning: ${normalizeValue(lastEvent.action).slice(0, 30)}...`;
            case "TOOL_CALL_START": return `Using ${lastEvent.tool_name}...`;
            case "TOOL_CALL_ARGS": return `Preparing ${state.toolCalls.get(lastEvent.tool_call_id)?.name || 'tool'}...`;
            case "EXECUTOR_INVOKED": return "Executing task...";
            case "SUPERSTEP_STARTED": return `Step ${lastEvent.step_number} in progress...`;
            default: return "Thinking...";
        }
    };

    return (
        <div ref={containerRef} className="flex-1 overflow-y-auto w-full px-4 md:px-8 py-4 space-y-6">
            <div className="max-w-3xl mx-auto space-y-6 pb-4">
                {messages.map((message) => (
                    <ModernMessageBubble
                        key={message.id}
                        message={message}
                        onToggleWorkspace={onToggleWorkspace}
                    />
                ))}

                {isThinking && (
                    <div className="space-y-6">
                        <div className="chat chat-start animate-fade-in">
                            <div className="chat-image avatar">
                                <div className="w-10 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center shadow-sm">
                                    <span className="loading loading-ring loading-sm text-primary"></span>
                                </div>
                            </div>
                            <div className="chat-bubble shadow-sm text-sm flex items-center gap-2">
                                <span className="loading loading-dots loading-xs"></span>
                                <span className="font-medium">{getActivityLabel()}</span>
                            </div>
                        </div>
                    </div>
                )}

                {state.error && (
                    <div className="chat chat-start animate-fade-in">
                        <div className="chat-image avatar">
                            <div className="w-10 rounded-full bg-error/10 text-error flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
                                </svg>
                            </div>
                        </div>
                        <div className="chat-bubble chat-bubble-error shadow-md flex items-center gap-3">
                            <span className="font-medium text-sm">Unable to handle the current request</span>
                            <div className="tooltip tooltip-bottom" data-tip={state.error}>
                                <button className="btn btn-ghost btn-xs btn-circle opacity-80 hover:opacity-100 transition-opacity">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4">
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z" />
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                )}

                <div ref={bottomRef} className="h-4" />
            </div>
        </div>
    );
}
