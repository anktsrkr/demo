"use client";

import { useState, useRef, useEffect, KeyboardEvent } from "react";
import { InputComponentProps } from "@/lib/agentic-ui";
import clsx from "clsx";

export function InputArea({ onSend, disabled }: InputComponentProps) {
    const [input, setInput] = useState("");
    const [selectedFile, setSelectedFile] = useState<File | null>(null);
    const textareaRef = useRef<HTMLTextAreaElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const adjustHeight = () => {
        const textarea = textareaRef.current;
        if (textarea) {
            textarea.style.height = "auto";
            textarea.style.height = `${Math.min(textarea.scrollHeight, 200)}px`;
        }
    };

    useEffect(() => {
        adjustHeight();
    }, [input]);

    const handleSend = () => {
        if (!input.trim() || disabled) return;
        onSend(input + (selectedFile ? `\n[Attached: ${selectedFile.name}]` : ""));
        setInput("");
        setSelectedFile(null);
        if (textareaRef.current) {
            textareaRef.current.style.height = "auto";
            textareaRef.current.focus();
        }
    };

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setSelectedFile(e.target.files[0]);
        }
    };

    const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    };

    return (
        <div className="w-full max-w-4xl mx-auto p-4">
            <div className={clsx(
                "relative bg-base-100/90 backdrop-blur-xl rounded-2xl border border-base-300 shadow-lg transition-all duration-300 focus-within:border-primary/40 focus-within:shadow-primary/5",
                disabled && "opacity-60 cursor-not-allowed"
            )}>
                <div className="p-2">
                    {/* 1. Text Input Area */}
                    <div className="relative">
                        {selectedFile && (
                            <div className="mx-2 mb-2 inline-flex items-center gap-2 px-3 py-1 bg-primary/10 text-primary rounded-lg text-xs w-fit animate-fade-in border border-primary/20">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-3.5 h-3.5">
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M18.375 12.739l-7.693 7.693a4.5 4.5 0 01-6.364-6.364l10.94-10.94A3 3 0 1119.5 5.818l-1.59 1.59" />
                                </svg>
                                <span className="font-semibold truncate max-w-[200px]">{selectedFile.name}</span>
                                <button
                                    onClick={() => setSelectedFile(null)}
                                    className="btn btn-ghost btn-xs btn-circle h-5 w-5 min-h-0 hover:bg-primary/20 ml-1"
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-3 h-3">
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>
                            </div>
                        )}
                        <textarea
                            ref={textareaRef}
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyDown={handleKeyDown}
                            placeholder={disabled ? "Agent is working..." : "Message Claude..."}
                            className="textarea textarea-ghost w-full focus:bg-transparent border-none resize-none bg-transparent min-h-[44px] max-h-[200px] py-3 text-base leading-relaxed placeholder:opacity-40 focus:outline-none"
                            rows={1}
                            disabled={disabled}
                        />
                    </div>

                    {/* 2. Footer: Tools (Left) & Send (Right) */}
                    <div className="flex justify-between items-center px-1 pt-1 border-t border-base-200/50 mt-1">
                        {/* Tool Bar */}
                        <div className="flex items-center gap-1">
                            {/* File Attachment */}
                            <input
                                type="file"
                                ref={fileInputRef}
                                onChange={handleFileSelect}
                                className="hidden"
                            />
                            <button
                                className={clsx(
                                    "btn btn-circle btn-ghost btn-sm text-base-content/60 hover:text-primary transition-colors",
                                    selectedFile && "text-primary bg-primary/10"
                                )}
                                disabled={disabled}
                                onClick={() => fileInputRef.current?.click()}
                                title="Attach file"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M18.375 12.739l-7.693 7.693a4.5 4.5 0 01-6.364-6.364l10.94-10.94A3 3 0 1119.5 5.818l-1.59 1.59" />
                                </svg>
                            </button>

                            {/* Web Search */}
                            <button className="btn btn-circle btn-ghost btn-sm text-base-content/60 hover:text-primary transition-colors" disabled={disabled} title="Search Web">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S12 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S12 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m-15.686 0A8.959 8.959 0 013 12c0-.778.099-1.533.284-2.253m0 0A11.953 11.953 0 0112 10.5c2.998 0 5.74-1.1 7.843-2.918" />
                                </svg>
                            </button>

                            {/* Voice Input */}
                            <button className="btn btn-circle btn-ghost btn-sm text-base-content/60 hover:text-primary transition-colors" disabled={disabled} title="Voice Input">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 18.75a6 6 0 006-6v-1.5m-6 7.5a6 6 0 01-6-6v-1.5m6 7.5v3.75m-3.75 0h7.5M12 15.75a3 3 0 01-3-3V4.5a3 3 0 116 0v8.25a3 3 0 01-3 3z" />
                                </svg>
                            </button>

                            {/* Image Upload */}
                            <button className="btn btn-circle btn-ghost btn-sm text-base-content/60 hover:text-primary transition-colors" disabled={disabled} title="Upload Image">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
                                </svg>
                            </button>
                        </div>

                        {/* Send Button */}
                        <button
                            onClick={handleSend}
                            disabled={(!input.trim() && !selectedFile) || disabled}
                            className={clsx(
                                "btn btn-sm btn-circle transition-all duration-300",
                                (input.trim() || selectedFile) ? "btn-primary shadow-md scale-100 opacity-100" : "btn-ghost bg-base-200/50 text-base-content/20 scale-95 opacity-50"
                            )}
                        >
                            {disabled ? (
                                <span className="loading loading-spinner loading-xs"></span>
                            ) : (
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5" />
                                </svg>
                            )}
                        </button>
                    </div>
                </div>

            </div>
            <div className="text-center mt-2 text-[10px] text-base-content/40">
                AI can make mistakes. Please use with caution.
            </div>
        </div>
    );
}
