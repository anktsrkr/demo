// Copyright (c) Microsoft. All rights reserved.

export type AgenticUIEventType =
  | "RUN_STARTED"
  | "RUN_FINISHED"
  | "RUN_ERROR"
  | "AGENT_STATE_SNAPSHOT"
  | "AGENT_STATE_DELTA"
  | "AGENT_PLANNING_START"
  | "AGENT_PLANNING_STEP"
  | "AGENT_PLANNING_END"
  | "TOOL_CALL_START"
  | "TOOL_CALL_ARGS"
  | "TOOL_CALL_END"
  | "TOOL_CALL_RESULT"
  | "EXECUTOR_INVOKED"
  | "EXECUTOR_COMPLETED"
  | "EXECUTOR_FAILED"
  | "SUPERSTEP_STARTED"
  | "SUPERSTEP_COMPLETED"
  | "AGENT_UPDATE"
  | "WORKFLOW_OUTPUT"
  | "WORKFLOW_WARNING"
  | "REQUEST_INFO"
  | "CHECKPOINT_CREATED"
  | "CHECKPOINT_RESUMING"
  | "CHECKPOINT_REHYDRATING"
  | "CHECKPOINT_ERROR";

export interface TypedValue<T = any> {
  typeId: {
    assemblyName: string;
    typeName: string;
  };
  value: T;
}

export interface AgenticUIEvent {
  eventType: AgenticUIEventType;
  timestamp: string;
  data?: unknown | TypedValue<unknown>;
}

export interface RunStartedEvent extends AgenticUIEvent {
  eventType: "RUN_STARTED";
  workflow_id: string;
  run_id: string;
}

export interface RunFinishedEvent extends AgenticUIEvent {
  eventType: "RUN_FINISHED";
  run_id: string;
  output?: unknown;
}

export interface RunErrorEvent extends AgenticUIEvent {
  eventType: "RUN_ERROR";
  run_id: string;
  error: string;
  details?: string;
}

export interface AgentTodo {
  description: string;
  executor?: string;
  status: string;
}

export interface AgentPlanningStartEvent extends AgenticUIEvent {
  eventType: "AGENT_PLANNING_START";
  goals: AgentTodo[];
}

export interface AgentPlanningStepEvent extends AgenticUIEvent {
  eventType: "AGENT_PLANNING_STEP";
  action: string | TypedValue<string>;
  reasoning?: string | TypedValue<string>;
  goal_index?: number;
  goal_status?: string;
}

export interface AgentPlanningEndEvent extends AgenticUIEvent {
  eventType: "AGENT_PLANNING_END";
  final_plan?: string;
}

export interface ToolCallStartEvent extends AgenticUIEvent {
  eventType: "TOOL_CALL_START";
  tool_call_id: string;
  tool_name: string;
}

export interface ToolCallArgsEvent extends AgenticUIEvent {
  eventType: "TOOL_CALL_ARGS";
  tool_call_id: string;
  args_delta: string;
}

export interface ToolCallEndEvent extends AgenticUIEvent {
  eventType: "TOOL_CALL_END";
  tool_call_id: string;
}

export interface ToolCallResultEvent extends AgenticUIEvent {
  eventType: "TOOL_CALL_RESULT";
  tool_call_id: string;
  result?: unknown;
}

export interface ExecutorInvokedEvent extends AgenticUIEvent {
  eventType: "EXECUTOR_INVOKED";
  executor_id: string;
  input?: unknown | TypedValue<unknown>;
}

export interface ExecutorCompletedEvent extends AgenticUIEvent {
  eventType: "EXECUTOR_COMPLETED";
  executor_id: string;
  output?: unknown | TypedValue<unknown>;
}

export interface ExecutorFailedEvent extends AgenticUIEvent {
  eventType: "EXECUTOR_FAILED";
  executor_id: string;
  error: string;
}

export interface SuperStepStartedEvent extends AgenticUIEvent {
  eventType: "SUPERSTEP_STARTED";
  step_number: number;
}

export interface SuperStepCompletedEvent extends AgenticUIEvent {
  eventType: "SUPERSTEP_COMPLETED";
  step_number: number;
}

export interface MessageContentText {
  $type: "text";
  text: string;
  annotations?: unknown;
  additionalProperties?: unknown;
}

export interface MessageContentUsage {
  $type: "usage";
  details: {
    inputTokenCount: number;
    outputTokenCount: number;
    totalTokenCount: number;
    cachedInputTokenCount?: number;
    reasoningTokenCount?: number;
    additionalCounts?: Record<string, number>;
  };
  annotations?: unknown;
  additionalProperties?: unknown;
}

export interface MessageContentToolCall {
  $type: "tool_call";
  id: string;
  name: string;
  arguments: string;
}

export interface MessageContentToolResult {
  $type: "tool_result";
  id: string;
  result: unknown;
}

export interface MessageContentFunctionCall {
  $type: "functionCall" | "function_call";
  callId: string;
  name: string;
  arguments: string | Record<string, any>;
}

export interface MessageContentFunctionResult {
  $type: "functionResult" | "function_result";
  callId: string;
  result: unknown;
}

export interface MessageContentCustom {
  $type: string;
  [key: string]: unknown;
}

export type MessageContent =
  | MessageContentText
  | MessageContentUsage
  | MessageContentToolCall
  | MessageContentToolResult
  | MessageContentFunctionCall
  | MessageContentFunctionResult
  | MessageContentCustom;

export function isTextContent(content: MessageContent): content is MessageContentText {
  return content.$type === "text";
}

export function isUsageContent(content: MessageContent): content is MessageContentUsage {
  return content.$type === "usage";
}

export function isToolCall(content: MessageContent): content is MessageContentToolCall | MessageContentFunctionCall {
  return content.$type === "tool_call" || content.$type === "functionCall" || content.$type === "function_call";
}

export function isToolResult(content: MessageContent): content is MessageContentToolResult | MessageContentFunctionResult {
  return content.$type === "tool_result" || content.$type === "functionResult" || content.$type === "function_result";
}

export interface AgentUpdateMessage {
  authorName?: string;
  role: "user" | "assistant" | "system";
  contents: MessageContent[];
  additionalProperties?: unknown;
  agentId: string;
  responseId: string;
  messageId: string;
  createdAt: string;
  continuationToken?: string;
}

export interface AgentUpdateEvent extends AgenticUIEvent {
  eventType: "AGENT_UPDATE";
  executor_id: string;
  update: AgentUpdateMessage;
}

export interface WorkflowOutputMessage {
  authorName?: string;
  createdAt?: string;
  role: "user" | "assistant" | "system";
  contents: MessageContent[];
  messageId?: string;
  additionalProperties?: unknown;
}

export interface WorkflowOutputEvent extends AgenticUIEvent {
  eventType: "WORKFLOW_OUTPUT";
  output?: WorkflowOutputMessage[];
}

export interface WorkflowWarningEvent extends AgenticUIEvent {
  eventType: "WORKFLOW_WARNING";
  warning: string;
}

export interface RequestInfoEvent extends AgenticUIEvent {
  eventType: "REQUEST_INFO";
  request?: unknown;
}

export interface CheckpointCreatedEvent extends AgenticUIEvent {
  eventType: "CHECKPOINT_CREATED";
  checkpoint_id: string;
  run_id: string;
  super_step_number: number;
  description?: string;
  tags?: Record<string, string>;
}

export interface CheckpointResumingEvent extends AgenticUIEvent {
  eventType: "CHECKPOINT_RESUMING";
  checkpoint_id: string;
  run_id: string;
  super_step_number: number;
  reason?: string;
}

export interface CheckpointRehydratingEvent extends AgenticUIEvent {
  eventType: "CHECKPOINT_REHYDRATING";
  checkpoint_id: string;
  original_run_id: string;
  new_run_id: string;
  super_step_number: number;
  reason?: string;
}

export interface CheckpointErrorEvent extends AgenticUIEvent {
  eventType: "CHECKPOINT_ERROR";
  checkpoint_id?: string;
  error: string;
  details?: string;
  operation?: string;
}

export type AnyAgenticUIEvent =
  | RunStartedEvent
  | RunFinishedEvent
  | RunErrorEvent
  | AgentPlanningStartEvent
  | AgentPlanningStepEvent
  | AgentPlanningEndEvent
  | ToolCallStartEvent
  | ToolCallArgsEvent
  | ToolCallEndEvent
  | ToolCallResultEvent
  | ExecutorInvokedEvent
  | ExecutorCompletedEvent
  | ExecutorFailedEvent
  | SuperStepStartedEvent
  | SuperStepCompletedEvent
  | AgentUpdateEvent
  | WorkflowOutputEvent
  | WorkflowWarningEvent
  | RequestInfoEvent
  | CheckpointCreatedEvent
  | CheckpointResumingEvent
  | CheckpointRehydratingEvent
  | CheckpointErrorEvent;
