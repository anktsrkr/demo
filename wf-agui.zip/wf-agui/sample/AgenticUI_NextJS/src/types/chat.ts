// Copyright (c) Microsoft. All rights reserved.

import type { MessageContent } from "./events";

export interface ChatMessage {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  contents: MessageContent[];
  agentId?: string;
  authorName?: string;
  createdAt: string;
  isStreaming: boolean;
  tokenUsage?: {
    inputTokens: number;
    outputTokens: number;
    totalTokens: number;
  };
}

export interface StreamingMessage {
  messageId: string;
  executorId: string;
  agentId: string;
  role: "user" | "assistant" | "system";
  textBuffer: string;
  contents: MessageContent[];
  createdAt: string;
  isComplete: boolean;
}

export interface SuperStep {
  stepNumber: number;
  status: "started" | "completed";
  executors: string[];
  startTime: string;
  endTime?: string;
}

export interface ExecutorInfo {
  id: string;
  status: "invoked" | "completed" | "failed";
  input?: unknown;
  output?: unknown;
  error?: string;
}
