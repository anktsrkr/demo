// Copyright (c) Microsoft. All rights reserved.

"use client";

import { AgenticUIProvider, type ToolResultComponentProps } from "@/lib/agentic-ui";
import { ModernLayout } from "@/components/modern/ModernLayout";
import { ToolCallCard } from "@/components/modern/ToolCallCard";

/**
 * Custom component for 'get_weather' tool result.
 * Demonstration of premium UI for a specific tool.
 */
function WeatherToolResult({ name, result }: ToolResultComponentProps) {
  const isStringResult = typeof result === "string";

  // Parse string result if possible, or use defaults
  const location = !isStringResult ? result.location : "London";
  const temp = !isStringResult ? result.temperature : "22";
  const cond = !isStringResult ? result.condition : (result.toLowerCase().includes("cloudy") ? "Cloudy" : "Sunny");

  return (
    <div className="bg-gradient-to-br from-blue-400 to-blue-600 text-white rounded-2xl p-4 my-2 shadow-lg border border-blue-300 animate-in fade-in slide-in-from-top-2 duration-500">
      <div className="flex items-center gap-3">
        <div className="text-3xl shrink-0">
          {cond === "Sunny" ? "☀️" : "☁️"}
        </div>
        <div className="min-w-0">
          <div className="text-[10px] font-bold uppercase tracking-wider opacity-70 truncate">Weather in {location}</div>
          <div className="text-xl font-black">{temp}°C - {cond}</div>
          {isStringResult && <div className="text-[10px] mt-1 opacity-60 italic truncate">{result}</div>}
        </div>
      </div>
    </div>
  );
}

/**
 * Custom component for 'get_time' tool result.
 */
function TimeToolResult({ name, result }: ToolResultComponentProps) {
  const isStringResult = typeof result === "string";
  const timeStr = isStringResult ? result : (result.time || new Date().toLocaleTimeString());
  const dateStr = !isStringResult && result.date ? result.date : new Date().toLocaleDateString();

  return (
    <div className="bg-gradient-to-br from-purple-500 to-indigo-600 text-white rounded-2xl p-4 my-2 shadow-lg border border-purple-400 animate-in fade-in slide-in-from-top-2 duration-500">
      <div className="flex items-center gap-3">
        <div className="bg-white/20 p-2 rounded-xl shrink-0">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-6 h-6">
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        </div>
        <div className="min-w-0">
          <div className="text-[10px] font-bold uppercase tracking-wider opacity-70 truncate">Current Time & Date</div>
          <div className="text-xl font-black">{timeStr}</div>
          <div className="text-[10px] opacity-60 font-medium">{dateStr}</div>
        </div>
      </div>
    </div>
  );
}

/**
 * Home page demonstrating the Agentic UI Framework with Modern UI.
 */
export default function Home() {
  return (
    <AgenticUIProvider
      config={{
        // API endpoint for SSE streaming
        apiUrl: "/api/agent",

        // Custom event component overrides
        eventComponents: {
          TOOL_CALL_START: ToolCallCard,
        },

        // Custom tool result components
        toolResultComponents: {
          GetWeather: WeatherToolResult,
          GetTimeInZone: TimeToolResult,
        },

        // Theme customization
        theme: {
          name: "system", // The sidebar theme controller will override this dynamic styling if we implement logic for it, but for now DaisyUI handles it via data-theme
        },
      }}
    >
      <ModernLayout />
    </AgenticUIProvider>
  );
}
