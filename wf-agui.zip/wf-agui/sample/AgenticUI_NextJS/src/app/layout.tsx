import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Agentic UI - Next.js + DaisyUI",
  description: "End-to-end Agentic UI demonstration with real-time streaming",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
