import { NextRequest } from "next/server";

const BACKEND_URL =
  process.env.AGENT_API_URL || "http://localhost:58186/api/travel-todos";

export async function POST(request: NextRequest) {
  const body = await request.json();

  const response = await fetch(BACKEND_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (!response.ok || !response.body) {
    console.error(`Backend error: ${response.status} ${response.statusText}`);
    return new Response(
      JSON.stringify({ error: "Failed to connect to agent API" }),
      { status: response.status, headers: { "Content-Type": "application/json" } }
    );
  }

  console.log("Backend response OK, streaming body...");

  return new Response(response.body, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
