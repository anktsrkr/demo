import { NextRequest } from "next/server";

const BACKEND_BASE_URL =
    process.env.AGENT_API_URL || "http://localhost:58186/api/travel-todos";

export async function GET(request: NextRequest, { params }: { params: Promise<{ path?: string[] }> }) {
    const resolvedParams = await params;
    const subPath = resolvedParams.path ? `/${resolvedParams.path.join("/")}` : "";
    const targetUrl = `${BACKEND_BASE_URL}/threads${subPath}`;

    const response = await fetch(targetUrl, {
        method: "GET",
        headers: { "Content-Type": "application/json" }
    });

    if (!response.ok) {
        return new Response(response.body, { status: response.status });
    }

    return new Response(response.body, {
        headers: { "Content-Type": "application/json" }
    });
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ path?: string[] }> }) {
    const resolvedParams = await params;
    const subPath = resolvedParams.path ? `/${resolvedParams.path.join("/")}` : "";
    const targetUrl = `${BACKEND_BASE_URL}/threads${subPath}`;

    const response = await fetch(targetUrl, {
        method: "DELETE"
    });

    return new Response(response.body, { status: response.status });
}


