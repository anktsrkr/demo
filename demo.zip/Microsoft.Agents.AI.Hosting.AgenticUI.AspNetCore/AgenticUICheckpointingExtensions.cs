// Copyright (c) Microsoft. All rights reserved.

using Microsoft.Agents.AI.Workflows.AgenticUI;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.Mvc;

namespace Microsoft.Agents.AI.Hosting.AgenticUI.AspNetCore;

/// <summary>
/// Extension methods for mapping checkpointing management endpoints.
/// </summary>
public static class AgenticUICheckpointingExtensions
{
    /// <summary>
    /// Maps endpoints for checkpoint management.
    /// </summary>
    public static IEndpointConventionBuilder MapAgenticUICheckpoints(
        this IEndpointRouteBuilder endpoints,
        string pattern = "/api/checkpoints")
    {
        var group = endpoints.MapGroup(pattern);

        // List all checkpoints for a run
        group.MapGet("/run/{runId}", ListCheckpoints)
            .WithName("ListCheckpoints")
            .WithOpenApi();

        // Get checkpoint metadata
        group.MapGet("/run/{runId}/{checkpointId}", GetCheckpointMetadata)
            .WithName("GetCheckpointMetadata")
            .WithOpenApi();

        // Delete a checkpoint (not supported)
        group.MapDelete("/{checkpointId}", DeleteCheckpoint)
            .WithName("DeleteCheckpoint")
            .WithOpenApi();

        // Delete all checkpoints for a run
        group.MapDelete("/run/{runId}", DeleteRunCheckpoints)
            .WithName("DeleteRunCheckpoints")
            .WithOpenApi();

        return group;
    }

    private static async Task<IResult> ListCheckpoints(
        string runId,
        [FromServices] ThreadManager? threadManager,
        CancellationToken ct)
    {
        if (threadManager == null)
        {
            return Results.BadRequest(new { error = "Checkpointing is not enabled" });
        }

        try
        {
            var checkpoints = await threadManager.ListCheckpointsAsync(runId, ct);
            return Results.Ok(checkpoints.Select(cp => new
            {
                cp.CheckpointId,
                cp.RunId,
                cp.SuperStepNumber,
                cp.CreatedAt,
                cp.Description,
                cp.Tags
            }));
        }
        catch (Exception)
        {
            return Results.InternalServerError();
        }
    }

    private static async Task<IResult> GetCheckpointMetadata(
        string runId,
        string checkpointId,
        [FromServices] ThreadManager? threadManager,
        CancellationToken ct)
    {
        if (threadManager == null)
        {
            return Results.BadRequest(new { error = "Checkpointing is not enabled" });
        }

        try
        {
            var metadata = await threadManager.GetCheckpointMetadataAsync(checkpointId, runId, ct);
            if (metadata == null || metadata.RunId != runId)
            {
                return Results.NotFound();
            }

            return Results.Ok(new
            {
                metadata.CheckpointId,
                metadata.RunId,
                metadata.SuperStepNumber,
                metadata.CreatedAt,
                metadata.Description,
                metadata.Tags
            });
        }
        catch (Exception)
        {
            return Results.InternalServerError();
        }
    }

    private static Task<IResult> DeleteCheckpoint(
        string checkpointId,
        [FromServices] ThreadManager? threadManager,
        CancellationToken ct)
    {
        if (threadManager == null)
        {
            return Task.FromResult(Results.BadRequest(new { error = "Checkpointing is not enabled" }));
        }

        // Individual checkpoint deletion is not currently supported.
        // Use DeleteRunCheckpoints endpoint to delete all checkpoints for a run.
        return Task.FromResult(Results.NotFound(new { error = "Individual checkpoint deletion is not supported. Use DELETE /run/{runId} instead." }));
    }

    private static async Task<IResult> DeleteRunCheckpoints(
        string runId,
        [FromServices] ThreadManager? threadManager,
        CancellationToken ct)
    {
        if (threadManager == null)
        {
            return Results.BadRequest(new { error = "Checkpointing is not enabled" });
        }

        try
        {
            await threadManager.DeleteThreadAsync(runId, ct);
            return Results.Ok(new { message = "Checkpoints deleted successfully" });
        }
        catch (Exception)
        {
            return Results.InternalServerError();
        }
    }
}
