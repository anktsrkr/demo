// Copyright (c) Microsoft. All rights reserved.

using Microsoft.Agents.AI.Workflows.AgenticUI;
using Microsoft.Agents.AI.Workflows.AgenticUI.Events;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace Microsoft.Agents.AI.Hosting.AgenticUI.AspNetCore;

/// <summary>
/// Extension methods for mapping thread management endpoints.
/// </summary>
public static class AgenticUIThreadExtensions
{
    /// <summary>
    /// Maps endpoints for managing agent threads (conversations).
    /// </summary>
    /// <param name="endpoints">The endpoint route builder.</param>
    /// <param name="pattern">The base route pattern.</param>
    /// <returns>A convention builder.</returns>
    public static IEndpointConventionBuilder MapAgenticUIThreads(
        this IEndpointRouteBuilder endpoints,
        string pattern = "/api/threads")
    {
        var group = endpoints.MapGroup(pattern);

        // List all threads
        group.MapGet("/", ListThreads)
            .WithName("ListThreads");

        // Get thread history (messages)
        group.MapGet("/{runId}/history", GetThreadHistory)
            .WithName("GetThreadHistory");

        // Delete a thread
        group.MapDelete("/{runId}", DeleteThread)
            .WithName("DeleteThread");

        return group;
    }

    private static async Task<IResult> ListThreads(
        [FromServices] ThreadManager? threadManager,
        CancellationToken ct)
    {
        if (threadManager == null)
        {
            return Results.Ok(Array.Empty<object>());
        }

        try
        {
            var runIds = await threadManager.ListThreadsAsync(ct);
            var threads = new List<object>();

            foreach (var runId in runIds)
            {
                var latest = await threadManager.GetLatestCheckpointAsync(runId, ct);
                if (latest != null)
                {
                    threads.Add(new
                    {
                        id = runId,
                        lastModified = latest.CreatedAt,
                        metadata = latest.Tags
                    });
                }
            }

            return Results.Ok(threads.OrderByDescending(t => ((dynamic)t).lastModified));
        }
        catch (Exception)
        {
            return Results.InternalServerError();
        }
    }

    private static async Task<IResult> GetThreadHistory(
        string runId,
        [FromServices] ThreadManager? threadManager,
        CancellationToken ct)
    {
        if (threadManager == null)
        {
            return Results.NotFound();
        }

        try
        {
            var data = await threadManager.GetChatHistoryDataAsync(runId, ct);
            if (!string.IsNullOrEmpty(data))
            {
                return Results.Content(data, "application/json");
            }

            return Results.Ok(Array.Empty<object>());
        }
        catch (Exception)
        {
            return Results.InternalServerError();
        }
    }

    private static async Task<IResult> DeleteThread(
        string runId,
        [FromServices] ThreadManager? threadManager,
        CancellationToken ct)
    {
        if (threadManager == null)
        {
            return Results.NotFound();
        }

        try
        {
            await threadManager.DeleteThreadAsync(runId, ct);
            return Results.Ok();
        }
        catch (Exception)
        {
            return Results.InternalServerError();
        }
    }
}
