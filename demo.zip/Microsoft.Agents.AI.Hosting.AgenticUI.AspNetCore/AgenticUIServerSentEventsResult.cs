// Copyright (c) Microsoft. All rights reserved.

using System.Text.Json;
using Microsoft.Agents.AI.Workflows.AgenticUI.Events;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Microsoft.Agents.AI.Hosting.AgenticUI.AspNetCore;

/// <summary>
/// An IResult that streams Agentic UI events as Server-Sent Events (SSE).
/// </summary>
public class AgenticUIServerSentEventsResult(IAsyncEnumerable<AgenticUIEvent> events, IAsyncDisposable? disposable = null) : IResult
{
    private const string ContentType = "text/event-stream";

    public async Task ExecuteAsync(HttpContext httpContext)
    {
        var response = httpContext.Response;
        response.Headers.ContentType = ContentType;
        response.Headers.CacheControl = "no-cache";
        response.Headers.Connection = "keep-alive";
        response.Headers["X-Accel-Buffering"] = "no";

        var bufferingFeature = httpContext.Features.Get<Microsoft.AspNetCore.Http.Features.IHttpResponseBodyFeature>();
        bufferingFeature?.DisableBuffering();

        var logger = httpContext.RequestServices.GetService<ILogger<AgenticUIServerSentEventsResult>>();

        // Get configured options or default
        var options = httpContext.RequestServices.GetService<IOptions<AgenticUIJsonSerializerOptions>>()?.Value?.Options
                      ?? new JsonSerializerOptions(JsonSerializerDefaults.Web);

        try
        {
            await response.Body.FlushAsync(httpContext.RequestAborted);

            await foreach (var evt in events.WithCancellation(httpContext.RequestAborted))
            {
                // Serialize the event. 
                // Polymorphism is handled by the attributes on AgenticUIEvent or the options.
                var json = JsonSerializer.Serialize(evt, options);

                // SSE format: data: {json}\n\n
                await response.WriteAsync($"data: {json}\n\n", httpContext.RequestAborted);
                await response.Body.FlushAsync(httpContext.RequestAborted);
            }
        }
        catch (OperationCanceledException)
        {
            logger?.LogInformation("Stream cancelled by client.");
        }
        catch (Exception ex)
        {
            logger?.LogError(ex, "Error streaming Agentic UI events.");
        }
        finally
        {
            if (disposable != null)
            {
                await disposable.DisposeAsync();
            }
        }
    }
}
