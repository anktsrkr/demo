// Copyright (c) Microsoft. All rights reserved.

using System.Text.Json;
using Microsoft.Agents.AI.Workflows.AgenticUI;
using Microsoft.Extensions.Options;

namespace Microsoft.Agents.AI.Hosting.AgenticUI.AspNetCore;

/// <summary>
/// Options for configuring JSON serialization for Agentic UI events.
/// </summary>
public class AgenticUIJsonSerializerOptions : IOptions<AgenticUIJsonSerializerOptions>
{
    /// <summary>
    /// The underlying JsonSerializerOptions.
    /// </summary>
    public JsonSerializerOptions Options { get; }

    /// <summary>
    /// The event registry for configuring custom events.
    /// </summary>
    public AgenticUIEventRegistry Registry { get; } = new();

    public AgenticUIJsonSerializerOptions(JsonSerializerOptions? options = null)
    {
        Options = options ?? new JsonSerializerOptions(JsonSerializerDefaults.Web);
        // Ensure polymorphism is enabled/configured if not already locally by attributes
        Registry.ConfigureSerializerOptions(Options);
    }
    
    // Default constructor for DI
    public AgenticUIJsonSerializerOptions() : this(null) { }

    AgenticUIJsonSerializerOptions IOptions<AgenticUIJsonSerializerOptions>.Value => this;
}
