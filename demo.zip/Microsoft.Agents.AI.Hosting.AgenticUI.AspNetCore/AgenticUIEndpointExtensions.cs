// Copyright (c) Microsoft. All rights reserved.

using Microsoft.Agents.AI.Workflows;
using Microsoft.Agents.AI.Workflows.AgenticUI;
using Microsoft.Agents.AI.Workflows.AgenticUI.Events;
using Microsoft.Agents.AI.Workflows.Checkpointing;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using System.Text.Json;

namespace Microsoft.Agents.AI.Hosting.AgenticUI.AspNetCore;

/// <summary>
/// Extension methods for mapping AgenticUI endpoints.
/// </summary>
public static class AgenticUIEndpointExtensions
{
    /// <summary>
    /// Maps an endpoint for streaming Agentic UI events from a workflow.
    /// </summary>
    /// <param name="endpoints">The endpoint route builder.</param>
    /// <param name="pattern">The route pattern.</param>
    /// <param name="workflow">The workflow to execute.</param>
    /// <returns>A convention builder.</returns>
    public static IEndpointConventionBuilder MapAgenticUI(
        this IEndpointRouteBuilder endpoints,
        string pattern,
        Workflow workflow)
    {
        return endpoints.MapPost(pattern, (
            HttpContext context,
            AgenticUIInput? input,
            [FromServices] CheckpointManager? checkpointManager) =>
                ExecuteWorkflowAsync(context, workflow, input, checkpointManager));
    }

    /// <summary>
    /// Maps an endpoint for streaming Agentic UI events from a workflow factory.
    /// </summary>
    /// <param name="endpoints">The endpoint route builder.</param>
    /// <param name="pattern">The route pattern.</param>
    /// <param name="workflowFactory">The factory to create a new workflow instance per request.</param>
    /// <returns>A convention builder.</returns>
    public static IEndpointConventionBuilder MapAgenticUI(
        this IEndpointRouteBuilder endpoints,
        string pattern,
        Func<Workflow> workflowFactory)
    {
        return endpoints.MapPost(pattern, (
            HttpContext context,
            AgenticUIInput? input,
            [FromServices] CheckpointManager? checkpointManager) =>
                ExecuteWorkflowAsync(context, workflowFactory(), input, checkpointManager));
    }

    private static async Task<IResult> ExecuteWorkflowAsync(
        HttpContext context,
        Workflow workflow,
        AgenticUIInput? input,
        CheckpointManager? checkpointManager)
    {
        // Validate input
        if (input == null)
        {
            return new AgenticUIServerSentEventsResult(StreamErrorEvent("Invalid input", "The request body was missing or invalid."));
        }

        // Extract input parameters
        var runId = input.RunId ?? Guid.NewGuid().ToString("N");
        var initialInput = input.Input ?? "Start";
        var ct = context.RequestAborted;

        try
        {
            // Get checkpoint store and last checkpoint for this run
            var store = context.RequestServices.GetService<ICheckpointStore<JsonElement>>();
            var lastCheckpoint = await GetLastCheckpointAsync(store, runId);

            // Determine execution path based on input type
            var run = await CreateStreamingRunAsync(
                workflow,
                input,
                runId,
                initialInput,
                lastCheckpoint,
                checkpointManager,
                store,
                ct);

            // Send turn token to trigger event emission
            await run.TrySendMessageAsync(new TurnToken(emitEvents: true));

            // Return SSE stream
            return new AgenticUIServerSentEventsResult(StreamWorkflowEvents(run, ct), run);
        }
        catch (InvalidOperationException ex)
        {
            return new AgenticUIServerSentEventsResult(StreamErrorEvent("Workflow error", ex.Message));
        }
        catch (Exception ex)
        {
            return new AgenticUIServerSentEventsResult(StreamErrorEvent("Internal error", ex.Message));
        }
    }

    /// <summary>
    /// Gets the last checkpoint for a run, if any.
    /// </summary>
    private static async Task<CheckpointInfo?> GetLastCheckpointAsync(
        ICheckpointStore<JsonElement>? store,
        string runId)
    {
        if (store == null) return null;

        var index = await store.RetrieveIndexAsync(runId).ConfigureAwait(false);
        return index.LastOrDefault();
    }

    /// <summary>
    /// Creates a streaming run based on input type (new run, resume, or external response).
    /// </summary>
    private static async Task<StreamingRun> CreateStreamingRunAsync(
        Workflow workflow,
        AgenticUIInput input,
        string runId,
        string initialInput,
        CheckpointInfo? lastCheckpoint,
        CheckpointManager? checkpointManager,
        ICheckpointStore<JsonElement>? store,
        CancellationToken ct)
    {
        // External response path (HITL approval/rejection)
        if (!string.IsNullOrEmpty(input.RequestId))
        {
            return await HandleExternalResponseAsync(
                workflow, input, runId, lastCheckpoint, checkpointManager, store, ct);
        }

        // Normal input path - start or resume workflow
        return await HandleNormalInputAsync(
            workflow, runId, initialInput, lastCheckpoint, checkpointManager, ct);
    }

    /// <summary>
    /// Handles external responses (HITL) by resuming from checkpoint and sending response.
    /// </summary>
    private static async Task<StreamingRun> HandleExternalResponseAsync(
        Workflow workflow,
        AgenticUIInput input,
        string runId,
        CheckpointInfo? lastCheckpoint,
        CheckpointManager? checkpointManager,
        ICheckpointStore<JsonElement>? store,
        CancellationToken ct)
    {
        // Validate port exists
        var ports = workflow.ReflectPorts();
        if (!ports.TryGetValue(input.PortId ?? string.Empty, out var portInfo))
        {
            throw new InvalidOperationException($"Port '{input.PortId}' not found in workflow.");
        }

        // Extract response data from input
        var responseData = ExtractResponseData(input.Response);

        // Resume from checkpoint if available
        if (checkpointManager != null && lastCheckpoint != null && store != null)
        {
            // Get request ID from checkpoint's outstanding requests
            var restoredRequestId = await GetOutstandingRequestIdAsync(store, runId, lastCheckpoint, input.PortId);

            if (string.IsNullOrEmpty(restoredRequestId))
            {
                throw new InvalidOperationException(
                    $"No outstanding request found for port '{input.PortId}' in checkpoint.");
            }

            // Resume workflow from checkpoint
            var checkpointed = await InProcessExecution.ResumeStreamAsync(
                workflow, lastCheckpoint, checkpointManager, runId, ct);

            // Send external response with restored request ID
            var response = new ExternalResponse(portInfo, restoredRequestId, new PortableValue(responseData));
            await checkpointed.Run.TrySendMessageAsync(response).ConfigureAwait(false);

            return checkpointed.Run;
        }

        // No checkpoint - stream with response directly
        var directResponse = new ExternalResponse(portInfo, input.RequestId!, new PortableValue(responseData));
        return await InProcessExecution.StreamAsync(workflow, directResponse, runId, ct);
    }

    /// <summary>
    /// Handles normal input by starting new workflow or resuming from checkpoint.
    /// </summary>
    private static async Task<StreamingRun> HandleNormalInputAsync(
        Workflow workflow,
        string runId,
        string initialInput,
        CheckpointInfo? lastCheckpoint,
        CheckpointManager? checkpointManager,
        CancellationToken ct)
    {
        // Resume from existing checkpoint
        if (checkpointManager != null && lastCheckpoint != null)
        {
            var checkpointed = await InProcessExecution.ResumeStreamAsync(
                workflow, lastCheckpoint, checkpointManager, runId, ct);
            await checkpointed.Run.TrySendMessageAsync(initialInput).ConfigureAwait(false);
            return checkpointed.Run;
        }

        // Start new workflow with checkpointing
        if (checkpointManager != null)
        {
            var checkpointed = await InProcessExecution.StreamAsync(
                workflow, initialInput, checkpointManager, runId, ct);
            return checkpointed.Run;
        }

        // Start new workflow without checkpointing
        return await InProcessExecution.StreamAsync(workflow, initialInput, runId, ct);
    }

    /// <summary>
    /// Extracts response data from input, handling JsonElement conversion.
    /// </summary>
    private static string ExtractResponseData(object? response)
    {
        if (response is JsonElement jsonElement)
        {
            return jsonElement.ValueKind == JsonValueKind.String
                ? jsonElement.GetString() ?? string.Empty
                : jsonElement.GetRawText();
        }

        return response?.ToString() ?? string.Empty;
    }

    /// <summary>
    /// Gets the outstanding request ID from checkpoint data for a specific port.
    /// </summary>
    private static async Task<string?> GetOutstandingRequestIdAsync(
        ICheckpointStore<JsonElement> store,
        string runId,
        CheckpointInfo lastCheckpoint,
        string? portId)
    {
        var checkpointData = await store.RetrieveCheckpointAsync(runId, lastCheckpoint).ConfigureAwait(false);

        if (checkpointData.TryGetProperty("runnerData", out var runnerData) &&
            runnerData.TryGetProperty("outstandingRequests", out var outstandingRequests))
        {
            foreach (var request in outstandingRequests.EnumerateArray())
            {
                if (request.TryGetProperty("portInfo", out var reqPortInfo) &&
                    reqPortInfo.TryGetProperty("portId", out var reqPortId) &&
                    reqPortId.GetString() == portId)
                {
                    if (request.TryGetProperty("requestId", out var reqId))
                    {
                        return reqId.GetString();
                    }
                }
            }
        }

        return null;
    }

    /// <summary>
    /// Streams workflow events as AgenticUI events.
    /// </summary>
    private static async IAsyncEnumerable<AgenticUIEvent> StreamWorkflowEvents(
        StreamingRun run,
        [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken ct)
    {
        yield return new RunStartedEvent();

        await foreach (var evt in run.WatchStreamAsync(ct).AsAgenticUIEvents())
        {
            yield return evt;
        }

        yield return new RunFinishedEvent();
    }

    /// <summary>
    /// Streams a single error event.
    /// </summary>
    private static async IAsyncEnumerable<AgenticUIEvent> StreamErrorEvent(string error, string details)
    {
        yield return new RunErrorEvent { Error = error, Details = details };
        await Task.CompletedTask;
    }
}

/// <summary>
/// Input model for AgenticUI requests.
/// </summary>
public class AgenticUIInput
{
    /// <summary>
    /// The user input message.
    /// </summary>
    public string? Input { get; set; }

    /// <summary>
    /// The run ID (for resuming or continuing a conversation).
    /// </summary>
    public string? RunId { get; set; }

    /// <summary>
    /// The request ID (for external responses/HITL).
    /// </summary>
    public string? RequestId { get; set; }

    /// <summary>
    /// The port ID (for external responses/HITL).
    /// </summary>
    public string? PortId { get; set; }

    /// <summary>
    /// The external response data (for HITL approval/rejection).
    /// </summary>
    public object? Response { get; set; }
}
