// Copyright (c) Microsoft. All rights reserved.

using System.Runtime.CompilerServices;
using Microsoft.Agents.AI.Workflows.AgenticUI.Events;

namespace Microsoft.Agents.AI.Workflows.AgenticUI;

public static class WorkflowEventToAgenticUIExtensions
{
    public static async IAsyncEnumerable<AgenticUIEvent> AsAgenticUIEvents(
        this IAsyncEnumerable<WorkflowEvent> workflowEvents,
        [EnumeratorCancellation] CancellationToken cancellationToken = default)
    {
        await foreach (var evt in workflowEvents.WithCancellation(cancellationToken))
        {
            if (evt is AgenticUIEvent agenticEvent)
            {
                yield return agenticEvent;
                continue;
            }

            if (evt is ExecutorInvokedEvent invokedEvent)
            {
                yield return new ExecutorInvokedUIEvent
                {
                    ExecutorId = invokedEvent.ExecutorId,
                    Input = invokedEvent.Data
                };
            }
            else if (evt is ExecutorCompletedEvent completedEvent)
            {
                yield return new ExecutorCompletedUIEvent
                {
                    ExecutorId = completedEvent.ExecutorId,
                    Output = completedEvent.Data
                };
            }
            else if (evt is ExecutorFailedEvent failedEvent)
            {
                yield return new ExecutorFailedUIEvent
                {
                    ExecutorId = failedEvent.ExecutorId,
                    Error = failedEvent.Data?.ToString() ?? "Unknown error"
                };
            }
            else if (evt is SuperStepStartedEvent stepStarted)
            {
                yield return new SuperStepStartedUIEvent
                {
                    StepNumber = stepStarted.StepNumber
                };
            }
            else if (evt is SuperStepCompletedEvent stepCompleted)
            {
                yield return new SuperStepCompletedUIEvent
                {
                    StepNumber = stepCompleted.StepNumber
                };
            }
            else if (evt is AgentRunUpdateEvent agentUpdate)
            {
                yield return new AgentUpdateUIEvent
                {
                    ExecutorId = agentUpdate.ExecutorId,
                    Update = agentUpdate.Update
                };
            }
            else if (evt is AgentRunResponseEvent agentResponse)
            {
                yield return new AgentUpdateUIEvent
                {
                    ExecutorId = agentResponse.ExecutorId,
                    Update = agentResponse.Response
                };
            }
            else if (evt is WorkflowOutputEvent outputEvent)
            {
                yield return new WorkflowOutputUIEvent
                {
                    Output = outputEvent.Data
                };
            }
            else if (evt is WorkflowErrorEvent errorEvent)
            {
                yield return new RunErrorEvent
                {
                    Error = errorEvent.Data?.ToString() ?? "Workflow error"
                };
            }
            else if (evt is WorkflowWarningEvent warningEvent)
            {
                yield return new WorkflowWarningUIEvent
                {
                    Warning = warningEvent.Data?.ToString() ?? "Workflow warning"
                };
            }
            else if (evt is SubworkflowErrorEvent subError)
            {
                yield return new RunErrorEvent
                {
                    Error = subError.Data?.ToString() ?? "Subworkflow error"
                };
            }
            else if (evt is SubworkflowWarningEvent subWarning)
            {
                yield return new WorkflowWarningUIEvent
                {
                    Warning = subWarning.Data?.ToString() ?? "Subworkflow warning"
                };
            }
            else if (evt is RequestInfoEvent infoEvent)
            {
                yield return new RequestInfoUIEvent
                {
                    Request = infoEvent.Request
                };
            }
            else if (evt is WorkflowStartedEvent)
            {
                yield return new RunStartedEvent();
            }

            // Allow custom logic or just ignore unknown events
        }
    }
}
