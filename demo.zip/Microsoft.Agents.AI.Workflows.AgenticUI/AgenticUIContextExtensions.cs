// Copyright (c) Microsoft. All rights reserved.

using System.Text.Json;
using Microsoft.Agents.AI.Workflows.AgenticUI.Events;

namespace Microsoft.Agents.AI.Workflows.AgenticUI;

public static class AgenticUIContextExtensions
{
    // Generic Emitter
    public static ValueTask EmitAsync<TEvent>(this IWorkflowContext context, TEvent agenticEvent, CancellationToken ct = default)
        where TEvent : AgenticUIEvent
    {
        return context.AddEventAsync(agenticEvent, ct);
    }

    // Planning Events - Helpers for heavily used complex events
    public static ValueTask EmitPlanningStartAsync(this IWorkflowContext context, List<AgentTodo> todos, string? planId = null, CancellationToken ct = default)
    {
        return context.AddEventAsync(new AgentPlanningStartEvent { Todos = todos, PlanId = planId }, ct);
    }

    public static ValueTask EmitPlanningStepAsync(this IWorkflowContext context, string action, string? reasoning = null, CancellationToken ct = default, int? goalIndex = null, string? goalStatus = null, string? planId = null)
    {
        return context.AddEventAsync(new AgentPlanningStepEvent
        {
            Action = action,
            Reasoning = reasoning,
            GoalIndex = goalIndex,
            GoalStatus = goalStatus,
            PlanId = planId
        }, ct);
    }

    public static ValueTask EmitPlanningEndAsync(this IWorkflowContext context, string? finalPlan = null, string? planId = null, CancellationToken ct = default)
    {
        return context.AddEventAsync(new AgentPlanningEndEvent { FinalPlan = finalPlan, PlanId = planId }, ct);
    }

    // Custom Ad-hoc Events
    public static ValueTask EmitCustomAsync(this IWorkflowContext context, string eventType, object? payload = null, CancellationToken ct = default)
    {
        JsonElement? jsonPayload = payload is not null ? JsonSerializer.SerializeToElement(payload) : null;
        return context.AddEventAsync(new CustomAgenticUIEvent(eventType) { Payload = jsonPayload }, ct);
    }
}
