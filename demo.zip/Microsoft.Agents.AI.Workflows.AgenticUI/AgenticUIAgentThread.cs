// Copyright (c) Microsoft. All rights reserved.

using Microsoft.Extensions.AI;
using System.Text.Json;

namespace Microsoft.Agents.AI.Workflows.AgenticUI;

/// <summary>
/// Represents thread information for AgenticUI workflows.
/// Thread state is derived from checkpoints rather than stored independently.
/// </summary>
public class AgenticUIThread
{
    /// <summary>
    /// Gets the run ID associated with this thread.
    /// </summary>
    public string RunId { get; }

    /// <summary>
    /// Gets the messages in this thread.
    /// </summary>
    public IReadOnlyList<ChatMessage> Messages { get; }

    /// <summary>
    /// Gets the timestamp of the last modification.
    /// </summary>
    public DateTimeOffset? LastModified { get; }

    /// <summary>
    /// Initializes a new instance with an empty message list.
    /// </summary>
    /// <param name="runId">The workflow run ID.</param>
    public AgenticUIThread(string runId)
    {
        RunId = runId ?? throw new ArgumentNullException(nameof(runId));
        Messages = Array.Empty<ChatMessage>();
    }

    /// <summary>
    /// Initializes a new instance with existing messages.
    /// </summary>
    /// <param name="runId">The workflow run ID.</param>
    /// <param name="messages">The messages.</param>
    /// <param name="lastModified">Optional last modified timestamp.</param>
    public AgenticUIThread(string runId, IEnumerable<ChatMessage> messages, DateTimeOffset? lastModified = null)
    {
        RunId = runId ?? throw new ArgumentNullException(nameof(runId));
        Messages = messages?.ToList() ?? new List<ChatMessage>();
        LastModified = lastModified;
    }

    /// <summary>
    /// Creates an AgenticUIThread from checkpoint data using a ThreadManager.
    /// </summary>
    /// <param name="threadManager">The thread manager.</param>
    /// <param name="runId">The workflow run ID.</param>
    /// <param name="ct">Cancellation token.</param>
    /// <returns>A new AgenticUIThread hydrated with messages from the checkpoint.</returns>
    public static async ValueTask<AgenticUIThread> FromThreadManagerAsync(
        ThreadManager threadManager,
        string runId,
        CancellationToken ct = default)
    {
        if (threadManager == null) throw new ArgumentNullException(nameof(threadManager));
        if (string.IsNullOrEmpty(runId)) throw new ArgumentException("RunId cannot be null or empty.", nameof(runId));

        return await threadManager.GetThreadAsync(runId, ct).ConfigureAwait(false);
    }

    /// <summary>
    /// Serializes the thread to JSON.
    /// </summary>
    public string ToJson(JsonSerializerOptions? options = null)
    {
        return JsonSerializer.Serialize(new
        {
            runId = RunId,
            messages = Messages.Select(m => new { role = m.Role.Value, content = m.Text }),
            lastModified = LastModified
        }, options);
    }
}
