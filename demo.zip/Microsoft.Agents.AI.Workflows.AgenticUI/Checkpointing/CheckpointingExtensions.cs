// Copyright (c) Microsoft. All rights reserved.

using Microsoft.Agents.AI.Workflows.AgenticUI.Events;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Agents.AI.Workflows;
using Microsoft.Agents.AI.Workflows.Checkpointing;

namespace Microsoft.Agents.AI.Workflows.AgenticUI.Checkpointing;

/// <summary>
/// Extension methods for checkpoint operations.
/// </summary>
public static class CheckpointingExtensions
{
    /// <summary>
    /// Adds Agentic UI ThreadManager by wrapping an existing <see cref="ICheckpointStore{JsonElement}"/>.
    /// </summary>
    public static IServiceCollection AddAgenticUICheckpointing(this IServiceCollection services)
    {
        services.AddSingleton<ThreadManager>(sp =>
        {
            var store = sp.GetRequiredService<ICheckpointStore<System.Text.Json.JsonElement>>();
            return new ThreadManager(store);
        });
        return services;
    }

    /// <summary>
    /// Adds Agentic UI ThreadManager with a specific store.
    /// </summary>
    public static IServiceCollection AddAgenticUICheckpointing(
        this IServiceCollection services,
        ICheckpointStore<System.Text.Json.JsonElement> store)
    {
        services.AddSingleton(new ThreadManager(store));
        return services;
    }

    /// <summary>
    /// Emits a checkpoint created event.
    /// </summary>
    public static ValueTask EmitCheckpointCreatedAsync(
        this IWorkflowContext context,
        string checkpointId,
        string runId,
        int superStepNumber,
        string? description = null,
        Dictionary<string, string>? tags = null,
        CancellationToken ct = default)
    {
        var evt = ThreadManager.CreateCreatedEvent(checkpointId, runId, superStepNumber, description, tags);
        return context.EmitAsync(evt, ct);
    }

    /// <summary>
    /// Emits a checkpoint error event.
    /// </summary>
    public static ValueTask EmitCheckpointErrorAsync(
        this IWorkflowContext context,
        string error,
        string? checkpointId = null,
        string? operation = null,
        string? details = null,
        CancellationToken ct = default)
    {
        var evt = ThreadManager.CreateErrorEvent(error, checkpointId, operation, details);
        return context.EmitAsync(evt, ct);
    }
}
