// Copyright (c) Microsoft. All rights reserved.

using Microsoft.Agents.AI.Workflows.Checkpointing;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Microsoft.Agents.AI.Workflows.AgenticUI.Checkpointing;

/// <summary>
/// Extension interface for <see cref="ICheckpointStore{T}"/> that adds management capabilities
/// like listing runs and deleting checkpoints.
/// </summary>
/// <typeparam name="TStoreObject">The type of object to be stored.</typeparam>
public interface ICheckpointStoreWithManagement<TStoreObject> : ICheckpointStore<TStoreObject>
{
    /// <summary>
    /// Lists all unique run IDs in the store.
    /// </summary>
    ValueTask<IEnumerable<string>> ListRunsAsync(CancellationToken ct = default);

    /// <summary>
    /// Deletes all checkpoints for a specific run.
    /// </summary>
    ValueTask DeleteRunCheckpointsAsync(string runId, CancellationToken ct = default);

    /// <summary>
    /// Deletes a specific checkpoint.
    /// </summary>
    ValueTask<bool> DeleteCheckpointAsync(string checkpointId, CancellationToken ct = default);
}
