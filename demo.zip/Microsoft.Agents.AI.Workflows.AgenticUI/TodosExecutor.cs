// Copyright (c) Microsoft. All rights reserved.

using Microsoft.Agents.AI.Workflows.AgenticUI.Events;
using Microsoft.Agents.AI.Workflows.Execution;

namespace Microsoft.Agents.AI.Workflows.AgenticUI;

/// <summary>
/// An executor that emits a list of todos as a planning event and then completes.
/// This is intended to be used as a starting point for workflows that route tasks based on a plan.
/// </summary>
public class TodosExecutor : Executor
{
    private readonly List<AgentTodo> _todos;

    public TodosExecutor(string id, List<AgentTodo> todos) : base(id)
    {
        _todos = todos;
    }

    protected override RouteBuilder ConfigureRoutes(RouteBuilder builder)
    {
        // No input routes needed, this executor is a source
        return builder.AddCatchAll(ExecuteAsync);
    }

    // Changed to match the catch-all signature
    private async ValueTask ExecuteAsync(PortableValue input, IWorkflowContext context)
    {
        // Emit the planning start event with the todos
        await context.EmitPlanningStartAsync(_todos, planId: Id);

        // Yield the todos as the output of this executor
        await context.YieldOutputAsync(_todos);
    }
}
