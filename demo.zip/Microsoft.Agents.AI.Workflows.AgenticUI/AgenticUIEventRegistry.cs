// Copyright (c) Microsoft. All rights reserved.

using System.Text.Json;
using System.Text.Json.Serialization.Metadata;
using Microsoft.Agents.AI.Workflows.AgenticUI.Events;

namespace Microsoft.Agents.AI.Workflows.AgenticUI;

/// <summary>
/// Registry for managing Agentic UI event types, including custom events.
/// </summary>
public class AgenticUIEventRegistry
{
    private readonly List<JsonDerivedType> _customTypes = [];

    /// <summary>
    /// Registers a custom event type for polymorphic serialization.
    /// </summary>
    /// <typeparam name="TEvent">The custom event type.</typeparam>
    /// <param name="typeDiscriminator">The string discriminator for the event type.</param>
    /// <returns>The registry instance for chaining.</returns>
    public AgenticUIEventRegistry RegisterCustomEvent<TEvent>(string typeDiscriminator)
        where TEvent : AgenticUIEvent
    {
        _customTypes.Add(new JsonDerivedType(typeof(TEvent), typeDiscriminator));
        return this;
    }

    /// <summary>
    /// Configures the JsonSerializerOptions with the registered custom types.
    /// </summary>
    /// <param name="options">The options to configure.</param>
    public void ConfigureSerializerOptions(JsonSerializerOptions options)
    {
        if (_customTypes.Count > 0)
        {
            options.TypeInfoResolver = options.TypeInfoResolver?.WithAddedModifier(typeInfo =>
            {
                if (typeInfo.Type == typeof(AgenticUIEvent))
                {
                    foreach (var derivedType in _customTypes)
                    {
                        if (!typeInfo.PolymorphismOptions!.DerivedTypes.Any(dt => dt.DerivedType == derivedType.DerivedType))
                        {
                            typeInfo.PolymorphismOptions.DerivedTypes.Add(derivedType);
                        }
                    }
                }

                if (typeInfo.Type == typeof(CustomAgenticUIEvent))
                {
                    // This is tricky because System.Text.Json expects a static discriminator mapping.
                    // If users use CustomAgenticUIEvent directly with different eventType strings,
                    // we can't easily support that with standard polymorphic serialization.
                    // However, we can at least make sure it doesn't break.
                }
            });
        }
    }
}
