// Copyright (c) Microsoft. All rights reserved.

using System.Text.Json.Serialization;

namespace Microsoft.Agents.AI.Workflows.AgenticUI.Events;

/// <summary>
/// Event emitted when the workflow produces an output.
/// </summary>
public class WorkflowOutputUIEvent : AgenticUIEvent
{
    [JsonPropertyName("output")]
    public object? Output { get; set; }
}

/// <summary>
/// Event emitted when the workflow produces a warning.
/// </summary>
public class WorkflowWarningUIEvent : AgenticUIEvent
{
    [JsonPropertyName("warning")]
    public string Warning { get; set; } = string.Empty;
}

/// <summary>
/// Event emitted when the workflow requests external information.
/// </summary>
public class RequestInfoUIEvent : AgenticUIEvent
{
    [JsonPropertyName("request")]
    public object? Request { get; set; }
}
