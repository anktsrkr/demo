// Copyright (c) Microsoft. All rights reserved.

using System.Text.Json.Serialization;

namespace Microsoft.Agents.AI.Workflows.AgenticUI.Events;

/// <summary>
/// Event emitted when a checkpoint is created during workflow execution.
/// </summary>
public class CheckpointCreatedUIEvent : AgenticUIEvent
{
    /// <summary>
    /// Unique identifier for this checkpoint.
    /// </summary>
    [JsonPropertyName("checkpoint_id")]
    public required string CheckpointId { get; set; }

    /// <summary>
    /// The run ID this checkpoint belongs to.
    /// </summary>
    [JsonPropertyName("run_id")]
    public required string RunId { get; set; }

    /// <summary>
    /// The super step number at which this checkpoint was created.
    /// </summary>
    [JsonPropertyName("super_step_number")]
    public int SuperStepNumber { get; set; }

    /// <summary>
    /// Optional description of the checkpoint.
    /// </summary>
    [JsonPropertyName("description")]
    public string? Description { get; set; }

    /// <summary>
    /// Tags associated with the checkpoint.
    /// </summary>
    [JsonPropertyName("tags")]
    public Dictionary<string, string>? Tags { get; set; }
}

/// <summary>
/// Event emitted when a checkpoint is being restored to resume execution.
/// </summary>
public class CheckpointResumingUIEvent : AgenticUIEvent
{
    /// <summary>
    /// The checkpoint ID being restored.
    /// </summary>
    [JsonPropertyName("checkpoint_id")]
    public required string CheckpointId { get; set; }

    /// <summary>
    /// The run ID being resumed.
    /// </summary>
    [JsonPropertyName("run_id")]
    public required string RunId { get; set; }

    /// <summary>
    /// The super step number from which execution resumes.
    /// </summary>
    [JsonPropertyName("super_step_number")]
    public int SuperStepNumber { get; set; }

    /// <summary>
    /// Reason or context for the resume operation.
    /// </summary>
    [JsonPropertyName("reason")]
    public string? Reason { get; set; }
}

/// <summary>
/// Event emitted when a checkpoint is being rehydrated (creating a new workflow instance).
/// </summary>
public class CheckpointRehydratingUIEvent : AgenticUIEvent
{
    /// <summary>
    /// The checkpoint ID being used for rehydration.
    /// </summary>
    [JsonPropertyName("checkpoint_id")]
    public required string CheckpointId { get; set; }

    /// <summary>
    /// The original run ID from the checkpoint.
    /// </summary>
    [JsonPropertyName("original_run_id")]
    public required string OriginalRunId { get; set; }

    /// <summary>
    /// The new run ID for the rehydrated workflow instance.
    /// </summary>
    [JsonPropertyName("new_run_id")]
    public required string NewRunId { get; set; }

    /// <summary>
    /// The super step number from which execution resumes.
    /// </summary>
    [JsonPropertyName("super_step_number")]
    public int SuperStepNumber { get; set; }

    /// <summary>
    /// Reason or context for the rehydrate operation.
    /// </summary>
    [JsonPropertyName("reason")]
    public string? Reason { get; set; }
}

/// <summary>
/// Event emitted when a checkpoint operation fails.
/// </summary>
public class CheckpointErrorUIEvent : AgenticUIEvent
{
    /// <summary>
    /// The checkpoint ID related to the error (if applicable).
    /// </summary>
    [JsonPropertyName("checkpoint_id")]
    public string? CheckpointId { get; set; }

    /// <summary>
    /// The error message.
    /// </summary>
    [JsonPropertyName("error")]
    public required string Error { get; set; }

    /// <summary>
    /// Additional details about the error.
    /// </summary>
    [JsonPropertyName("details")]
    public string? Details { get; set; }

    /// <summary>
    /// The type of checkpoint operation that failed (e.g., "create", "resume", "rehydrate").
    /// </summary>
    [JsonPropertyName("operation")]
    public string? Operation { get; set; }
}
