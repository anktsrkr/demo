// Copyright (c) Microsoft. All rights reserved.

using System.Text.Json.Serialization;

namespace Microsoft.Agents.AI.Workflows.AgenticUI.Events;

/// <summary>
/// Event emitted when an executor is invoked.
/// </summary>
public class ExecutorInvokedUIEvent : AgenticUIEvent
{
    [JsonPropertyName("executor_id")]
    public string ExecutorId { get; set; } = string.Empty;

    [JsonPropertyName("input")]
    public object? Input { get; set; }
}

/// <summary>
/// Event emitted when an executor completes successfully.
/// </summary>
public class ExecutorCompletedUIEvent : AgenticUIEvent
{
    [JsonPropertyName("executor_id")]
    public string ExecutorId { get; set; } = string.Empty;

    [JsonPropertyName("output")]
    public object? Output { get; set; }
}

/// <summary>
/// Event emitted when an executor fails.
/// </summary>
public class ExecutorFailedUIEvent : AgenticUIEvent
{
    [JsonPropertyName("executor_id")]
    public string ExecutorId { get; set; } = string.Empty;

    [JsonPropertyName("error")]
    public string Error { get; set; } = string.Empty;
}
