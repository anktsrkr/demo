// Copyright (c) Microsoft. All rights reserved.

using System.Text.Json;
using System.Text.Json.Serialization;

namespace Microsoft.Agents.AI.Workflows.AgenticUI.Events;

/// <summary>
/// Event emitted when a full snapshot of the agent's state is captured.
/// </summary>
public class AgentStateSnapshotEvent : AgenticUIEvent
{
    [JsonPropertyName("snapshot")]
    public JsonElement? Snapshot { get; set; }
}

/// <summary>
/// Event emitted when an incremental change to the agent's state occurs (JSON Patch).
/// </summary>
public class AgentStateDeltaEvent : AgenticUIEvent
{
    [JsonPropertyName("delta")]
    public JsonElement? Delta { get; set; }
}
