// Copyright (c) Microsoft. All rights reserved.

using System.Text.Json.Serialization;

namespace Microsoft.Agents.AI.Workflows.AgenticUI.Events;

/// <summary>
/// Event emitted when a workflow run starts.
/// </summary>
public class RunStartedEvent : AgenticUIEvent
{
    [JsonPropertyName("workflow_id")]
    public string WorkflowId { get; set; } = string.Empty;

    [JsonPropertyName("run_id")]
    public string RunId { get; set; } = string.Empty;
}

/// <summary>
/// Event emitted when a workflow run finishes successfully.
/// </summary>
public class RunFinishedEvent : AgenticUIEvent
{
    [JsonPropertyName("run_id")]
    public string RunId { get; set; } = string.Empty;

    [JsonPropertyName("output")]
    public object? Output { get; set; }
}

/// <summary>
/// Event emitted when a workflow run encounters an error.
/// </summary>
public class RunErrorEvent : AgenticUIEvent
{
    [JsonPropertyName("run_id")]
    public string RunId { get; set; } = string.Empty;

    [JsonPropertyName("error")]
    public string Error { get; set; } = string.Empty;

    [JsonPropertyName("details")]
    public string? Details { get; set; }
}
