// Copyright (c) Microsoft. All rights reserved.

namespace Microsoft.Agents.AI.Workflows.AgenticUI.Events;

/// <summary>
/// Constants for Agentic UI event types.
/// </summary>
public static class AgenticUIEventTypes
{
    // Lifecycle
    public const string RunStarted = "RUN_STARTED";
    public const string RunFinished = "RUN_FINISHED";
    public const string RunError = "RUN_ERROR";

    // Agent State
    public const string AgentStateSnapshot = "AGENT_STATE_SNAPSHOT";
    public const string AgentStateDelta = "AGENT_STATE_DELTA";

    // Planning
    public const string AgentPlanningStart = "AGENT_PLANNING_START";
    public const string AgentPlanningStep = "AGENT_PLANNING_STEP";
    public const string AgentPlanningEnd = "AGENT_PLANNING_END";

    // Tool Calls
    public const string ToolCallStart = "TOOL_CALL_START";
    public const string ToolCallArgs = "TOOL_CALL_ARGS";
    public const string ToolCallEnd = "TOOL_CALL_END";
    public const string ToolCallResult = "TOOL_CALL_RESULT";

    // Executor State
    public const string ExecutorInvoked = "EXECUTOR_INVOKED";
    public const string ExecutorCompleted = "EXECUTOR_COMPLETED";
    public const string ExecutorFailed = "EXECUTOR_FAILED";

    // SuperStep
    public const string SuperStepStarted = "SUPERSTEP_STARTED";
    public const string SuperStepCompleted = "SUPERSTEP_COMPLETED";

    // Agent Updates
    public const string AgentUpdate = "AGENT_UPDATE";

    // Workflow Events
    public const string WorkflowOutput = "WORKFLOW_OUTPUT";
    public const string WorkflowWarning = "WORKFLOW_WARNING";
    public const string RequestInfo = "REQUEST_INFO";

    // Checkpoint Events
    public const string CheckpointCreated = "CHECKPOINT_CREATED";
    public const string CheckpointResuming = "CHECKPOINT_RESUMING";
    public const string CheckpointRehydrating = "CHECKPOINT_REHYDRATING";
    public const string CheckpointError = "CHECKPOINT_ERROR";
}
