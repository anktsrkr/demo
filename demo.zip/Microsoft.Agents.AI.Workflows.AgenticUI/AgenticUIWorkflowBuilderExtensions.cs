// Copyright (c) Microsoft. All rights reserved.

using Microsoft.Agents.AI.Workflows;

namespace Microsoft.Agents.AI.Workflows.AgenticUI;

public static class AgenticUIWorkflowBuilderExtensions
{
    // Placeholder for future builder extensions if needed.
    // Currently, typical usage is just adding the library and using extension methods on IWorkflowContext (e.g. EmitPlanningStepAsync).
    // We might add methods here to register global policies or interceptors later.
}
