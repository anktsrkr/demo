using Microsoft.Agents.AI.Workflows.AgenticUI.Checkpointing;
using Microsoft.Agents.AI.Workflows.AgenticUI.Events;
using Microsoft.Agents.AI.Workflows.Checkpointing;
using Microsoft.Extensions.AI;
using System.Text.Json;

namespace Microsoft.Agents.AI.Workflows.AgenticUI;

/// <summary>
/// Manages thread and checkpoint operations for AgenticUI.
/// Provides methods for listing threads, retrieving chat history, and managing checkpoints.
/// </summary>
/// <remarks>
/// This class wraps an <see cref="ICheckpointStore{TStoreObject}"/> to provide
/// thread-centric operations like retrieving chat history and messages.
/// It is distinct from the framework's CheckpointManager which is used for workflow execution.
/// </remarks>
public class ThreadManager(ICheckpointStore<JsonElement> store)
{
    private readonly ICheckpointStore<JsonElement> _store = store ?? throw new ArgumentNullException(nameof(store));

    #region Thread Operations

    /// <summary>
    /// Lists all unique run/thread IDs.
    /// </summary>
    public ValueTask<IEnumerable<string>> ListThreadsAsync(CancellationToken ct = default)
    {
        if (_store is ICheckpointStoreWithManagement<JsonElement> management)
        {
            return management.ListRunsAsync(ct);
        }

        return ValueTask.FromResult(Enumerable.Empty<string>());
    }

    /// <summary>
    /// Gets a thread with its messages from the latest checkpoint.
    /// </summary>
    public async ValueTask<AgenticUIThread> GetThreadAsync(string runId, CancellationToken ct = default)
    {
        var messages = await GetMessagesAsync(runId, ct).ConfigureAwait(false);
        var metadata = await GetLatestCheckpointAsync(runId, ct).ConfigureAwait(false);
        return new AgenticUIThread(runId, messages, metadata?.CreatedAt);
    }

    /// <summary>
    /// Gets a list of ChatMessages from the latest checkpoint for a run.
    /// </summary>
    public async ValueTask<IReadOnlyList<ChatMessage>> GetMessagesAsync(string runId, CancellationToken ct = default)
    {
        var historyJson = await GetChatHistoryDataAsync(runId, ct).ConfigureAwait(false);
        if (string.IsNullOrEmpty(historyJson))
        {
            return Array.Empty<ChatMessage>();
        }

        try
        {
            var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
            var messages = JsonSerializer.Deserialize<List<ChatMessage>>(historyJson, options);
            return messages ?? new List<ChatMessage>();
        }
        catch
        {
            return Array.Empty<ChatMessage>();
        }
    }

    /// <summary>
    /// Deletes all checkpoints for a thread/run.
    /// </summary>
    public ValueTask DeleteThreadAsync(string runId, CancellationToken ct = default)
    {
        if (_store is ICheckpointStoreWithManagement<JsonElement> management)
        {
            return management.DeleteRunCheckpointsAsync(runId, ct);
        }

        return ValueTask.CompletedTask;
    }

    #endregion

    #region Checkpoint Operations

    /// <summary>
    /// Retrieves checkpoint metadata by ID.
    /// </summary>
    public async ValueTask<CheckpointMetadata?> GetCheckpointMetadataAsync(string checkpointId, string runId, CancellationToken ct = default)
    {
        var data = await GetCheckpointDataAsync(checkpointId, runId, ct).ConfigureAwait(false);
        if (data == null) return null;

        int stepNumber = 0;
        DateTimeOffset createdAt = DateTimeOffset.UtcNow;

        try
        {
            using var doc = JsonDocument.Parse(data);

            if (doc.RootElement.TryGetProperty("value", out var valueProp) &&
                valueProp.TryGetProperty("stepNumber", out var stepProp))
            {
                stepNumber = stepProp.GetInt32();
            }
            else if (doc.RootElement.TryGetProperty("superStepNumber", out var ssProp))
            {
                stepNumber = ssProp.GetInt32();
            }

            if (doc.RootElement.TryGetProperty("timestamp", out var tsProp) &&
                tsProp.TryGetDateTimeOffset(out var ts))
            {
                createdAt = ts;
            }
        }
        catch { /* Ignore parse errors */ }

        return new CheckpointMetadata
        {
            CheckpointId = checkpointId,
            RunId = runId,
            CreatedAt = createdAt,
            SuperStepNumber = stepNumber
        };
    }

    /// <summary>
    /// Lists all checkpoints for a specific run.
    /// </summary>
    public async ValueTask<IEnumerable<CheckpointMetadata>> ListCheckpointsAsync(string runId, CancellationToken ct = default)
    {
        var index = await _store.RetrieveIndexAsync(runId).ConfigureAwait(false);
        var result = new List<CheckpointMetadata>();

        foreach (var info in index)
        {
            var metadata = await GetCheckpointMetadataAsync(info.CheckpointId, runId, ct).ConfigureAwait(false);
            if (metadata != null)
            {
                result.Add(metadata);
            }
        }

        return result;
    }

    /// <summary>
    /// Retrieves the latest checkpoint metadata for a run.
    /// </summary>
    public async ValueTask<CheckpointMetadata?> GetLatestCheckpointAsync(string runId, CancellationToken ct = default)
    {
        var index = await _store.RetrieveIndexAsync(runId).ConfigureAwait(false);
        var latest = index.LastOrDefault();

        if (latest == null) return null;
        return await GetCheckpointMetadataAsync(latest.CheckpointId, runId, ct).ConfigureAwait(false);
    }

    /// <summary>
    /// Retrieves the checkpoint data as JSON string.
    /// </summary>
    public async ValueTask<string?> GetCheckpointDataAsync(string checkpointId, string runId, CancellationToken ct = default)
    {
        try
        {
            var element = await _store.RetrieveCheckpointAsync(runId, new CheckpointInfo(runId, checkpointId)).ConfigureAwait(false);
            return element.GetRawText();
        }
        catch (KeyNotFoundException)
        {
            return null;
        }
    }

    /// <summary>
    /// Retrieves the chat history data from the latest checkpoint of a run.
    /// </summary>
    public async ValueTask<string?> GetChatHistoryDataAsync(string runId, CancellationToken ct = default)
    {
        var latest = await GetLatestCheckpointAsync(runId, ct).ConfigureAwait(false);
        if (latest == null) return null;

        var data = await GetCheckpointDataAsync(latest.CheckpointId, runId, ct).ConfigureAwait(false);
        if (string.IsNullOrEmpty(data)) return null;

        try
        {
            using var doc = JsonDocument.Parse(data);

            JsonElement stateData;
            if (doc.RootElement.TryGetProperty("stateData", out stateData))
            {
                // Good - use stateData
            }
            else if (doc.RootElement.TryGetProperty("state", out stateData))
            {
                // Use legacy state
            }
            else
            {
                return null;
            }

            // Search for any key ending in "workflow_message_store"
            foreach (var prop in stateData.EnumerateObject())
            {
                if (prop.Name.EndsWith("workflow_message_store", StringComparison.OrdinalIgnoreCase))
                {
                    var storeProp = prop.Value;

                    // Unwrap TypedValue wrapper if present
                    if (storeProp.TryGetProperty("value", out var innerValue))
                    {
                        storeProp = innerValue;
                    }

                    // Extract messages array
                    if (storeProp.TryGetProperty("messages", out var messagesProp) ||
                        storeProp.TryGetProperty("Messages", out messagesProp))
                    {
                        return messagesProp.GetRawText();
                    }
                }
            }
        }
        catch { /* Ignore parse errors */ }

        return null;
    }

    #endregion

    #region Event Factory Methods

    /// <summary>
    /// Creates a checkpoint created event.
    /// </summary>
    public static CheckpointCreatedUIEvent CreateCreatedEvent(
        string checkpointId,
        string runId,
        int superStepNumber,
        string? description = null,
        Dictionary<string, string>? tags = null)
    {
        return new CheckpointCreatedUIEvent
        {
            CheckpointId = checkpointId,
            RunId = runId,
            SuperStepNumber = superStepNumber,
            Description = description,
            Tags = tags,
            Timestamp = DateTimeOffset.UtcNow
        };
    }

    /// <summary>
    /// Creates a checkpoint resuming event.
    /// </summary>
    public static CheckpointResumingUIEvent CreateResumingEvent(
        string checkpointId,
        string runId,
        int superStepNumber,
        string? reason = null)
    {
        return new CheckpointResumingUIEvent
        {
            CheckpointId = checkpointId,
            RunId = runId,
            SuperStepNumber = superStepNumber,
            Reason = reason,
            Timestamp = DateTimeOffset.UtcNow
        };
    }

    /// <summary>
    /// Creates a checkpoint error event.
    /// </summary>
    public static CheckpointErrorUIEvent CreateErrorEvent(
        string error,
        string? checkpointId = null,
        string? operation = null,
        string? details = null)
    {
        return new CheckpointErrorUIEvent
        {
            CheckpointId = checkpointId,
            Error = error,
            Operation = operation,
            Details = details,
            Timestamp = DateTimeOffset.UtcNow
        };
    }

    #endregion
}

/// <summary>
/// Represents metadata about a checkpoint.
/// </summary>
public record CheckpointMetadata
{
    public required string CheckpointId { get; set; }
    public required string RunId { get; set; }
    public required int SuperStepNumber { get; set; }
    public required DateTimeOffset CreatedAt { get; set; }
    public string? Description { get; set; }
    public Dictionary<string, string>? Tags { get; set; }
}
